'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { ShieldCheck, Mail, Lock, ArrowRight, AlertCircle, Sparkles, ArrowLeft } from 'lucide-react';
import Link from 'next/link';

export default function AdminLoginPage() {
    const router = useRouter();
    const [email, setEmail] = useState('admin@ammc.edu.ph');
    const [password, setPassword] = useState('admin123');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    // Check if already authenticated
    useEffect(() => {
        fetch('/api/auth/me').then((res) => res.json()).then((data) => {
            if (data.authenticated) {
                router.push('/admin');
            }
        }).catch(() => { });
    }, [router]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setIsLoading(true);

        try {
            const res = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password }),
            });

            const data = await res.json();
            if (!res.ok) {
                throw new Error(data.error || 'Authentication failed');
            }

            router.push('/admin');
        } catch (err: unknown) {
            const msg = err instanceof Error ? err.message : 'Login failed';
            setError(msg);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-[#FAF9F6] flex flex-col justify-between font-sans-ui text-[#3C3A36] p-4 sm:p-6">
            <div>
                <Link
                    href="/"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1F9D55] hover:text-[#3C3A36] p-2 rounded-xl hover:bg-[#EAF8EF] transition"
                >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Return to Public </span>
                </Link>
            </div>

            <div className="max-w-md w-full mx-auto my-8 bg-white rounded-3xl border border-[#E8E4DF] shadow-xl overflow-hidden">
                {/* Header */}
                <div className="bg-[#1F9D55] text-[#FAF9F6] px-6 py-6 text-center space-y-2">
                    <div className="w-16 h-16 rounded-2xl overflow-hidden bg-white border border-white/20 mx-auto shadow-xs flex items-center justify-center">
                        <img src="/logo.png" alt="AMMC Logo" className="w-full h-full object-cover" />
                    </div>
                    <div>
                        <h1 className="font-serif-heading text-2xl text-[#FAF9F6]">
                            AMMC Admin
                        </h1>
                        <p className="text-xs text-[#DDD8CE]">
                            Dr. Aurelio Mendoza Memorial Colleges
                        </p>
                    </div>
                </div>

                {/* Body */}
                <div className="p-6 sm:p-8 space-y-5">
                    {error && (
                        <div className="p-3.5 rounded-2xl bg-[#FAF0EB] border border-[#ECCEC1] text-[#9E5B3D] text-xs flex items-start gap-2.5">
                            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                            <span>{error}</span>
                        </div>
                    )}

                    {/* Quick presets */}
                    <div className="p-3.5 rounded-2xl bg-[#EAF8EF] border border-[#B2E6C4] text-xs space-y-2">
                        <div className="flex items-center gap-1.5 font-semibold text-[#0E562D]">
                            <Sparkles className="w-3.5 h-3.5 text-[#1F9D55]" />
                            <span>Quick Test Account (Password: <code>admin123</code>):</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                            <button
                                type="button"
                                onClick={() => {
                                    setEmail('admin@ammc.edu.ph');
                                    setPassword('admin123');
                                }}
                                className="px-2.5 py-1 rounded-full bg-white border border-[#B2E6C4] text-[#0E562D] text-[11px] font-medium hover:border-[#1F9D55]"
                            >
                                Super Admin
                            </button>
                            <button
                                type="button"
                                onClick={() => {
                                    setEmail('registrar@ammc.edu.ph');
                                    setPassword('admin123');
                                }}
                                className="px-2.5 py-1 rounded-full bg-white border border-[#B2E6C4] text-[#0E562D] text-[11px] font-medium hover:border-[#1F9D55]"
                            >
                                Registrar
                            </button>
                        </div>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="space-y-1.5">
                            <label className="text-xs font-semibold text-[#3C3A36] uppercase tracking-wider">
                                Institutional Email
                            </label>
                            <div className="relative">
                                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6B6862]" />
                                <input
                                    type="email"
                                    required
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    placeholder="admin@ammc.edu.ph"
                                    className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                                />
                            </div>
                        </div>

                        <div className="space-y-1.5">
                            <label className="text-xs font-semibold text-[#3C3A36] uppercase tracking-wider">
                                Password
                            </label>
                            <div className="relative">
                                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6B6862]" />
                                <input
                                    type="password"
                                    required
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder="••••••••"
                                    className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                                />
                            </div>
                        </div>

                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full py-3 px-5 rounded-2xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] font-medium text-xs flex items-center justify-center gap-2 shadow-md transition disabled:opacity-50"
                        >
                            {isLoading ? (
                                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            ) : (
                                <>
                                    <span>Sign In to Admin Studio</span>
                                    <ArrowRight className="w-4 h-4" />
                                </>
                            )}
                        </button>
                    </form>
                </div>

                <div className="bg-[#FAF9F6] px-6 py-3 border-t border-[#E8E4DF] text-center text-[11px] text-[#6B6862]">
                    Dr. Aurelio Mendoza Memorial Colleges • Administrative Security Framework
                </div>
            </div>

            <div className="text-center text-[11px] text-[#6B6862]">
                © 2026 Dr. Aurelio Mendoza Memorial Colleges. All rights reserved.
            </div>
        </div>
    );
}
