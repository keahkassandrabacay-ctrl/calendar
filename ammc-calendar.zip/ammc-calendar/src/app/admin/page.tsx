'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import AdminAnnouncementForm from '@/components/AdminAnnouncementForm';
import AdminEventForm from '@/components/AdminEventForm';
import AdminAuthModal from '@/components/AdminAuthModal';
import TaxonomyManager from '@/components/TaxonomyManager';
import NotificationBlasts from '@/components/NotificationBlasts';
import ConfirmDialog from '@/components/ConfirmDialog';
import PdfDownloadButton from '@/components/PdfDownloadButton';
import { announceDataChange } from '@/lib/data-refresh';
import {
    Announcement,
    SchoolEvent,
    AdminUser,
    Student,
} from '@/types';
import {
    ShieldCheck,
    Bell,
    Calendar,
    Plus,
    Trash2,
    Pin,
    ExternalLink,
    Download,
    Search,
    MapPin,
    GraduationCap,
    Pencil,
    Mail,
    Phone,
    Clock3,
    UserCheck,
    UserX,
    Tags,
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';

// CSV export helper (module scope: runs in an event handler).
function downloadStudentsCSV(students: Student[]) {
    const headers = ['Student ID', 'First Name', 'Last Name', 'Middle Name', 'Program', 'Year', 'Phone', 'Email', 'Status'];
    const rows = students.map((s) => [`"${s.student_id}"`, `"${s.fname.replace(/"/g, '""')}"`, `"${s.lname.replace(/"/g, '""')}"`, `"${(s.mname || '').replace(/"/g, '""')}"`, `"${s.course.replace(/"/g, '""')}"`, `"${s.year}"`, `"${s.phone}"`, `"${s.email}"`, `"${s.status || 'approved'}"`]);
    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `AMMC_Students_${Date.now()}.csv`;
    link.click();
    URL.revokeObjectURL(url);
}

export default function AdminPage() {
    const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);
    const [isAuthLoading, setIsAuthLoading] = useState(true);
    const [activeTab, setActiveTab] = useState<'announcements' | 'events' | 'students' | 'subscribers' | 'taxonomy' | 'notifications'>('announcements');

    // Form states
    const [isCreatingAnnouncement, setIsCreatingAnnouncement] = useState(false);
    const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
    // Deep-link target from modal Edit buttons (?tab=announcements&edit=<id>).
    const [pendingEditId, setPendingEditId] = useState<string | null>(null);
    const [pendingEditEventId, setPendingEditEventId] = useState<string | null>(null);
    type ConfirmAction = 'delete-announcement' | 'delete-event' | 'delete-student' | 'decline-student';
    const [confirmAction, setConfirmAction] = useState<{ action: ConfirmAction; id: string; label: string } | null>(null);
    const [isCreatingEvent, setIsCreatingEvent] = useState(false);
    const [editingEvent, setEditingEvent] = useState<SchoolEvent | null>(null);

    // Data
    const [announcements, setAnnouncements] = useState<Announcement[]>([]);
    const [events, setEvents] = useState<SchoolEvent[]>([]);
    const [students, setStudents] = useState<Student[]>([]);
    const [pendingStudents, setPendingStudents] = useState<Student[]>([]);
    const [studentSearch, setStudentSearch] = useState('');
    const [studentCourseFilter, setStudentCourseFilter] = useState('All');
    const [studentYearFilter, setStudentYearFilter] = useState('All');
    const [isCreatingStudent, setIsCreatingStudent] = useState(false);
    const [editingStudent, setEditingStudent] = useState<Student | null>(null);
    const [studentForm, setStudentForm] = useState({ student_id: '', fname: '', lname: '', mname: '', course: '', year: '1', phone: '', email: '' });
    const [studentFormError, setStudentFormError] = useState('');
    const [studentFormLoading, setStudentFormLoading] = useState(false);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

    // Auth check
    const checkAuth = async () => {
        setIsAuthLoading(true);
        try {
            const res = await fetch('/api/auth/me');
            const data = await res.json();
            if (data.authenticated && data.user) {
                setCurrentUser(data.user);
            } else {
                setCurrentUser(null);
            }
        } catch {
            setCurrentUser(null);
        } finally {
            setIsAuthLoading(false);
        }
    };

    useEffect(() => {
        const frame = requestAnimationFrame(() => {
            void checkAuth();
        });
        return () => cancelAnimationFrame(frame);
    }, []);

    // Sync tab from URL (?tab=) — allows Navbar submenu deep-links; Posting separated from Students.
    // Also captures ?edit=<id> deep-links from modal Edit buttons.
    useEffect(() => {
        const frame = requestAnimationFrame(() => {
            const params = new URLSearchParams(window.location.search);
            const tab = params.get('tab');
            if (tab && ['announcements', 'events', 'students', 'subscribers', 'taxonomy', 'notifications'].includes(tab)) {
                setActiveTab(tab as 'announcements' | 'events' | 'students' | 'subscribers' | 'taxonomy' | 'notifications');
                setIsCreatingAnnouncement(false);
                setEditingAnnouncement(null);
                setIsCreatingEvent(false);
                setEditingEvent(null);
                setIsCreatingStudent(false);
            }
            const editId = params.get('edit');
            if (editId) {
                if (tab === 'events') setPendingEditEventId(editId);
                else setPendingEditId(editId);
            }
        });
        return () => cancelAnimationFrame(frame);
    }, []);

    const navigateTab = (tab: 'announcements' | 'events' | 'students' | 'subscribers' | 'taxonomy' | 'notifications') => {
        setActiveTab(tab);
        setIsCreatingAnnouncement(false);
        setEditingAnnouncement(null);
        setIsCreatingEvent(false);
        setEditingEvent(null);
        setIsCreatingStudent(false);
        if (typeof window !== 'undefined') {
            const url = new URL(window.location.href);
            url.searchParams.set('tab', tab);
            window.history.replaceState(null, '', url.toString());
        }
    };

    const loadData = async () => {
        setIsRefreshing(true);
        try {
            const [annRes, evtRes, stuRes, pendingRes] = await Promise.all([
                fetch('/api/announcements'),
                fetch('/api/events'),
                fetch('/api/students?status=approved'),
                fetch('/api/students?status=pending'),
            ]);

            const annData = await annRes.json();
            const evtData = await evtRes.json();
            const stuData = await stuRes.json();
            const pendingData = await pendingRes.json();

            if (annData.announcements) setAnnouncements(annData.announcements);
            if (evtData.events) setEvents(evtData.events);
            if (stuData.students) setStudents(stuData.students);
            if (pendingData.students) setPendingStudents(pendingData.students);
        } catch (e) {
            console.error('Error loading admin data:', e);
        } finally {
            setIsRefreshing(false);
        }
    };

    useEffect(() => {
        if (!currentUser) return;
        const frame = requestAnimationFrame(() => {
            void loadData();
        });
        return () => cancelAnimationFrame(frame);
    }, [currentUser]);

    // Resolve ?edit=<id> deep-links once announcements are loaded.
    useEffect(() => {
        if (!pendingEditId || announcements.length === 0) return;
        const frame = requestAnimationFrame(() => {
            const target = announcements.find((a) => a.id === pendingEditId);
            if (target) {
                setIsCreatingAnnouncement(false);
                setEditingAnnouncement(target);
                setPendingEditId(null);
                if (typeof window !== 'undefined') {
                    const url = new URL(window.location.href);
                    url.searchParams.delete('edit');
                    window.history.replaceState(null, '', url.toString());
                }
            }
        });
        return () => cancelAnimationFrame(frame);
    }, [pendingEditId, announcements]);

    // Resolve ?edit=<id> deep-links for events once events are loaded.
    useEffect(() => {
        if (!pendingEditEventId || events.length === 0) return;
        const frame = requestAnimationFrame(() => {
            const target = events.find((e) => e.id === pendingEditEventId);
            if (target) {
                setIsCreatingEvent(false);
                setEditingEvent(target);
                setPendingEditEventId(null);
                if (typeof window !== 'undefined') {
                    const url = new URL(window.location.href);
                    url.searchParams.delete('edit');
                    window.history.replaceState(null, '', url.toString());
                }
            }
        });
        return () => cancelAnimationFrame(frame);
    }, [pendingEditEventId, events]);

    const handleLogout = async () => {
        await fetch('/api/auth/me', { method: 'POST' });
        setCurrentUser(null);
    };

    const handleDeleteAnnouncement = async (id: string) => {
        setConfirmAction({ action: 'delete-announcement', id, label: announcements.find((a) => a.id === id)?.title || 'this announcement' });
    };

    const doDeleteAnnouncement = async (id: string) => {
        try {
            const res = await fetch(`/api/announcements?id=${id}`, { method: 'DELETE' });
            if (res.ok) {
                setAnnouncements((prev) => prev.filter((a) => a.id !== id));
                announceDataChange('announcement');
            }
        } catch (e) {
            alert('Failed to delete announcement');
        }
    };

    const handleDeleteEvent = async (id: string) => {
        setConfirmAction({ action: 'delete-event', id, label: events.find((e) => e.id === id)?.title || 'this event' });
    };

    const doDeleteEvent = async (id: string) => {
        try {
            const res = await fetch(`/api/events?id=${id}`, { method: 'DELETE' });
            if (res.ok) {
                setEvents((prev) => prev.filter((e) => e.id !== id));
                announceDataChange('event');
            }
        } catch (e) {
            alert('Failed to delete event');
        }
    };

    const resetStudentForm = () => {
        setStudentForm({ student_id: '', fname: '', lname: '', mname: '', course: '', year: '1', phone: '', email: '' });
        setStudentFormError('');
        setEditingStudent(null);
        setIsCreatingStudent(false);
    };

    const handleCreateStudent = async (e: React.FormEvent) => {
        e.preventDefault();
        setStudentFormError('');
        if (!studentForm.student_id.trim() || !studentForm.fname.trim() || !studentForm.lname.trim() || !studentForm.course.trim() || !studentForm.phone.trim() || !studentForm.email.trim()) {
            setStudentFormError('Please fill all required fields.');
            return;
        }
        setStudentFormLoading(true);
        try {
            const res = await fetch('/api/students', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...studentForm, year: Number(studentForm.year) }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to create student');
            setStudents((prev) => [data.student, ...prev]);
            resetStudentForm();
        } catch (err: unknown) {
            setStudentFormError(err instanceof Error ? err.message : 'Failed to create student');
        } finally {
            setStudentFormLoading(false);
        }
    };

    const handleUpdateStudent = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!editingStudent) return;
        setStudentFormError('');
        setStudentFormLoading(true);
        try {
            const res = await fetch(`/api/students?id=${editingStudent.student_id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ fname: studentForm.fname, lname: studentForm.lname, mname: studentForm.mname, course: studentForm.course, year: Number(studentForm.year), phone: studentForm.phone, email: studentForm.email }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to update student');
            setStudents((prev) => prev.map((s) => (s.student_id === editingStudent.student_id ? data.student : s)));
            resetStudentForm();
        } catch (err: unknown) {
            setStudentFormError(err instanceof Error ? err.message : 'Failed to update student');
        } finally {
            setStudentFormLoading(false);
        }
    };

    const handleDeleteStudent = async (id: string) => {
        setConfirmAction({ action: 'delete-student', id, label: id });
    };

    const doDeleteStudent = async (id: string) => {
        try {
            const res = await fetch(`/api/students?id=${id}`, { method: 'DELETE' });
            if (!res.ok) {
                const d = await res.json();
                throw new Error(d.error || 'Failed to delete');
            }
            setStudents((prev) => prev.filter((s) => s.student_id !== id));
            setPendingStudents((prev) => prev.filter((s) => s.student_id !== id));
        } catch (err: unknown) {
            alert(err instanceof Error ? err.message : 'Failed to delete student');
        }
    };

    const confirmDialogCopy = (action: ConfirmAction) => {
        switch (action) {
            case 'delete-announcement':
                return { title: 'Delete announcement?', confirmLabel: 'Delete', tone: 'danger' as const };
            case 'delete-event':
                return { title: 'Delete event?', confirmLabel: 'Delete', tone: 'danger' as const };
            case 'delete-student':
                return { title: 'Delete student?', confirmLabel: 'Delete', tone: 'danger' as const };
            default:
                return { title: 'Decline subscription?', confirmLabel: 'Decline', tone: 'danger' as const };
        }
    };

    const runConfirmAction = async () => {
        const pending = confirmAction;
        if (!pending) return;
        setConfirmAction(null);
        if (pending.action === 'delete-announcement') return doDeleteAnnouncement(pending.id);
        if (pending.action === 'delete-event') return doDeleteEvent(pending.id);
        if (pending.action === 'delete-student') return doDeleteStudent(pending.id);
        return doDeclineStudent(pending.id);
    };

    const handleApproveStudent = async (id: string) => {
        try {
            const res = await fetch(`/api/students?id=${id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: 'approved' }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to approve');
            setPendingStudents((prev) => prev.filter((s) => s.student_id !== id));
            setStudents((prev) => [data.student, ...prev]);
        } catch (err: unknown) {
            alert(err instanceof Error ? err.message : 'Failed to approve student');
        }
    };

    const handleDeclineStudent = async (id: string) => {
        setConfirmAction({ action: 'decline-student', id, label: id });
    };

    const doDeclineStudent = async (id: string) => {
        try {
            const res = await fetch(`/api/students?id=${id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: 'declined' }),
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Failed to decline');
            setPendingStudents((prev) => prev.filter((s) => s.student_id !== id));
        } catch (err: unknown) {
            alert(err instanceof Error ? err.message : 'Failed to decline student');
        }
    };

    const handleExportStudentsCSV = () => {
        downloadStudentsCSV(filteredStudents);
    };

    if (isAuthLoading) {
        return (
            <div className="min-h-screen bg-[#FAF9F6] flex items-center justify-center font-sans-ui text-[#3C3A36]">
                <div className="text-center space-y-3">
                    <div className="w-8 h-8 border-2 border-[#1F9D55] border-t-transparent rounded-full animate-spin mx-auto" />
                    <p className="text-xs font-medium">Verifying Administrative Privileges...</p>
                </div>
            </div>
        );
    }

    if (!currentUser) {
        return (
            <div className="min-h-screen bg-[#FAF9F6] flex flex-col font-sans-ui text-[#3C3A36]">
                <Navbar
                    onOpenAuthModal={() => setIsAuthModalOpen(true)}
                    currentUser={null}
                    onLogout={handleLogout}
                    searchQuery=""
                    onSearchChange={() => { }}
                />

                <main className="flex-1 flex items-center justify-center p-6">
                    <div className="max-w-md w-full bg-white rounded-3xl p-8 border border-[#E8E4DF] shadow-lg text-center space-y-5">
                        <div className="w-14 h-14 rounded-2xl bg-[#EAF8EF] border border-[#B2E6C4] text-[#1F9D55] flex items-center justify-center mx-auto">
                            <ShieldCheck className="w-7 h-7" />
                        </div>

                        <div>
                            <h2 className="font-serif-heading text-2xl text-[#262422]">
                                Admin Studio Access Required
                            </h2>
                            <p className="text-xs text-[#6B6862] mt-1 leading-relaxed">
                                Please sign in with your Dr. Aurelio Mendoza Memorial Colleges administrative or registrar credentials to manage broadcasts and events.
                            </p>
                        </div>

                        <button
                            onClick={() => setIsAuthModalOpen(true)}
                            className="w-full py-3 rounded-2xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-semibold shadow-sm transition"
                        >
                            Sign In to Admin Studio
                        </button>

                        <div className="text-[11px] text-[#6B6862] pt-2 border-t border-[#E8E4DF]">
                            Demo account: <code>admin@ammc.edu.ph</code> / <code>admin123</code>
                        </div>
                    </div>
                </main>

                <AdminAuthModal
                    isOpen={isAuthModalOpen}
                    onClose={() => setIsAuthModalOpen(false)}
                    onLoginSuccess={(user) => {
                        setCurrentUser(user);
                    }}
                />
            </div>
        );
    }

    const filteredStudents = students.filter((s) => {
        if (studentCourseFilter !== 'All' && s.course !== studentCourseFilter) return false;
        if (studentYearFilter !== 'All' && String(s.year) !== studentYearFilter) return false;
        if (studentSearch.trim()) {
            const q = studentSearch.toLowerCase();
            return (
                s.student_id.toLowerCase().includes(q) ||
                s.fname.toLowerCase().includes(q) ||
                s.lname.toLowerCase().includes(q) ||
                (s.mname && s.mname.toLowerCase().includes(q)) ||
                s.email.toLowerCase().includes(q) ||
                s.phone.includes(q) ||
                s.course.toLowerCase().includes(q)
            );
        }
        return true;
    });

    const uniqueCourses = Array.from(new Set(students.map((s) => s.course))).sort();

    return (
        <div className="min-h-screen bg-[#FAF9F6] flex flex-col font-sans-ui text-[#3C3A36]">
            <Navbar
                onOpenAuthModal={() => { }}
                currentUser={currentUser}
                onLogout={handleLogout}
                searchQuery=""
                onSearchChange={() => { }}
            />

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex-1 w-full py-8 space-y-8">
                {/* Studio Top Banner */}
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E4DF] shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="space-y-2">
                        <div className="flex items-center gap-2">
                            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-[#EAF8EF] text-[#0E562D] border border-[#B2E6C4]">
                                {currentUser.role}
                            </span>
                            <span className="text-xs text-[#6B6862]">
                                {currentUser.department || 'Administration'}
                            </span>
                        </div>
                        <h1 className="font-serif-heading text-3xl sm:text-4xl text-[#262422]">
                            AMMC Admin Control Center
                        </h1>
                        <p className="text-xs text-[#6B6862]">
                            Welcome back, <strong>{currentUser.name}</strong> ({currentUser.email}). Manage postings — Announcements & Events — separated from Students & Subscribers. Approved students are notified for every new posting.
                        </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                        <button
                            onClick={() => {
                                navigateTab('announcements');
                                setIsCreatingAnnouncement(true);
                            }}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-semibold shadow-xs transition"
                        >
                            <Plus className="w-3.5 h-3.5" />
                            <span>New Announcement</span>
                        </button>

                        <button
                            onClick={() => {
                                navigateTab('events');
                                setIsCreatingEvent(true);
                            }}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-[#FAF0EB] hover:bg-[#F7E5DC] text-[#B56E4D] border border-[#ECCEC1] text-xs font-semibold shadow-xs transition"
                        >
                            <Calendar className="w-3.5 h-3.5" />
                            <span>Schedule Event</span>
                        </button>
                    </div>
                </div>

                {/* Tab Navigation */}
                <div className="flex items-center gap-2 border-b border-[#E8E4DF] overflow-x-auto pb-1">
                    <button
                        onClick={() => {
                            navigateTab('announcements');
                        }}
                        className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-xs font-semibold transition ${activeTab === 'announcements'
                            ? 'bg-[#1F9D55] text-[#FAF9F6] shadow-xs'
                            : 'bg-white text-[#6B6862] hover:text-[#3C3A36] border border-[#E8E4DF]'
                            }`}
                    >
                        <Bell className="w-3.5 h-3.5" />
                        <span>Announcements ({announcements.length})</span>
                    </button>

                    <button
                        onClick={() => {
                            navigateTab('events');
                        }}
                        className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-xs font-semibold transition ${activeTab === 'events'
                            ? 'bg-[#1F9D55] text-[#FAF9F6] shadow-xs'
                            : 'bg-white text-[#6B6862] hover:text-[#3C3A36] border border-[#E8E4DF]'
                            }`}
                    >
                        <Calendar className="w-3.5 h-3.5" />
                        <span>Calendar Events ({events.length})</span>
                    </button>

                    <button
                        onClick={() => {
                            navigateTab('students');
                        }}
                        className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-xs font-semibold transition ${activeTab === 'students'
                            ? 'bg-[#1F9D55] text-[#FAF9F6] shadow-xs'
                            : 'bg-white text-[#6B6862] hover:text-[#3C3A36] border border-[#E8E4DF]'
                            }`}
                    >
                        <GraduationCap className="w-3.5 h-3.5" />
                        <span>Students ({students.length})</span>
                    </button>

                    <button
                        onClick={() => {
                            navigateTab('subscribers');
                        }}
                        className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-xs font-semibold transition relative ${activeTab === 'subscribers'
                            ? 'bg-[#B56E4D] text-white shadow-xs'
                            : 'bg-white text-[#6B6862] hover:text-[#3C3A36] border border-[#E8E4DF]'
                            }`}
                    >
                        <Clock3 className="w-3.5 h-3.5" />
                        <span>Subscribers</span>
                        {pendingStudents.length > 0 && (
                            <span className="px-1.5 py-0.5 rounded-full bg-[#B56E4D] text-white text-[10px] font-bold border border-white/20">
                                {pendingStudents.length}
                            </span>
                        )}
                    </button>

                    <button
                        onClick={() => {
                            navigateTab('taxonomy');
                        }}
                        className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-xs font-semibold transition ${activeTab === 'taxonomy'
                            ? 'bg-[#1F9D55] text-[#FAF9F6] shadow-xs'
                            : 'bg-white text-[#6B6862] hover:text-[#3C3A36] border border-[#E8E4DF]'
                            }`}
                    >
                        <Tags className="w-3.5 h-3.5" />
                        <span>Categories & Departments</span>
                    </button>

                    <button
                        onClick={() => {
                            navigateTab('notifications');
                        }}
                        className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-xs font-semibold transition ${activeTab === 'notifications'
                            ? 'bg-[#1F9D55] text-[#FAF9F6] shadow-xs'
                            : 'bg-white text-[#6B6862] hover:text-[#3C3A36] border border-[#E8E4DF]'
                            }`}
                    >
                        <Mail className="w-3.5 h-3.5" />
                        <span>Notifications</span>
                    </button>

                </div>

                {/* Tab 1: Announcements Content */}
                {activeTab === 'announcements' && (
                    <div className="space-y-6">
                        {(isCreatingAnnouncement || editingAnnouncement) ? (
                            <AdminAnnouncementForm
                                key={editingAnnouncement?.id ?? 'new'}
                                initialAnnouncement={editingAnnouncement}
                                onSuccess={() => {
                                    setIsCreatingAnnouncement(false);
                                    setEditingAnnouncement(null);
                                    loadData();
                                    announceDataChange('announcement');
                                }}
                                onCancel={() => {
                                    setIsCreatingAnnouncement(false);
                                    setEditingAnnouncement(null);
                                }}
                            />
                        ) : (
                            <div className="bg-white rounded-3xl p-6 border border-[#E8E4DF] shadow-sm space-y-4">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E8E4DF] pb-3">
                                    <h3 className="font-serif-heading text-2xl text-[#262422]">
                                        Published Announcements Archive
                                    </h3>
                                    <PdfDownloadButton
                                            label="Export all as PDF"
                                            title="Download every published announcement as one PDF"
                                            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#EAF8EF] text-[#1F9D55] text-xs font-semibold transition"
                                        />
                                        <button
                                        onClick={() => {
                                            setEditingAnnouncement(null);
                                            setIsCreatingAnnouncement(true);
                                        }}
                                        className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-semibold transition"
                                    >
                                        <Plus className="w-3.5 h-3.5" />
                                        <span>Create Announcement</span>
                                    </button>
                                </div>

                                <div className="divide-y divide-[#E8E4DF] space-y-3">
                                    {announcements.map((ann) => (
                                        <div
                                            key={ann.id}
                                            className="pt-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:bg-[#FAF9F6] p-3 rounded-2xl transition"
                                        >
                                            <div className="space-y-1 max-w-2xl">
                                                <div className="flex items-center gap-2 flex-wrap">
                                                    {ann.is_pinned && (
                                                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#1F9D55] text-white flex items-center gap-1">
                                                            <Pin className="w-2.5 h-2.5 fill-current" />
                                                            Pinned
                                                        </span>
                                                    )}
                                                    <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-[#FAF0EB] text-[#B56E4D]">
                                                        {ann.category}
                                                    </span>
                                                    <span className="text-xs text-[#6B6862]">
                                                        {ann.department} • {format(new Date(ann.issue_date ?? ann.created_at), 'MMM d, yyyy • h:mm a')}
                                                    </span>
                                                </div>
                                                <h4 className="font-serif-heading text-lg text-[#262422] leading-snug">
                                                    {ann.title}
                                                </h4>
                                                <p className="text-xs text-[#6B6862] line-clamp-1">
                                                    {ann.summary}
                                                </p>
                                            </div>

                                            <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                                                <Link
                                                    href="/"
                                                    target="_blank"
                                                    className="p-2 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#FAF9F6] text-[#6B6862]"
                                                    title="View on Public "
                                                >
                                                    <ExternalLink className="w-3.5 h-3.5" />
                                                </Link>
                                                <PdfDownloadButton
                                                    id={ann.id}
                                                    title="Download this circular as PDF"
                                                />
                                                <button
                                                    onClick={() => {
                                                        setIsCreatingAnnouncement(false);
                                                        setEditingAnnouncement(ann);
                                                    }}
                                                    className="p-2 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#EAF8EF] text-[#1F9D55] transition"
                                                    title="Edit Announcement"
                                                >
                                                    <Pencil className="w-3.5 h-3.5" />
                                                </button>
                                                <button
                                                    onClick={() => handleDeleteAnnouncement(ann.id)}
                                                    className="p-2 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#FAF0EB] text-[#9E5B3D] transition"
                                                    title="Delete Announcement"
                                                >
                                                    <Trash2 className="w-3.5 h-3.5" />
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                )}

                {/* Tab 2: Events Content */}
                {activeTab === 'events' && (
                    <div className="space-y-6">
                        {(isCreatingEvent || editingEvent) ? (
                            <AdminEventForm
                                key={editingEvent?.id ?? 'new'}
                                initialEvent={editingEvent}
                                onSuccess={() => {
                                    setIsCreatingEvent(false);
                                    setEditingEvent(null);
                                    loadData();
                                    announceDataChange('event');
                                }}
                                onCancel={() => {
                                    setIsCreatingEvent(false);
                                    setEditingEvent(null);
                                }}
                            />
                        ) : (
                            <div className="bg-white rounded-3xl p-6 border border-[#E8E4DF] shadow-sm space-y-4">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E8E4DF] pb-3">
                                    <h3 className="font-serif-heading text-2xl text-[#262422]">
                                        Scheduled School Events
                                    </h3>
                                    <button
                                        onClick={() => {
                                            setEditingEvent(null);
                                            setIsCreatingEvent(true);
                                        }}
                                        className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-semibold transition"
                                    >
                                        <Plus className="w-3.5 h-3.5" />
                                        <span>Schedule Event</span>
                                    </button>
                                </div>

                                <div className="divide-y divide-[#E8E4DF] space-y-3">
                                    {events.map((evt) => (
                                        <div
                                            key={evt.id}
                                            className="pt-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:bg-[#FAF9F6] p-3 rounded-2xl transition"
                                        >
                                            <div className="space-y-1 max-w-2xl">
                                                <div className="flex items-center gap-2">
                                                    <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-[#FAF0EB] text-[#B56E4D]">
                                                        {evt.category}
                                                    </span>
                                                    <span className="text-xs text-[#6B6862]">
                                                        {format(new Date(evt.start_time), 'EEEE, MMM d, yyyy • h:mm a')}
                                                    </span>
                                                </div>
                                                <h4 className="font-serif-heading text-lg text-[#262422]">
                                                    {evt.title}
                                                </h4>
                                                <div className="flex items-center gap-1 text-xs text-[#6B6862]">
                                                    <MapPin className="w-3 h-3 text-[#B56E4D]" />
                                                    {evt.location}
                                                </div>
                                            </div>

                                            <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                                                <button
                                                    onClick={() => {
                                                        setIsCreatingEvent(false);
                                                        setEditingEvent(evt);
                                                    }}
                                                    className="p-2 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#EAF8EF] text-[#1F9D55] transition"
                                                    title="Edit Event"
                                                >
                                                    <Pencil className="w-3.5 h-3.5" />
                                                </button>
                                                <button
                                                    onClick={() => handleDeleteEvent(evt.id)}
                                                    className="p-2 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#FAF0EB] text-[#9E5B3D] transition"
                                                    title="Delete Event"
                                                >
                                                    <Trash2 className="w-3.5 h-3.5" />
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                )}


                {/* Tab 4: Students — Approved Students (Posting separated) */}
                {activeTab === 'students' && (
                    <div className="bg-white rounded-3xl p-6 border border-[#E8E4DF] shadow-sm space-y-4">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#E8E4DF] pb-4">
                            <div>
                                <h3 className="font-serif-heading text-2xl text-[#262422]">Students — Approved</h3>
                                <p className="text-xs text-[#6B6862]">
                                    Approved student directory. Only approved students receive SMS & email notifications for new postings.
                                </p>
                            </div>
                            <div className="flex flex-wrap items-center gap-2">
                                <button
                                    onClick={() => {
                                        setEditingStudent(null);
                                        setStudentForm({ student_id: '', fname: '', lname: '', mname: '', course: '', year: '1', phone: '', email: '' });
                                        setStudentFormError('');
                                        setIsCreatingStudent(true);
                                    }}
                                    className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-semibold transition"
                                >
                                    <Plus className="w-3.5 h-3.5" />
                                    <span>Add Student</span>
                                </button>
                                <button
                                    onClick={handleExportStudentsCSV}
                                    className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-white border border-[#E8E4DF] hover:bg-[#FAF9F6] text-[#3C3A36] text-xs font-semibold transition"
                                >
                                    <Download className="w-3.5 h-3.5" />
                                    <span>Export CSV</span>
                                </button>
                            </div>
                        </div>

                        {/* Filters — Posting separated from Students */}
                        <div className="flex flex-wrap items-center gap-2">
                            <div className="relative flex-1 min-w-[320px] max-w-lg">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B6862]" />
                                <input
                                    type="text"
                                    value={studentSearch}
                                    onChange={(e) => setStudentSearch(e.target.value)}
                                    placeholder="Search ID, name, email, phone..."
                                    className="w-full pl-11 pr-4 py-3 rounded-2xl bg-white border border-[#E8E4DF] text-sm text-[#3C3A36] placeholder-[#6B6862] shadow-sm focus:outline-none focus:border-[#1F9D55] focus:ring-2 focus:ring-[#1F9D55]/10 transition"
                                />
                            </div>
                            <select value={studentCourseFilter} onChange={(e) => setStudentCourseFilter(e.target.value)} className="px-4 py-2.5 rounded-2xl bg-white border border-[#E8E4DF] text-sm text-[#3C3A36] shadow-sm">
                                <option value="All">All Programs</option>
                                {uniqueCourses.map((c) => (
                                    <option key={c} value={c}>{c}</option>
                                ))}
                            </select>
                            <select value={studentYearFilter} onChange={(e) => setStudentYearFilter(e.target.value)} className="px-4 py-2.5 rounded-2xl bg-white border border-[#E8E4DF] text-sm text-[#3C3A36] shadow-sm">
                                <option value="All">All Years</option>
                                <option value="1">1st Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                                <option value="4">4th Year</option>
                            </select>
                            <span className="text-xs text-[#6B6862]">{filteredStudents.length} result(s)</span>
                        </div>

                        {/* Create/Edit form */}
                        {(isCreatingStudent || editingStudent) && (
                            <form onSubmit={editingStudent ? handleUpdateStudent : handleCreateStudent} className="p-5 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] space-y-4">
                                <div className="flex items-center justify-between">
                                    <h4 className="font-semibold text-sm text-[#262422]">{editingStudent ? `Edit Student ${editingStudent.student_id}` : 'Add New Student'}</h4>
                                    <button type="button" onClick={resetStudentForm} className="text-xs text-[#6B6862] hover:text-[#3C3A36] underline">Cancel</button>
                                </div>
                                {studentFormError && <div className="p-2 rounded-xl bg-[#FAF0EB] border border-[#ECCEC1] text-xs text-[#9E5B3D]">{studentFormError}</div>}
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                    <label className="space-y-1">
                                        <span className="text-[11px] font-semibold text-[#6B6862]">Student ID *</span>
                                        <input value={studentForm.student_id} onChange={(e) => setStudentForm({ ...studentForm, student_id: e.target.value })} disabled={!!editingStudent} placeholder="e.g. 2024-0001" className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E4DF] text-xs disabled:bg-[#EAF8EF] disabled:text-[#6B6862]" required />
                                    </label>
                                    <label className="space-y-1">
                                        <span className="text-[11px] font-semibold text-[#6B6862]">First Name *</span>
                                        <input value={studentForm.fname} onChange={(e) => setStudentForm({ ...studentForm, fname: e.target.value })} className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E4DF] text-xs" required />
                                    </label>
                                    <label className="space-y-1">
                                        <span className="text-[11px] font-semibold text-[#6B6862]">Last Name *</span>
                                        <input value={studentForm.lname} onChange={(e) => setStudentForm({ ...studentForm, lname: e.target.value })} className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E4DF] text-xs" required />
                                    </label>
                                    <label className="space-y-1">
                                        <span className="text-[11px] font-semibold text-[#6B6862]">Middle Name</span>
                                        <input value={studentForm.mname} onChange={(e) => setStudentForm({ ...studentForm, mname: e.target.value })} className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E4DF] text-xs" />
                                    </label>
                                    <label className="space-y-1">
                                        <span className="text-[11px] font-semibold text-[#6B6862]">Program *</span>
                                        <input value={studentForm.course} onChange={(e) => setStudentForm({ ...studentForm, course: e.target.value })} placeholder="e.g. BSIT, BSED, BSN" className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E4DF] text-xs" required />
                                    </label>
                                    <label className="space-y-1">
                                        <span className="text-[11px] font-semibold text-[#6B6862]">Year *</span>
                                        <select value={studentForm.year} onChange={(e) => setStudentForm({ ...studentForm, year: e.target.value })} className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E4DF] text-xs">
                                            <option value="1">1st Year</option>
                                            <option value="2">2nd Year</option>
                                            <option value="3">3rd Year</option>
                                            <option value="4">4th Year</option>
                                        </select>
                                    </label>
                                    <label className="space-y-1">
                                        <span className="text-[11px] font-semibold text-[#6B6862]">Phone *</span>
                                        <input value={studentForm.phone} onChange={(e) => setStudentForm({ ...studentForm, phone: e.target.value })} placeholder="+639XXXXXXXXX" className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E4DF] text-xs" required />
                                    </label>
                                    <label className="space-y-1 sm:col-span-2">
                                        <span className="text-[11px] font-semibold text-[#6B6862]">Email *</span>
                                        <input type="email" value={studentForm.email} onChange={(e) => setStudentForm({ ...studentForm, email: e.target.value })} placeholder="student@ammc.edu.ph" className="w-full px-3 py-2 rounded-xl bg-white border border-[#E8E4DF] text-xs" required />
                                    </label>
                                </div>
                                <button type="submit" disabled={studentFormLoading} className="px-5 py-2 rounded-xl bg-[#1F9D55] hover:bg-[#168044] text-white text-xs font-semibold disabled:opacity-60 transition">
                                    {studentFormLoading ? 'Saving...' : editingStudent ? 'Update Student' : 'Create Student'}
                                </button>
                            </form>
                        )}

                        {/* Approved Table */}
                        {filteredStudents.length === 0 ? (
                            <div className="py-12 text-center text-[#6B6862] text-xs space-y-2">
                                <GraduationCap className="w-8 h-8 text-[#DDD7CE] mx-auto" />
                                <p>No approved students. Add students directly.</p>
                            </div>
                        ) : (
                            <div className="overflow-x-auto">
                                <table className="w-full text-left text-xs border-collapse">
                                    <thead>
                                        <tr className="border-b border-[#E8E4DF] text-[#6B6862] uppercase tracking-wider">
                                            <th className="py-3 px-3">Student ID</th>
                                            <th className="py-3 px-3">Name</th>
                                            <th className="py-3 px-3">Program / Year</th>
                                            <th className="py-3 px-3">Phone</th>
                                            <th className="py-3 px-3">Email</th>
                                            <th className="py-3 px-3 text-right">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-[#E8E4DF]">
                                        {filteredStudents.map((s) => (
                                            <tr key={s.student_id} className="hover:bg-[#FAF9F6] transition">
                                                <td className="py-3 px-3 font-mono text-[11px] font-semibold text-[#262422]">{s.student_id}</td>
                                                <td className="py-3 px-3 font-semibold text-[#262422]">{s.lname}, {s.fname}{s.mname ? ` ${s.mname}` : ''}</td>
                                                <td className="py-3 px-3"><span className="px-2 py-0.5 rounded-md bg-[#EAF8EF] text-[#0E562D] font-medium text-[10px]">{s.course} — {s.year}{s.year === 1 ? 'st' : s.year === 2 ? 'nd' : s.year === 3 ? 'rd' : 'th'} Year</span></td>
                                                <td className="py-3 px-3"><div className="flex items-center gap-1"><Phone className="w-3 h-3 shrink-0 text-[#1F9D55]" /><span>{s.phone}</span></div></td>
                                                <td className="py-3 px-3"><div className="flex items-center gap-1"><Mail className="w-3 h-3 shrink-0 text-[#1F9D55]" /><span className="break-all">{s.email}</span></div></td>
                                                <td className="py-3 px-3">
                                                    <div className="flex items-center justify-end gap-1">
                                                        <button
                                                            onClick={() => {
                                                                setEditingStudent(s);
                                                                setIsCreatingStudent(false);
                                                                setStudentForm({ student_id: s.student_id, fname: s.fname, lname: s.lname, mname: s.mname || '', course: s.course, year: String(s.year), phone: s.phone, email: s.email });
                                                                setStudentFormError('');
                                                            }}
                                                            className="p-1.5 rounded-lg bg-white border border-[#E8E4DF] hover:bg-[#FAF9F6] text-[#1F9D55]"
                                                            title="Edit"
                                                        >
                                                            <Pencil className="w-3.5 h-3.5" />
                                                        </button>
                                                        <button onClick={() => handleDeleteStudent(s.student_id)} className="p-1.5 rounded-lg bg-white border border-[#E8E4DF] hover:bg-[#FAF0EB] text-[#9E5B3D]" title="Delete">
                                                            <Trash2 className="w-3.5 h-3.5" />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                        <p className="text-[11px] text-[#6B6862] bg-[#EAF8EF]/60 border border-[#B2E6C4] rounded-xl p-3">
                            Approved students receive every new Announcement/Event automatically.
                        </p>
                    </div>
                )}

                {/* Tab 5: Subscribers — Pending Requests (separated from Students) */}
                {activeTab === 'subscribers' && (
                    <div className="bg-white rounded-3xl p-6 border border-[#E8E4DF] shadow-sm space-y-4">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#E8E4DF] pb-4">
                            <div>
                                <h3 className="font-serif-heading text-2xl text-[#262422]">Subscribers — Pending Review</h3>
                                <p className="text-xs text-[#6B6862]">
                                    Students who subscribed via homepage. Approve to enable notifications, decline to block spam.
                                </p>
                            </div>
                            <span className="px-3 py-1 rounded-full bg-[#FAF0EB] text-[#B56E4D] border border-[#ECCEC1] text-xs font-semibold">
                                {pendingStudents.length} pending
                            </span>
                        </div>

                        {pendingStudents.length === 0 ? (
                            <div className="py-12 text-center text-[#6B6862] text-xs space-y-2">
                                <Clock3 className="w-8 h-8 text-[#DDD7CE] mx-auto" />
                                <p>No pending subscriber requests.</p>
                                <p className="text-[11px]">Homepage subscriptions will appear here for admin review.</p>
                            </div>
                        ) : (
                            <div className="overflow-x-auto">
                                <table className="w-full text-left text-xs border-collapse">
                                    <thead>
                                        <tr className="border-b border-[#E8E4DF] text-[#6B6862] uppercase tracking-wider">
                                            <th className="py-3 px-3">Student ID</th>
                                            <th className="py-3 px-3">Name</th>
                                            <th className="py-3 px-3">Program / Year</th>
                                            <th className="py-3 px-3">Phone</th>
                                            <th className="py-3 px-3">Email</th>
                                            <th className="py-3 px-3 text-right">Review</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-[#E8E4DF]">
                                        {pendingStudents.map((s) => (
                                            <tr key={s.student_id} className="hover:bg-[#FAF9F6] transition">
                                                <td className="py-3 px-3 font-mono text-[11px] font-semibold text-[#262422]">{s.student_id}</td>
                                                <td className="py-3 px-3 font-semibold text-[#262422]">{s.lname}, {s.fname}{s.mname ? ` ${s.mname}` : ''}</td>
                                                <td className="py-3 px-3"><span className="px-2 py-0.5 rounded-md bg-[#FAF0EB] text-[#B56E4D] font-medium text-[10px]">{s.course} — {s.year} Year</span></td>
                                                <td className="py-3 px-3"><div className="flex items-center gap-1"><Phone className="w-3 h-3 shrink-0 text-[#1F9D55]" /><span>{s.phone}</span></div></td>
                                                <td className="py-3 px-3"><div className="flex items-center gap-1"><Mail className="w-3 h-3 shrink-0 text-[#1F9D55]" /><span className="break-all">{s.email}</span></div></td>
                                                <td className="py-3 px-3">
                                                    <div className="flex items-center justify-end gap-1">
                                                        <button onClick={() => handleApproveStudent(s.student_id)} className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#1F9D55] hover:bg-[#168044] text-white text-[11px] font-semibold" title="Approve">
                                                            <UserCheck className="w-3 h-3" /> Approve
                                                        </button>
                                                        <button onClick={() => handleDeclineStudent(s.student_id)} className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-white border border-[#ECCEC1] hover:bg-[#FAF0EB] text-[#9E5B3D] text-[11px] font-semibold" title="Decline">
                                                            <UserX className="w-3 h-3" /> Decline
                                                        </button>
                                                        <button onClick={() => handleDeleteStudent(s.student_id)} className="p-1.5 rounded-lg bg-white border border-[#E8E4DF] hover:bg-[#FAF0EB] text-[#9E5B3D]" title="Delete">
                                                            <Trash2 className="w-3.5 h-3.5" />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                        <p className="text-[11px] text-[#6B6862] bg-[#EAF8EF]/60 border border-[#B2E6C4] rounded-xl p-3">
                            <strong>Anti-spam:</strong> Only <em>Approved</em> students are notified. Declined requests are kept as <code className="font-mono bg-white px-1 rounded border">declined</code> and not notified.
                        </p>
                    </div>
                )}

                {/* Tab 6: Categories & Departments — managed taxonomy */}
                {activeTab === 'taxonomy' && (
                    <div className="space-y-6">
                        <div className="bg-white rounded-3xl p-6 border border-[#E8E4DF] shadow-sm">
                            <h3 className="font-serif-heading text-2xl text-[#262422]">
                                Categories & Departments
                            </h3>
                            <p className="text-xs text-[#6B6862]">
                                Manage the announcement categories and department list used across posting forms and filters.
                                Renaming updates existing records; entries in use cannot be deleted.
                            </p>
                        </div>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <TaxonomyManager
                                title="Announcement Categories"
                                description="Values offered in the announcement Category dropdown."
                                endpoint="/api/categories"
                                itemLabel="Category"
                                onChanged={() => { void loadData(); announceDataChange('taxonomy'); }}
                            />
                            <TaxonomyManager
                                title="Departments"
                                description="Values offered in announcement and event Department dropdowns."
                                endpoint="/api/departments"
                                itemLabel="Department"
                                onChanged={() => { void loadData(); announceDataChange('taxonomy'); }}
                            />
                        </div>
                    </div>
                )}

                {/* Tab 7: Notifications — read tracking and reminders */}
                {activeTab === 'notifications' && (
                    <NotificationBlasts />
                )}
            </main>

            {confirmAction && (
                <ConfirmDialog
                    isOpen
                    title={confirmDialogCopy(confirmAction.action).title}
                    confirmLabel={confirmDialogCopy(confirmAction.action).confirmLabel}
                    tone={confirmDialogCopy(confirmAction.action).tone}
                    message={
                        <>
                            &ldquo;<strong>{confirmAction.label}</strong>&rdquo; will be{' '}
                            {confirmAction.action === 'decline-student' ? 'declined and kept on record' : 'permanently removed'}.
                            This cannot be undone.
                        </>
                    }
                    onConfirm={() => void runConfirmAction()}
                    onCancel={() => setConfirmAction(null)}
                />
            )}
        </div>
    );
}
