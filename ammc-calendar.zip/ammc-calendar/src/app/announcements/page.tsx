'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import AnnouncementCard from '@/components/AnnouncementCard';
import AnnouncementModal from '@/components/AnnouncementModal';
import AdminAuthModal from '@/components/AdminAuthModal';
import {
  Announcement,
  UrgencyLevel,
  AdminUser,
  DEFAULT_ANNOUNCEMENT_CATEGORIES,
  DEFAULT_DEPARTMENTS,
} from '@/types';
import {
  Bell,
  Search,
  Filter,
  Bookmark,
  RefreshCw,
  Pin,
  ArrowLeft,
  Sparkles,
  School,
  ChevronDown,
  X,
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { subscribeDataChanges } from '@/lib/data-refresh';

const ALL_CATEGORIES_LABEL = 'All';

// Surfaced as quick pills; the full list stays in the filter dropdown.
const HOT_CATEGORIES = ['Academic', 'Campus Advisory', 'Student Affairs', 'Scholarships & Grants'];

export default function AnnouncementsPage() {
  const router = useRouter();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [categoryOptions, setCategoryOptions] = useState<string[]>([ALL_CATEGORIES_LABEL, ...DEFAULT_ANNOUNCEMENT_CATEGORIES]);
  const [selectedDepartment, setSelectedDepartment] = useState<string>('All Departments');
  const [departmentOptions, setDepartmentOptions] = useState<string[]>([...DEFAULT_DEPARTMENTS]);
  const [selectedUrgency, setSelectedUrgency] = useState<UrgencyLevel | 'All'>('All');
  const [onlyBookmarked, setOnlyBookmarked] = useState(false);
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [activeAnnouncement, setActiveAnnouncement] = useState<Announcement | null>(null);
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  const activeFilterCount =
    (selectedCategory !== 'All' ? 1 : 0) +
    (selectedDepartment !== 'All Departments' ? 1 : 0) +
    (selectedUrgency !== 'All' ? 1 : 0) +
    (onlyBookmarked ? 1 : 0);

  const clearFilters = () => {
    setSelectedCategory('All');
    setSelectedDepartment('All Departments');
    setSelectedUrgency('All');
    setOnlyBookmarked(false);
  };
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);

  // Load managed taxonomy for filters.
  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      void (async () => {
        try {
          const [catRes, deptRes] = await Promise.all([
            fetch('/api/categories'),
            fetch('/api/departments'),
          ]);
          const catData = await catRes.json();
          const deptData = await deptRes.json();
          if (Array.isArray(catData.categories) && catData.categories.length > 0) {
            setCategoryOptions([ALL_CATEGORIES_LABEL, ...catData.categories.map((c: { name: string }) => c.name)]);
          }
          if (Array.isArray(deptData.departments) && deptData.departments.length > 0) {
            setDepartmentOptions(deptData.departments.map((d: { name: string }) => d.name));
          }
        } catch {
          // keep defaults
        }
      })();
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  // Load bookmarks
  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      try {
        const stored = localStorage.getItem('ammc_bookmarked_announcements');
        if (stored) setBookmarkedIds(JSON.parse(stored));
      } catch {
        // ignore
      }
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  // Check auth
  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => {
        if (data.authenticated && data.user) {
          setCurrentUser(data.user);
        }
      })
      .catch(() => {});
  }, []);

  const loadAnnouncements = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/announcements');
      const data = await res.json();
      if (data.announcements) {
        setAnnouncements(data.announcements);
      }
    } catch (e) {
      console.error('Failed to load announcements:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      void loadAnnouncements();
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  // Refresh when an announcement is posted/edited/deleted.
  useEffect(
    () =>
      subscribeDataChanges((kind) => {
        if (kind === 'announcement') void loadAnnouncements();
      }),
    []
  );

  const handleToggleBookmark = (id: string) => {
    setBookmarkedIds((prev) => {
      const updated = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
      try {
        localStorage.setItem('ammc_bookmarked_announcements', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
  };

  const handleLogout = async () => {
    await fetch('/api/auth/me', { method: 'POST' });
    setCurrentUser(null);
  };

  const filteredAnnouncements = announcements.filter((ann) => {
    if (selectedCategory !== 'All' && ann.category !== selectedCategory) return false;
    if (selectedDepartment !== 'All Departments' && ann.department !== selectedDepartment) return false;
    if (selectedUrgency !== 'All' && ann.urgency !== selectedUrgency) return false;
    if (onlyBookmarked && !bookmarkedIds.includes(ann.id)) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        ann.title.toLowerCase().includes(q) ||
        ann.summary.toLowerCase().includes(q) ||
        ann.content.toLowerCase().includes(q) ||
        ann.department.toLowerCase().includes(q);
      if (!match) return false;
    }

    return true;
  });

  return (
    <div className="min-h-screen bg-[#FAF9F6] flex flex-col font-sans-ui text-[#3C3A36]">
      <Navbar
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        currentUser={currentUser}
        onLogout={handleLogout}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex-1 w-full py-8 space-y-8">
        {/* Page Header */}
        <div className="border-b border-[#E8E4DF] pb-5 space-y-2">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1F9D55] hover:text-[#3C3A36] mb-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Campus Home</span>
          </Link>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-[#1F9D55] uppercase tracking-wider block mb-1">
                Institutional Circulars & Memoranda
              </span>
              <h1 className="font-serif-heading text-3xl sm:text-5xl text-[#262422]">
                School Announcements & Advisories
              </h1>
            </div>

            <div className="text-xs text-[#6B6862]">
              Showing <strong>{filteredAnnouncements.length}</strong> of {announcements.length} published bulletins
            </div>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="bg-white p-4 rounded-3xl border border-[#E8E4DF] shadow-sm space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Quick-access categories */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
              {(['All', ...HOT_CATEGORIES] as string[]).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                    selectedCategory === cat
                      ? 'bg-[#1F9D55] text-[#FAF9F6] shadow-xs'
                      : 'bg-[#FAF9F6] text-[#6B6862] hover:text-[#3C3A36] border border-[#E8E4DF]'
                  }`}
                >
                  {cat === 'All' ? 'All Bulletins' : cat}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setIsFilterPanelOpen((v) => !v)}
                aria-expanded={isFilterPanelOpen}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition ${
                  activeFilterCount > 0
                    ? 'bg-[#1F9D55] border-[#168044] text-[#FAF9F6]'
                    : 'bg-[#FAF9F6] border-[#E8E4DF] text-[#6B6862] hover:text-[#3C3A36]'
                }`}
              >
                <Filter className="w-3.5 h-3.5" />
                <span>{activeFilterCount > 0 ? `Filter · ${activeFilterCount}` : 'Filter'}</span>
                <ChevronDown className={`w-3 h-3 transition-transform ${isFilterPanelOpen ? 'rotate-180' : ''}`} />
              </button>

              {activeFilterCount > 0 && (
                <button
                  onClick={clearFilters}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium bg-[#FAF0EB] border border-[#ECCEC1] text-[#9E5B3D] transition hover:bg-[#F8E3D8]"
                >
                  <X className="w-3 h-3" />
                  <span>Clear</span>
                </button>
              )}

              <button
                onClick={loadAnnouncements}
                className="p-2 rounded-full bg-[#FAF9F6] border border-[#E8E4DF] hover:bg-[#EAF8EF] text-[#6B6862] hover:text-[#3C3A36] transition"
                title="Refresh"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          {/* Expanded filter panel */}
          {isFilterPanelOpen && (
            <div className="pt-3 border-t border-[#E8E4DF] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 animate-fade-in">
              <label className="space-y-1">
                <span className="text-[11px] font-semibold text-[#6B6862]">Department</span>
                <select
                  value={selectedDepartment}
                  onChange={(e) => setSelectedDepartment(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                >
                  {departmentOptions.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-[11px] font-semibold text-[#6B6862]">Urgency</span>
                <select
                  value={selectedUrgency}
                  onChange={(e) => setSelectedUrgency(e.target.value as UrgencyLevel | 'All')}
                  className="w-full px-3 py-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                >
                  <option value="All">All Urgencies</option>
                  <option value="critical">Critical Urgency</option>
                  <option value="important">Important Advisory</option>
                  <option value="normal">Normal</option>
                </select>
              </label>

              <label className="space-y-1">
                <span className="text-[11px] font-semibold text-[#6B6862]">Category</span>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                >
                  {categoryOptions.map((c) => (
                    <option key={c} value={c}>
                      {c === 'All' ? 'All Categories' : c}
                    </option>
                  ))}
                </select>
              </label>

              <div className="space-y-1">
                <span className="text-[11px] font-semibold text-[#6B6862]">Bookmarks</span>
                <button
                  onClick={() => setOnlyBookmarked(!onlyBookmarked)}
                  className={`w-full flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium border transition ${
                    onlyBookmarked
                      ? 'bg-[#1F9D55] border-[#168044] text-[#FAF9F6]'
                      : 'bg-[#FAF9F6] border border-[#E8E4DF] text-[#6B6862] hover:text-[#3C3A36]'
                  }`}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${onlyBookmarked ? 'fill-current' : ''}`} />
                  <span>Saved only ({bookmarkedIds.length})</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 py-8">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div
                key={n}
                className="natural-card rounded-3xl p-6 h-64 animate-pulse bg-white space-y-4"
              >
                <div className="w-24 h-4 bg-[#EAF8EF] rounded-full" />
                <div className="w-3/4 h-6 bg-[#EAF8EF] rounded-lg" />
                <div className="space-y-2">
                  <div className="w-full h-3 bg-[#EAF8EF] rounded-md" />
                  <div className="w-5/6 h-3 bg-[#EAF8EF] rounded-md" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredAnnouncements.length === 0 ? (
          <div className="py-16 text-center bg-white rounded-3xl border border-[#E8E4DF] p-8 space-y-3">
            <Bell className="w-10 h-10 text-[#DDD7CE] mx-auto" />
            <h3 className="font-serif-heading text-xl text-[#262422]">
              No Announcements Matching Criteria
            </h3>
            <p className="text-xs text-[#6B6862] max-w-sm mx-auto">
              Please adjust your active category, department, or search filters.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSelectedDepartment('All Departments');
                setSelectedUrgency('All');
                setOnlyBookmarked(false);
                setSearchQuery('');
              }}
              className="text-xs font-semibold px-4 py-2 rounded-full bg-[#FAF9F6] border border-[#E8E4DF] hover:bg-[#F2EFE9] text-[#3C3A36]"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAnnouncements.map((announcement) => (
              <AnnouncementCard
                key={announcement.id}
                announcement={announcement}
                onOpen={(ann) => setActiveAnnouncement(ann)}
                isBookmarked={bookmarkedIds.includes(announcement.id)}
                onToggleBookmark={handleToggleBookmark}
              />
            ))}
          </div>
        )}
      </main>

      {/* Modals */}
      <AnnouncementModal
        isOpen={!!activeAnnouncement}
        announcement={activeAnnouncement}
        onClose={() => setActiveAnnouncement(null)}
        isAdmin={!!currentUser}
        onEdit={(ann) => {
          setActiveAnnouncement(null);
          router.push(`/admin?tab=announcements&edit=${encodeURIComponent(ann.id)}`);
        }}
      />

      <AdminAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={(user) => setCurrentUser(user)}
      />
    </div>
  );
}
