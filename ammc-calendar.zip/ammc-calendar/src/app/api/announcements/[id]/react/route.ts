import { NextResponse } from 'next/server';
import { reactToAnnouncement } from '@/lib/db';

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { type } = await request.json();

    if (!['helpful', 'heart', 'celebrate'].includes(type)) {
      return NextResponse.json({ error: 'Invalid reaction type.' }, { status: 400 });
    }

    const reactions = await reactToAnnouncement(id, type as 'helpful' | 'heart' | 'celebrate');
    return NextResponse.json({ success: true, reactions });
  } catch (error) {
    console.error('Error reacting to announcement:', error);
    return NextResponse.json({ error: 'Failed to record reaction.' }, { status: 500 });
  }
}
