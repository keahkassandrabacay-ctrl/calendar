import { NextResponse } from 'next/server';
import { markAnnouncementsRead } from '@/lib/db';

// Called when a device views the announcements list. Marks everything published
// up to now as read and returns the remaining unread count so the client can
// reconcile the OS badge in the same round trip.
export async function POST(request: Request) {
    try {
        const body = await request.json();
        const deviceId = body?.deviceId;
        if (typeof deviceId !== 'string' || deviceId.length === 0 || deviceId.length > 64) {
            return NextResponse.json({ error: 'Invalid device id.' }, { status: 400 });
        }
        const unread = await markAnnouncementsRead(deviceId);
        return NextResponse.json({ success: true, unread });
    } catch (error) {
        console.error('Error marking announcements read:', error);
        return NextResponse.json({ error: 'Failed to mark announcements read.' }, { status: 500 });
    }
}