import { NextResponse } from 'next/server';
import { fetchAnnouncements } from '@/lib/db';
import { buildAnnouncementPdf, buildSingleAnnouncementPdf } from '@/lib/pdf';

// GET /api/announcements/pdf          -> all published announcements in one PDF
// GET /api/announcements/pdf?id=<id>  -> a single circular
//
// Public on purpose: bulletins are public content (the same data is served by
// GET /api/announcements), and students/parents export them from the calendar.
export async function GET(request: Request) {
    try {
        const { searchParams } = new URL(request.url);
        const id = searchParams.get('id');
        const announcements = await fetchAnnouncements();

        if (id) {
            const found = announcements.find((a) => a.id === id);
            if (!found) {
                return NextResponse.json({ error: 'Announcement not found.' }, { status: 404 });
            }
            const bytes = await buildSingleAnnouncementPdf(found);
            const safe = found.slug || found.id;
            return new NextResponse(Buffer.from(bytes), {
                headers: {
                    'Content-Type': 'application/pdf',
                    'Content-Disposition': `attachment; filename="ammc-announcement-${safe}.pdf"`,
                    'Content-Length': String(bytes.byteLength),
                },
            });
        }

        const bytes = await buildAnnouncementPdf(announcements);
        const stamp = new Date().toISOString().slice(0, 10);
        return new NextResponse(Buffer.from(bytes), {
            headers: {
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename="ammc-announcements-${stamp}.pdf"`,
                'Content-Length': String(bytes.byteLength),
            },
        });
    } catch (error) {
        console.error('Error generating announcement PDF:', error);
        return NextResponse.json({ error: 'Failed to generate PDF.' }, { status: 500 });
    }
}