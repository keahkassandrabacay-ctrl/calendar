import { NextResponse } from 'next/server';
import { getUnreadCount } from '@/lib/db';

// Unread count for the navbar badge and the installed app's icon badge.
// Unread means "published after this device last viewed the announcements list",
// tracked in announcement_reads — not a rolling time window, so it only grows
// when something is actually posted and clears when the list is read.
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const deviceId = searchParams.get('deviceId');
    const count = await getUnreadCount(deviceId);
    return NextResponse.json({ count });
  } catch (error) {
    console.error('Error fetching unread announcement count:', error);
    return NextResponse.json({ error: 'Failed to fetch count.', count: 0 }, { status: 500 });
  }
}