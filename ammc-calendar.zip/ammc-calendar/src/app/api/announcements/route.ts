import { NextResponse } from 'next/server';
import { after } from 'next/server';
import { cookies } from 'next/headers';
import { fetchAnnouncements, createAnnouncement, deleteAnnouncement, updateAnnouncement, fetchTaxonomy } from '@/lib/db';
import { verifyAdminToken } from '@/lib/auth';
import { notifyNewAnnouncement } from '@/lib/notifications';
import { broadcastAnnouncement } from '@/lib/push';

async function assertKnownTaxonomy(category: unknown, department: unknown): Promise<string | null> {
  if (typeof category !== 'string' || !category.trim()) return 'Announcement category is required.';
  if (typeof department !== 'string' || !department.trim()) return 'Announcement department is required.';
  const [categories, departments] = await Promise.all([fetchTaxonomy('categories'), fetchTaxonomy('departments')]);
  if (!categories.some((c) => c.name === category)) {
    return `Unknown category "${category}". Add it under Admin → Categories first.`;
  }
  if (!departments.some((d) => d.name === department)) {
    return `Unknown department "${department}". Add it under Admin → Categories first.`;
  }
  return null;
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const department = searchParams.get('department');
    const urgency = searchParams.get('urgency');
    const audience = searchParams.get('audience');
    const search = searchParams.get('search')?.toLowerCase();

    let announcements = await fetchAnnouncements();

    if (category && category !== 'All') {
      announcements = announcements.filter((a) => a.category === category);
    }
    if (department && department !== 'All Departments') {
      announcements = announcements.filter((a) => a.department === department);
    }
    if (urgency && urgency !== 'All') {
      announcements = announcements.filter((a) => a.urgency === urgency);
    }
    if (audience && audience !== 'All Campus') {
      announcements = announcements.filter((a) => a.audience === audience || a.audience === 'All Campus');
    }
    if (search) {
      announcements = announcements.filter(
        (a) =>
          a.title.toLowerCase().includes(search) ||
          a.summary.toLowerCase().includes(search) ||
          a.content.toLowerCase().includes(search) ||
          a.department.toLowerCase().includes(search)
      );
    }

    return NextResponse.json({ announcements });
  } catch (error) {
    console.error('Error fetching announcements:', error);
    return NextResponse.json({ error: 'Failed to fetch announcements.' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('ammc_admin_token')?.value ||
      request.headers.get('Authorization')?.replace('Bearer ', '');

    const user = token ? verifyAdminToken(token) : null;
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized. Admin credentials required.' }, { status: 401 });
    }

    const body = await request.json();
    const { title, summary, content, category, department, audience, urgency, is_pinned, attachments, issue_date } = body;

    if (!title || !content || !category || !department) {
      return NextResponse.json({ error: 'Missing required announcement fields.' }, { status: 400 });
    }

    const taxonomyError = await assertKnownTaxonomy(category, department);
    if (taxonomyError) {
      return NextResponse.json({ error: taxonomyError }, { status: 400 });
    }

    const slug = title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');

    const created = await createAnnouncement({
      title,
      slug,
      summary: summary || title,
      content,
      category,
      department,
      audience: audience || 'All Campus',
      urgency: urgency || 'normal',
      is_pinned: Boolean(is_pinned),
      is_published: true,
      author_name: user.name || 'AMMC Administration',
      attachments: attachments || [],
      ...(issue_date ? { issue_date: new Date(issue_date).toISOString() } : {}),
    });

    // Notify in the background so posting never blocks on the SMS/email blast.
    after(async () => {
      try {
        const notifyResult = await notifyNewAnnouncement({
          id: created.id,
          title: created.title,
          summary: created.summary,
          category: created.category,
          department: created.department,
          audience: created.audience,
          urgency: created.urgency,
        });
        console.log(`[NOTIFY] Announcement notify done:`, notifyResult);
      } catch (notifyErr) {
        console.error('[NOTIFY] notifyNewAnnouncement failed:', notifyErr);
      }

      // Web Push drives the installed PWA's taskbar badge and toast, which is
      // the only channel that reaches a closed app.
      try {
        const pushResult = await broadcastAnnouncement({
          title: created.title,
          body: created.summary || 'A new announcement was posted.',
          url: '/announcements',
          tag: `announcement-${created.id}`,
        });
        console.log('[PUSH] Announcement push done:', pushResult);
      } catch (pushErr) {
        console.error('[PUSH] broadcastAnnouncement failed:', pushErr);
      }
    });

    return NextResponse.json({ success: true, announcement: created, notificationsQueued: true }, { status: 201 });
  } catch (error) {
    console.error('Error creating announcement:', error);
    return NextResponse.json({ error: 'Failed to create announcement.' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('ammc_admin_token')?.value ||
      request.headers.get('Authorization')?.replace('Bearer ', '');

    const user = token ? verifyAdminToken(token) : null;
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized. Admin credentials required.' }, { status: 401 });
    }

    const body = await request.json();
    const { id, title, summary, content, category, department, audience, urgency, is_pinned, is_published, attachments, issue_date } = body ?? {};

    if (!id) {
      return NextResponse.json({ error: 'Announcement ID is required.' }, { status: 400 });
    }

    if (category !== undefined || department !== undefined) {
      const existing = await fetchAnnouncements();
      const current = existing.find((a) => a.id === id);
      if (!current) {
        return NextResponse.json({ error: `Announcement with ID "${id}" was not found.` }, { status: 404 });
      }
      const taxonomyError = await assertKnownTaxonomy(
        category ?? current.category,
        department ?? current.department
      );
      if (taxonomyError) {
        return NextResponse.json({ error: taxonomyError }, { status: 400 });
      }
    }

    const updates: Parameters<typeof updateAnnouncement>[1] = {};
    if (title !== undefined) {
      updates.title = title;
      updates.slug = String(title).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    }
    if (summary !== undefined) updates.summary = summary;
    if (content !== undefined) updates.content = content;
    if (category !== undefined) updates.category = category;
    if (department !== undefined) updates.department = department;
    if (audience !== undefined) updates.audience = audience;
    if (urgency !== undefined) updates.urgency = urgency;
    if (is_pinned !== undefined) updates.is_pinned = Boolean(is_pinned);
    if (is_published !== undefined) updates.is_published = Boolean(is_published);
    if (attachments !== undefined) updates.attachments = attachments;
    if (issue_date !== undefined) updates.issue_date = issue_date;

    // NOTE: edits intentionally do not re-trigger SMS/email notifications.
    const updated = await updateAnnouncement(String(id), updates);
    return NextResponse.json({ success: true, announcement: updated });
  } catch (error) {
    const msg = error instanceof Error ? error.message : 'Failed to update announcement.';
    const status = msg.includes('was not found') ? 404 : msg === 'No fields to update.' ? 400 : 500;
    console.error('Error updating announcement:', error);
    return NextResponse.json({ error: msg }, { status });
  }
}

export async function DELETE(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('ammc_admin_token')?.value ||
      request.headers.get('Authorization')?.replace('Bearer ', '');

    const user = token ? verifyAdminToken(token) : null;
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized.' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Announcement ID is required.' }, { status: 400 });
    }

    await deleteAnnouncement(id);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting announcement:', error);
    return NextResponse.json({ error: 'Failed to delete announcement.' }, { status: 500 });
  }
}
