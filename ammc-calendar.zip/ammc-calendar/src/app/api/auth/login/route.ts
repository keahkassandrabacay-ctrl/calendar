import { NextResponse } from 'next/server';
import { authenticateAdminCredentials, signAdminToken } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json();

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required.' },
        { status: 400 }
      );
    }

    const admin = authenticateAdminCredentials(email, password);

    if (!admin) {
      return NextResponse.json(
        { error: 'Invalid credentials. Try admin@ammc.edu.ph with admin123' },
        { status: 401 }
      );
    }

    const token = signAdminToken(admin);

    const response = NextResponse.json({
      success: true,
      user: admin,
      token,
    });

    // Set HTTP-only cookie for secure session
    response.cookies.set('ammc_admin_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7, // 7 days
      path: '/',
    });

    return response;
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: 'An unexpected error occurred during login.' },
      { status: 500 }
    );
  }
}
