import { taxonomyHandlers } from '@/lib/taxonomy-api';

export const { GET, POST, PATCH, DELETE } = taxonomyHandlers('departments', 'Department');
