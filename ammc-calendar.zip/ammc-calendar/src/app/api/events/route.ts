import { NextResponse } from 'next/server';
import { after } from 'next/server';
import { cookies } from 'next/headers';
import { fetchEvents, createEvent, deleteEvent, updateEvent, fetchTaxonomy } from '@/lib/db';
import { verifyAdminToken } from '@/lib/auth';
import { notifyNewEvent } from '@/lib/notifications';

async function assertKnownDepartment(department: unknown): Promise<string | null> {
  if (typeof department !== 'string' || !department.trim()) return null; // defaults apply
  const departments = await fetchTaxonomy('departments');
  if (!departments.some((d) => d.name === department)) {
    return `Unknown department "${department}". Add it under Admin → Categories first.`;
  }
  return null;
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const department = searchParams.get('department');
    const search = searchParams.get('search')?.toLowerCase();

    let events = await fetchEvents();

    if (category && category !== 'All') {
      events = events.filter((e) => e.category === category);
    }
    if (department && department !== 'All Departments') {
      events = events.filter((e) => e.department === department);
    }
    if (search) {
      events = events.filter(
        (e) =>
          e.title.toLowerCase().includes(search) ||
          e.description.toLowerCase().includes(search) ||
          e.location.toLowerCase().includes(search)
      );
    }

    return NextResponse.json({ events });
  } catch (error) {
    console.error('Error fetching events:', error);
    return NextResponse.json({ error: 'Failed to fetch events.' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('ammc_admin_token')?.value ||
      request.headers.get('Authorization')?.replace('Bearer ', '');

    const user = token ? verifyAdminToken(token) : null;
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized. Admin credentials required.' }, { status: 401 });
    }

    const body = await request.json();
    const {
      title,
      description,
      location,
      category,
      start_time,
      end_time,
      capacity,
      is_featured,
      organizer,
      target_audience,
      department,
      banner_color,
    } = body;

    if (!title || !start_time || !end_time || !category) {
      return NextResponse.json({ error: 'Missing required event fields.' }, { status: 400 });
    }
    // Venue optional for Holidays & Observances — defaults to Nationwide Observance
    const isHolidayCategory = category === 'Holidays & Observances';
    if (!location && !isHolidayCategory) {
      return NextResponse.json({ error: 'Venue / Location is required for non-holiday events.' }, { status: 400 });
    }
    const locationToSave = (location && String(location).trim()) || (isHolidayCategory ? 'Nationwide Observance' : '');

    if (department) {
      const deptError = await assertKnownDepartment(department);
      if (deptError) {
        return NextResponse.json({ error: deptError }, { status: 400 });
      }
    }

    const created = await createEvent({
      title,
      description: description || '',
      location: locationToSave,
      category,
      start_time,
      end_time,
      capacity: Number(capacity) || 0,
      is_featured: Boolean(is_featured),
      organizer: organizer || user.name || 'AMMC',
      target_audience: target_audience || 'All Campus',
      department: department || 'All Departments',
      banner_color: banner_color || '#1F9D55',
    });

    // Notify in the background so posting never blocks on the SMS/email blast.
    after(async () => {
      try {
        const notifyResult = await notifyNewEvent({
          id: created.id,
          title: created.title,
          description: created.description,
          location: created.location,
          category: created.category,
          start_time: created.start_time,
          end_time: created.end_time,
          target_audience: created.target_audience,
          department: created.department,
        });
        console.log(`[NOTIFY] Event notify done:`, notifyResult);
      } catch (notifyErr) {
        console.error('[NOTIFY] notifyNewEvent failed:', notifyErr);
      }
    });

    return NextResponse.json({ success: true, event: created, notificationsQueued: true }, { status: 201 });
  } catch (error) {
    console.error('Error creating event:', error);
    return NextResponse.json({ error: 'Failed to create event.' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('ammc_admin_token')?.value ||
      request.headers.get('Authorization')?.replace('Bearer ', '');

    const user = token ? verifyAdminToken(token) : null;
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized. Admin credentials required.' }, { status: 401 });
    }

    const body = await request.json();
    const {
      id, title, description, location, category, start_time, end_time,
      capacity, is_featured, organizer, target_audience, department, banner_color,
    } = body ?? {};

    if (!id) {
      return NextResponse.json({ error: 'Event ID is required.' }, { status: 400 });
    }
    if (department !== undefined) {
      const deptError = await assertKnownDepartment(department);
      if (deptError) {
        return NextResponse.json({ error: deptError }, { status: 400 });
      }
    }

    const updates: Parameters<typeof updateEvent>[1] = {};
    if (title !== undefined) updates.title = title;
    if (description !== undefined) updates.description = description;
    if (location !== undefined) updates.location = location;
    if (category !== undefined) updates.category = category;
    if (start_time !== undefined) updates.start_time = start_time;
    if (end_time !== undefined) updates.end_time = end_time;
    if (capacity !== undefined) updates.capacity = Number(capacity) || 0;
    if (is_featured !== undefined) updates.is_featured = Boolean(is_featured);
    if (organizer !== undefined) updates.organizer = organizer;
    if (target_audience !== undefined) updates.target_audience = target_audience;
    if (department !== undefined) updates.department = department;
    if (banner_color !== undefined) updates.banner_color = banner_color;

    // NOTE: edits intentionally do not re-trigger SMS/email notifications.
    const updated = await updateEvent(String(id), updates);
    return NextResponse.json({ success: true, event: updated });
  } catch (error) {
    const msg = error instanceof Error ? error.message : 'Failed to update event.';
    const status = msg.includes('was not found') ? 404 : msg === 'No fields to update.' ? 400 : 500;
    console.error('Error updating event:', error);
    return NextResponse.json({ error: msg }, { status });
  }
}

export async function DELETE(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('ammc_admin_token')?.value ||
      request.headers.get('Authorization')?.replace('Bearer ', '');

    const user = token ? verifyAdminToken(token) : null;
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized.' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Event ID is required.' }, { status: 400 });
    }

    await deleteEvent(id);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting event:', error);
    return NextResponse.json({ error: 'Failed to delete event.' }, { status: 500 });
  }
}
