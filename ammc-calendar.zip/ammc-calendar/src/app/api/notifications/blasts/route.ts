import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { verifyAdminToken } from '@/lib/auth';
import { fetchBlastStats, fetchNonOpeners, BlastKind } from '@/lib/db';

// Blast engagement stats are public (counts only, no personal data).
// The per-recipient non-opener lookup requires admin auth.
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const kind = searchParams.get('kind') as BlastKind | null;
    const refId = searchParams.get('refId');

    if (kind && refId) {
      if (kind !== 'announcement' && kind !== 'event') {
        return NextResponse.json({ error: 'Invalid kind.' }, { status: 400 });
      }
      const cookieStore = await cookies();
      const token =
        cookieStore.get('ammc_admin_token')?.value ||
        request.headers.get('Authorization')?.replace('Bearer ', '');
      const user = token ? verifyAdminToken(token) : null;
      if (!user) {
        return NextResponse.json({ error: 'Unauthorized. Admin credentials required.' }, { status: 401 });
      }
      const nonOpeners = await fetchNonOpeners(kind, refId);
      return NextResponse.json({
        nonOpeners: nonOpeners.map((e) => ({
          email: e.student_email,
          sent_at: e.sent_at,
          reminders_sent: e.reminders_sent,
          last_reminder_at: e.last_reminder_at,
        })),
      });
    }

    const blasts = await fetchBlastStats();
    return NextResponse.json({ blasts });
  } catch (error) {
    console.error('Error fetching blast stats:', error);
    return NextResponse.json({ error: 'Failed to fetch notification stats.' }, { status: 500 });
  }
}
