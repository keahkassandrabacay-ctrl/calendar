import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { verifyAdminToken } from '@/lib/auth';
import { remindNonOpeners, REMINDER_DEFAULT_MIN_AGE_DAYS, REMINDER_DEFAULT_MAX } from '@/lib/notifications';
import { BlastKind } from '@/lib/db';

// One-click reminder blast to non-openers. Admin only. Email only (SMS costs
// per message; email is free). Eligibility (blast age + per-recipient cap) is
// enforced server-side regardless of what the UI requests.
export async function POST(request: Request) {
  try {
    const cookieStore = await cookies();
    const token =
      cookieStore.get('ammc_admin_token')?.value ||
      request.headers.get('Authorization')?.replace('Bearer ', '');
    const user = token ? verifyAdminToken(token) : null;
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized. Admin credentials required.' }, { status: 401 });
    }

    const body = await request.json();
    const { kind, refId, minAgeDays, maxReminders } = body ?? {};
    if ((kind !== 'announcement' && kind !== 'event') || !refId) {
      return NextResponse.json({ error: 'Valid kind and refId are required.' }, { status: 400 });
    }

    const result = await remindNonOpeners(
      kind as BlastKind,
      String(refId),
      minAgeDays === undefined ? REMINDER_DEFAULT_MIN_AGE_DAYS : Number(minAgeDays),
      maxReminders === undefined ? REMINDER_DEFAULT_MAX : Number(maxReminders)
    );
    return NextResponse.json({ success: true, ...result });
  } catch (error) {
    const msg = error instanceof Error ? error.message : 'Failed to send reminders.';
    const status = msg === 'Announcement not found.' || msg === 'Event not found.' ? 404 : 500;
    console.error('Error sending reminders:', error);
    return NextResponse.json({ error: msg }, { status });
  }
}
