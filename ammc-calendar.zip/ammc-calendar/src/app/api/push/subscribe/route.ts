import { NextResponse } from 'next/server';
import { upsertPushSubscription, deletePushSubscription } from '@/lib/db';
import { pushConfigured } from '@/lib/push';

// Chrome accepts a malformed applicationServerKey silently by subscribing to a
// key the server cannot encrypt for, which only fails later at send time.
const BASE64URL = /^[A-Za-z0-9_-]+={0,2}$/;

function validKey(value: unknown): value is string {
    return typeof value === 'string' && value.length > 0 && value.length <= 255 && BASE64URL.test(value);
}

export async function GET() {
    return NextResponse.json({
        configured: pushConfigured(),
        publicKey: process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY ?? null,
    });
}

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const endpoint = body?.endpoint;
        const deviceId = body?.deviceId;
        const p256dh = body?.keys?.p256dh;
        const auth = body?.keys?.auth;

        if (typeof endpoint !== 'string' || !/^https:\/\//.test(endpoint) || endpoint.length > 512) {
            return NextResponse.json({ error: 'Invalid push endpoint.' }, { status: 400 });
        }
        if (typeof deviceId !== 'string' || deviceId.length === 0 || deviceId.length > 64) {
            return NextResponse.json({ error: 'Invalid device id.' }, { status: 400 });
        }
        if (!validKey(p256dh) || !validKey(auth)) {
            return NextResponse.json({ error: 'Invalid subscription keys.' }, { status: 400 });
        }

        await upsertPushSubscription(endpoint, { p256dh, auth }, deviceId);
        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('Error saving push subscription:', error);
        return NextResponse.json({ error: 'Failed to save subscription.' }, { status: 500 });
    }
}

export async function DELETE(request: Request) {
    try {
        const body = await request.json();
        const endpoint = body?.endpoint;
        if (typeof endpoint !== 'string' || !/^https:\/\//.test(endpoint)) {
            return NextResponse.json({ error: 'Invalid push endpoint.' }, { status: 400 });
        }
        await deletePushSubscription(endpoint);
        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('Error removing push subscription:', error);
        return NextResponse.json({ error: 'Failed to remove subscription.' }, { status: 500 });
    }
}