import { NextResponse } from 'next/server';
import { getDbStatus, getPool } from '@/lib/db';
import { pushConfigured } from '@/lib/push';

// Health surface for the services that run off environment config rather than
// the database. Push silently disabling itself (missing VAPID keys) looks like a
// broken badge/app-notifications feature, so it is reported here instead.
function integrationsStatus() {
  return {
    push_notifications: pushConfigured() ? 'configured' : 'missing_vapid_keys',
    email_smtp: Boolean((process.env.SMTP_HOST || '').trim() && (process.env.SMTP_USER || '').trim()),
    sms_textbee: Boolean((process.env.TEXTBEE_API_KEY || '').trim()),
    app_url: (process.env.APP_URL || '').trim() || null,
  };
}

export async function GET() {
  try {
    const status = await getDbStatus();
    return NextResponse.json({ status, integrations: integrationsStatus() });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}

export async function POST() {
  try {
    await getPool();
    const status = await getDbStatus();
    return NextResponse.json({
      success: true,
      message: 'MySQL connection established and synchronized with XAMPP.',
      status,
      integrations: integrationsStatus(),
    });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
