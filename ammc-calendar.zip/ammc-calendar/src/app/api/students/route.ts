import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { fetchStudents, createStudent, deleteStudent, updateStudent } from '@/lib/db';
import { verifyAdminToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('ammc_admin_token')?.value || request.headers.get('Authorization')?.replace('Bearer ', '');
    const user = token ? verifyAdminToken(token) : null;
    if (!user) return NextResponse.json({ error: 'Unauthorized.' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search')?.toLowerCase();
    const course = searchParams.get('course');
    const year = searchParams.get('year');
    const status = searchParams.get('status') as 'pending' | 'approved' | 'declined' | null;

    let students = await fetchStudents(status || undefined);
    if (course && course !== 'All') students = students.filter((s) => s.course === course);
    if (year && year !== 'All') students = students.filter((s) => String(s.year) === year);
    if (search) {
      students = students.filter(
        (s) =>
          s.student_id.toLowerCase().includes(search) ||
          s.fname.toLowerCase().includes(search) ||
          s.lname.toLowerCase().includes(search) ||
          (s.mname && s.mname.toLowerCase().includes(search)) ||
          s.email.toLowerCase().includes(search) ||
          s.phone.includes(search) ||
          s.course.toLowerCase().includes(search)
      );
    }
    return NextResponse.json({ students });
  } catch (error) {
    console.error('Error fetching students:', error);
    return NextResponse.json({ error: 'Failed to fetch students.' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('ammc_admin_token')?.value || request.headers.get('Authorization')?.replace('Bearer ', '');
    const user = token ? verifyAdminToken(token) : null;
    if (!user) return NextResponse.json({ error: 'Unauthorized.' }, { status: 401 });

    const body = await request.json();
    const { student_id, fname, lname, mname, course, year, phone, email } = body;

    if (!student_id || !fname || !lname || !course || !year || !phone || !email) {
      return NextResponse.json({ error: 'Missing required student fields: student_id, fname, lname, course, year, phone, email.' }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'Invalid email format.' }, { status: 400 });
    }
    const yearNum = Number(year);
    if (!Number.isInteger(yearNum) || yearNum < 1 || yearNum > 6) {
      return NextResponse.json({ error: 'Year must be an integer 1-6.' }, { status: 400 });
    }

    const created = await createStudent({
      student_id: String(student_id).trim(),
      fname: String(fname).trim(),
      lname: String(lname).trim(),
      mname: mname ? String(mname).trim() : undefined,
      course: String(course).trim(),
      year: yearNum,
      phone: String(phone).trim(),
      email: String(email).trim().toLowerCase(),
    });

    return NextResponse.json({ success: true, student: created }, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : String(error);
    if (msg.includes('Duplicate entry') || msg.includes('UNIQUE')) {
      return NextResponse.json({ error: 'Student ID or email already exists.' }, { status: 409 });
    }
    console.error('Error creating student:', error);
    return NextResponse.json({ error: msg || 'Failed to create student.' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('ammc_admin_token')?.value || request.headers.get('Authorization')?.replace('Bearer ', '');
    const user = token ? verifyAdminToken(token) : null;
    if (!user) return NextResponse.json({ error: 'Unauthorized.' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Student ID is required.' }, { status: 400 });

    await deleteStudent(id);
    return NextResponse.json({ success: true });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : String(error);
    console.error('Error deleting student:', error);
    return NextResponse.json({ error: msg || 'Failed to delete student.' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('ammc_admin_token')?.value || request.headers.get('Authorization')?.replace('Bearer ', '');
    const user = token ? verifyAdminToken(token) : null;
    if (!user) return NextResponse.json({ error: 'Unauthorized.' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'Student ID is required.' }, { status: 400 });

    const body = await request.json();
    const allowed: Record<string, unknown> = {};
    for (const k of ['fname', 'lname', 'mname', 'course', 'year', 'phone', 'email', 'status'] as const) {
      if (body[k] !== undefined) allowed[k] = body[k];
    }
    if (allowed.year !== undefined) allowed.year = Number(allowed.year);
    if (allowed.email !== undefined) allowed.email = String(allowed.email).trim().toLowerCase();
    if (allowed.status !== undefined) {
      const s = String(allowed.status);
      if (!['pending', 'approved', 'declined'].includes(s)) {
        return NextResponse.json({ error: 'Invalid status.' }, { status: 400 });
      }
    }

    const updated = await updateStudent(id, allowed as never);
    return NextResponse.json({ success: true, student: updated });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : String(error);
    console.error('Error updating student:', error);
    return NextResponse.json({ error: msg || 'Failed to update student.' }, { status: 500 });
  }
}
