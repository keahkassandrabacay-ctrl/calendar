import { NextResponse } from 'next/server';
import { createSubscriptionRequest } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { student_id, fname, lname, mname, course, year, phone, email } = body;

    if (!student_id || !fname || !lname || !course || !year || !phone || !email) {
      return NextResponse.json({ error: 'Please fill all required fields: student ID, first name, last name, course, year, phone, email.' }, { status: 400 });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) {
      return NextResponse.json({ error: 'Invalid email format.' }, { status: 400 });
    }
    const yearNum = Number(year);
    if (!Number.isInteger(yearNum) || yearNum < 1 || yearNum > 6) {
      return NextResponse.json({ error: 'Year must be 1-6.' }, { status: 400 });
    }
    const phoneStr = String(phone).trim();
    if (phoneStr.length < 10) {
      return NextResponse.json({ error: 'Invalid phone number.' }, { status: 400 });
    }

    const created = await createSubscriptionRequest({
      student_id: String(student_id).trim(),
      fname: String(fname).trim(),
      lname: String(lname).trim(),
      mname: mname ? String(mname).trim() : undefined,
      course: String(course).trim(),
      year: yearNum,
      phone: phoneStr,
      email: String(email).trim().toLowerCase(),
    });

    return NextResponse.json({ success: true, message: 'Subscription request submitted! Please wait for admin approval.', student: created }, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : String(error);
    if (msg.includes('Duplicate entry') || msg.includes('UNIQUE')) {
      return NextResponse.json({ error: 'Student ID or email already exists. If you were declined, contact admin.' }, { status: 409 });
    }
    console.error('Error creating subscription request:', error);
    return NextResponse.json({ error: 'Failed to submit subscription. Please try again.' }, { status: 500 });
  }
}
