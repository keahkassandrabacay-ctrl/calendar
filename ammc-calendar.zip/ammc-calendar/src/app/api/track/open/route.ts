import { NextResponse } from 'next/server';
import { recordOpen } from '@/lib/db';

// 1x1 transparent GIF.
const PIXEL = Buffer.from('R0lGODlhAQABAIAAAP///////yH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==', 'base64');

// Open-tracking pixel for notification emails. No auth: mail clients (and
// Gmail's image proxy) fetch this URL anonymously. Unknown or already-opened
// tokens still return the pixel so email rendering never breaks.
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const token = searchParams.get('token') || '';
    await recordOpen(token);
  } catch {
    // Tracking must never break the response.
  }
  return new NextResponse(PIXEL, {
    status: 200,
    headers: {
      'Content-Type': 'image/gif',
      'Cache-Control': 'no-store, no-cache, must-revalidate',
      'Content-Length': String(PIXEL.length),
    },
  });
}
