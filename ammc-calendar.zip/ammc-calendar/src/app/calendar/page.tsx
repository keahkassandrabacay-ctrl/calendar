'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import CalendarView from '@/components/CalendarView';
import EventDetailModal from '@/components/EventDetailModal';
import AdminAuthModal from '@/components/AdminAuthModal';
import { SchoolEvent, AdminUser } from '@/types';
import { Calendar as CalendarIcon, ArrowLeft, Plus, Download, Sparkles } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { subscribeDataChanges } from '@/lib/data-refresh';

export default function CalendarPage() {
  const router = useRouter();
  const [events, setEvents] = useState<SchoolEvent[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeEvent, setActiveEvent] = useState<SchoolEvent | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Check auth
  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => {
        if (data.authenticated && data.user) {
          setCurrentUser(data.user);
        }
      })
      .catch(() => {});
  }, []);

  const loadEvents = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/events');
      const data = await res.json();
      if (data.events) {
        setEvents(data.events);
      }
    } catch (e) {
      console.error('Failed to load calendar events:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      void loadEvents();
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  useEffect(
    () =>
      subscribeDataChanges((kind) => {
        if (kind === 'event') void loadEvents();
      }),
    []
  );

  const handleLogout = async () => {
    await fetch('/api/auth/me', { method: 'POST' });
    setCurrentUser(null);
  };

  return (
    <div className="min-h-screen bg-[#FAF9F6] flex flex-col font-sans-ui text-[#3C3A36]">
      <Navbar
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        currentUser={currentUser}
        onLogout={handleLogout}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex-1 w-full py-8 space-y-6">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E8E4DF] pb-5">
          <div className="space-y-1">
            <Link
              href="/"
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#1F9D55] hover:text-[#3C3A36] mb-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Announcements Feed</span>
            </Link>
            <h1 className="font-serif-heading text-3xl sm:text-4xl text-[#262422]">
              AMMC Academic & Events Calendar
            </h1>
            <p className="text-xs text-[#6B6862]">
              Interactive schedule of lectures, examinations, symposiums, athletic games, and campus reservations.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {currentUser && (
              <Link
                href="/admin"
                className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-semibold shadow-xs transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Schedule Event</span>
              </Link>
            )}
          </div>
        </div>

        {/* Calendar Component */}
        {isLoading ? (
          <div className="h-96 rounded-3xl bg-white border border-[#E8E4DF] animate-pulse flex items-center justify-center">
            <div className="text-center space-y-2 text-[#6B6862] text-xs">
              <CalendarIcon className="w-8 h-8 text-[#1F9D55] mx-auto animate-bounce" />
              <p>Loading school schedule calendar...</p>
            </div>
          </div>
        ) : (
          <CalendarView
            events={events}
            onSelectEvent={(evt) => setActiveEvent(evt)}
          />
        )}
      </main>

      {/* Modals */}
      <EventDetailModal
        isOpen={!!activeEvent}
        event={activeEvent}
        onClose={() => setActiveEvent(null)}
        isAdmin={!!currentUser}
        onEdit={(evt) => {
          setActiveEvent(null);
          router.push(`/admin?tab=events&edit=${encodeURIComponent(evt.id)}`);
        }}
      />
<AdminAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={(user) => {
          setCurrentUser(user);
        }}
      />
    </div>
  );
}
