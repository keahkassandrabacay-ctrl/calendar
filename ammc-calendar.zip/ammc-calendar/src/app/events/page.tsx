'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import EventCard from '@/components/EventCard';
import EventDetailModal from '@/components/EventDetailModal';
import AdminAuthModal from '@/components/AdminAuthModal';
import { SchoolEvent, EventCategory, AdminUser } from '@/types';
import {
  Calendar,
  Sparkles,
  Filter,
  ArrowLeft,
  MapPin,
  Clock,
  Ticket,
  Search,
  RefreshCw,
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { subscribeDataChanges } from '@/lib/data-refresh';

const EVENT_CATEGORIES: Array<EventCategory | 'All'> = [
  'All',
  'Campus Life & Culture',
  'Athletics & Sports',
  'Seminars & Workshops',
  'Examinations',
  'Academic Calendar',
  'Alumni & Community',
];

export default function EventsPage() {
  const router = useRouter();
  const [events, setEvents] = useState<SchoolEvent[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<EventCategory | 'All'>('All');
  const [activeEvent, setActiveEvent] = useState<SchoolEvent | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);

  // Check auth
  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => {
        if (data.authenticated && data.user) {
          setCurrentUser(data.user);
        }
      })
      .catch(() => {});
  }, []);

  const loadEvents = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/events');
      const data = await res.json();
      if (data.events) {
        setEvents(data.events);
      }
    } catch (e) {
      console.error('Failed to load events:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      void loadEvents();
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  useEffect(
    () =>
      subscribeDataChanges((kind) => {
        if (kind === 'event') void loadEvents();
      }),
    []
  );

  const handleLogout = async () => {
    await fetch('/api/auth/me', { method: 'POST' });
    setCurrentUser(null);
  };

  const filteredEvents = events.filter((e) => {
    // Exclude purely administrative meetings & holidays if needed, or filter by category
    if (selectedCategory !== 'All' && e.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        e.title.toLowerCase().includes(q) ||
        e.description.toLowerCase().includes(q) ||
        e.location.toLowerCase().includes(q) ||
        e.organizer.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-[#FAF9F6] flex flex-col font-sans-ui text-[#3C3A36]">
      <Navbar
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        currentUser={currentUser}
        onLogout={handleLogout}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex-1 w-full py-8 space-y-8">
        {/* Page Header */}
        <div className="border-b border-[#E8E4DF] pb-5 space-y-2">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1F9D55] hover:text-[#3C3A36] mb-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Campus Home</span>
          </Link>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-[#1F9D55] uppercase tracking-wider block mb-1">
                Campus Activities & Gatherings
              </span>
              <h1 className="font-serif-heading text-3xl sm:text-5xl text-[#262422]">
                School Events & Programs
              </h1>
            </div>

            <Link
              href="/calendar"
              className="px-4 py-2 rounded-full bg-white border border-[#E8E4DF] hover:border-[#1F9D55] text-[#1F9D55] text-xs font-semibold shadow-xs transition"
            >
              Open Interactive Full Calendar
            </Link>
          </div>
        </div>

        {/* Category Filter Bar */}
        <div className="bg-white p-4 rounded-3xl border border-[#E8E4DF] shadow-sm flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
            {EVENT_CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                  selectedCategory === cat
                    ? 'bg-[#1F9D55] text-[#FAF9F6] shadow-xs'
                    : 'bg-[#FAF9F6] text-[#6B6862] hover:text-[#3C3A36] border border-[#E8E4DF]'
                  }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <button
            onClick={loadEvents}
            className="p-2 rounded-full bg-[#FAF9F6] border border-[#E8E4DF] hover:bg-[#EAF8EF] text-[#6B6862] transition"
            title="Refresh"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Events Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 py-8">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div
                key={n}
                className="natural-card rounded-3xl p-6 h-64 animate-pulse bg-white space-y-4"
              >
                <div className="w-16 h-16 bg-[#EAF8EF] rounded-2xl" />
                <div className="w-3/4 h-6 bg-[#EAF8EF] rounded-lg" />
                <div className="w-full h-3 bg-[#EAF8EF] rounded-md" />
              </div>
            ))}
          </div>
        ) : filteredEvents.length === 0 ? (
          <div className="py-16 text-center bg-white rounded-3xl border border-[#E8E4DF] p-8 space-y-3">
            <Calendar className="w-10 h-10 text-[#DDD7CE] mx-auto" />
            <h3 className="font-serif-heading text-xl text-[#262422]">
              No Events Found Matching Filter
            </h3>
            <p className="text-xs text-[#6B6862]">
              Please choose another category or clear your search term.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSearchQuery('');
              }}
              className="text-xs font-semibold px-4 py-2 rounded-full bg-[#FAF9F6] border border-[#E8E4DF] hover:bg-[#F2EFE9] text-[#3C3A36]"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map((evt) => (
              <EventCard
                key={evt.id}
                event={evt}
                onOpenDetail={(e) => setActiveEvent(e)}
              />
            ))}
          </div>
        )}
      </main>

      {/* Modals */}
      <EventDetailModal
        isOpen={!!activeEvent}
        event={activeEvent}
        onClose={() => setActiveEvent(null)}
        isAdmin={!!currentUser}
        onEdit={(evt) => {
          setActiveEvent(null);
          router.push(`/admin?tab=events&edit=${encodeURIComponent(evt.id)}`);
        }}
      />
<AdminAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={(user) => setCurrentUser(user)}
      />
    </div>
  );
}
