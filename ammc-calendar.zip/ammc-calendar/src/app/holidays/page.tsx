'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import AdminAuthModal from '@/components/AdminAuthModal';
import { SchoolEvent, AdminUser } from '@/types';
import { format, differenceInDays } from 'date-fns';
import {
 GraduationCap,
 Calendar,
 Sparkles,
 MapPin,
 Clock,
 ArrowLeft,
 Search,
 RefreshCw,
 Sun,
 ShieldCheck,
 CheckCircle2,
 AlertCircle,
} from 'lucide-react';
import Link from 'next/link';
import { subscribeDataChanges } from '@/lib/data-refresh';

export default function HolidaysPage() {
 const [holidays, setHolidays] = useState<SchoolEvent[]>([]);
 const [isLoading, setIsLoading] = useState(true);
 const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
 const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);

 // Check auth
 useEffect(() => {
 fetch('/api/auth/me').then((res) => res.json()).then((data) => {
 if (data.authenticated && data.user) {
 setCurrentUser(data.user);
 }
 }).catch(() => {});
 }, []);

 const loadHolidays = async () => {
 setIsLoading(true);
 try {
 const res = await fetch('/api/events');
 const data = await res.json();
 if (data.events) {
 const holidayList = data.events.filter(
 (e: SchoolEvent) =>
 e.category === 'Holidays & Observances' ||
 e.title.toLowerCase().includes('holiday') ||
 e.title.toLowerCase().includes('heroes day') ||
 e.title.toLowerCase().includes('founder') ||
 e.title.toLowerCase().includes('non-working')
 );
 setHolidays(holidayList);
 }
 } catch (e) {
 console.error('Failed to load holidays:', e);
 } finally {
 setIsLoading(false);
 }
 };

 useEffect(() => {
 const frame = requestAnimationFrame(() => {
 void loadHolidays();
 });
 return () => cancelAnimationFrame(frame);
 }, []);

 useEffect(
 () =>
 subscribeDataChanges((kind) => {
 if (kind === 'event') void loadHolidays();
 }),
 []
 );

 const handleLogout = async () => {
 await fetch('/api/auth/me', { method: 'POST' });
 setCurrentUser(null);
 };

 return (
 <div className="min-h-screen bg-[#FAF9F6] flex flex-col font-sans-ui text-[#3C3A36]">
 <Navbar
 onOpenAuthModal={() => setIsAuthModalOpen(true)}
 currentUser={currentUser}
 onLogout={handleLogout}
 searchQuery=""
 onSearchChange={() => {}}
 />

 <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex-1 w-full py-8 space-y-8">
 {/* Page Header */}
 <div className="border-b border-[#E8E4DF] pb-5 space-y-2">
 <Link
 href="/"
 className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1F9D55] hover:text-[#3C3A36] mb-1"
 >
 <ArrowLeft className="w-3.5 h-3.5" />
 <span>Return to Campus Home</span>
 </Link>
 <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
 <div>
 <span className="text-xs font-bold text-[#1F9D55] uppercase tracking-wider block mb-1">
 Philippine National & Institutional Calendar
 </span>
 <h1 className="font-serif-heading text-3xl sm:text-5xl text-[#262422]">
 School Holidays & Observances
 </h1>
 </div>

 <div className="text-xs text-[#6B6862]">
 Academic Year 2026-2027 Schedule
 </div>
 </div>
 </div>

 {/* Advisory Banner */}
 {/* <div className="p-4 rounded-3xl bg-[#EAF8EF] border border-[#B2E6C4] flex items-start gap-3 text-xs text-[#0E562D]">
 <CheckCircle2 className="w-4 h-4 text-[#1F9D55] shrink-0 mt-0.5" />
 <p className="leading-relaxed">
 During officially declared institutional and national holidays, regular in-person classes, laboratory sessions, and administrative office operations are suspended across all AMMC campuses. Online Canvas LMS remains accessible for asynchronous submissions.
 </p>
 </div> */}

 {/* Holidays Cards List */}
 {isLoading ? (
 <div className="space-y-4 py-6">
 {[1, 2, 3].map((n) => (
 <div key={n} className="natural-card rounded-3xl p-6 h-32 bg-white animate-pulse" />
 ))}
 </div>
 ) : holidays.length === 0 ? (
 <div className="py-16 text-center bg-white rounded-3xl border border-[#E8E4DF] p-8 space-y-3">
 <Sun className="w-10 h-10 text-[#DDD7CE] mx-auto" />
 <h3 className="font-serif-heading text-xl text-[#262422]">
 No Holiday Recesses Scheduled
 </h3>
 <p className="text-xs text-[#6B6862]">
 All regular classes proceed according to the academic term timetable.
 </p>
 </div>
 ) : (
 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
 {holidays.map((holiday) => {
 const startDate = new Date(holiday.start_time);
 const daysDiff = differenceInDays(startDate, new Date('2026-08-19'));

  // Clear holiday type + color for distinct Non-Working vs others
  const titleLower = holiday.title.toLowerCase();
  const isSpecialNonWorking = titleLower.includes('special') && titleLower.includes('non-working');
  const isNonWorking = titleLower.includes('non-working');
  const isNational = titleLower.includes('national') || titleLower.includes('heroes') || titleLower.includes('ninoy') || titleLower.includes('aquino');
  const isInstitutional = titleLower.includes('founder') || titleLower.includes('charter') || titleLower.includes('institutional');

  let badgeConfig: { label: string; className: string };
  if (isSpecialNonWorking) {
    badgeConfig = {
      label: 'Special Non-Working',
      className: 'bg-[#FEF3C7] text-[#92400E] border-[#FDE68A]',
    };
  } else if (isNonWorking) {
    badgeConfig = {
      label: 'Non-Working Holiday',
      className: 'bg-[#FEE2E2] text-[#991B1B] border-[#FECACA]',
    };
  } else if (isInstitutional) {
    badgeConfig = {
      label: 'Institutional Holiday',
      className: 'bg-[#EAF8EF] text-[#0E562D] border-[#B2E6C4]',
    };
  } else if (isNational) {
    badgeConfig = {
      label: 'National Holiday',
      className: 'bg-[#FEE2E2] text-[#991B1B] border-[#FECACA]',
    };
  } else {
    badgeConfig = {
      label: 'Holiday',
      className: 'bg-[#EFF6FF] text-[#1E40AF] border-[#DBEAFE]',
    };
  }

  return (
  <div
  key={holiday.id}
  className="natural-card rounded-3xl p-6 flex flex-col justify-between space-y-4 bg-white border border-[#E8E4DF] hover:border-[#B2E6C4] hover:shadow-md transition"
  >
  <div className="space-y-3">
  <div className="flex items-center justify-between gap-2">
  {/* <span className={`inline-flex itmes-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium border ${badgeConfig.className}`}>
  {isNonWorking && <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70 animate-pulse" />}
  {badgeConfig.label}
  </span> */}

  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-[#FBF2EC] text-[#AC6243] border border-[#F0D5C7]">
  {badgeConfig.label}
 </span>

  {daysDiff >= 0 && (
  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-[#EAF8EF] text-[#0E562D] border border-[#B2E6C4]">
  {daysDiff === 0 ? 'Today' : `In ${daysDiff} days`}
  </span>
  )}
  </div>

 <div className="flex items-center gap-3">
 <div className="w-12 h-12 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] flex flex-col items-center justify-center shrink-0 text-center">
 <span className="text-[9px] uppercase font-bold text-[#1F9D55]">
 {format(startDate, 'MMM')}
 </span>
 <span className="text-lg font-bold font-serif-heading text-[#262422] leading-none">
 {format(startDate, 'd')}
 </span>
 </div>

 <div>
 <h3 className="font-serif-heading text-lg font-bold text-[#262422] leading-snug">
 {holiday.title}
 </h3>
 <p className="text-xs text-[#6B6862]">
 {format(startDate, 'EEEE, MMMM d, yyyy')}
 </p>
 </div>
 </div>

 <p className="text-xs text-[#6B6862] leading-relaxed pt-1">
 {holiday.description}
 </p>
 </div>

 <div className="pt-3 border-t border-[#E8E4DF] flex items-center justify-between text-xs text-[#6B6862]">
 <span className="flex items-center gap-1">
 <MapPin className="w-3.5 h-3.5 text-[#B56E4D]" />
 {holiday.location}
 </span>
 <span className="font-medium text-[#1F9D55]">
 Official Observance
 </span>
 </div>
 </div>
 );
 })}
 </div>
 )}
 </main>

 <AdminAuthModal
 isOpen={isAuthModalOpen}
 onClose={() => setIsAuthModalOpen(false)}
 onLoginSuccess={(user) => setCurrentUser(user)}
 />
 </div>
 );
}
