import type { Metadata, Viewport } from 'next';
import { Instrument_Serif, Plus_Jakarta_Sans, Source_Serif_4 } from 'next/font/google';
import './globals.css';
import RegisterPWA from '@/components/RegisterPWA';
import InstallPrompt from '@/components/InstallPrompt';

const instrumentSerif = Instrument_Serif({
 weight: '400',
 subsets: ['latin'],
 variable: '--font-instrument',
 display: 'swap',
});

const plusJakartaSans = Plus_Jakarta_Sans({
 weight: ['400', '500', '600', '700'],
 subsets: ['latin'],
 variable: '--font-jakarta',
 display: 'swap',
});

const sourceSerif4 = Source_Serif_4({
 weight: ['400', '500', '600'],
 subsets: ['latin'],
 variable: '--font-source-serif',
 display: 'swap',
});

export const viewport: Viewport = {
  themeColor: '#1F9D55',
  width: 'device-width',
  initialScale: 1,
};

export const metadata: Metadata = {
  title: 'Dr. Aurelio Mendoza Memorial Colleges | Announcements & Events ',
  description: 'Official announcements, academic notices, event schedules, and calendar reservations for Dr. Aurelio Mendoza Memorial Colleges.',
  keywords: ['AMMC', 'Dr. Aurelio Mendoza Memorial Colleges', 'School Announcements', 'Academic Calendar', 'Events ', 'College Events'],
  manifest: '/manifest.webmanifest',
  appleWebApp: {
    capable: true,
    title: 'AMMC',
    statusBarStyle: 'default',
  },
  icons: {
    icon: [
      { url: '/icons/icon-192x192.png', sizes: '192x192', type: 'image/png' },
      { url: '/icons/icon-512x512.png', sizes: '512x512', type: 'image/png' },
    ],
    apple: [{ url: '/icons/apple-touch-icon.png', sizes: '180x180', type: 'image/png' }],
  },
  openGraph: {
    title: 'Dr. Aurelio Mendoza Memorial Colleges | Announcements & Events',
    description: 'Official announcements, academic notices, event schedules, and calendar reservations for Dr. Aurelio Mendoza Memorial Colleges.',
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
  <html
  lang="en"
  suppressHydrationWarning
  className={`${instrumentSerif.variable} ${plusJakartaSans.variable} ${sourceSerif4.variable} scroll-smooth`}
  >
  <head>
    <script
      dangerouslySetInnerHTML={{
        __html: `(function(){try{var t=localStorage.getItem('ammc-theme');var m=window.matchMedia('(prefers-color-scheme: dark)').matches;if(t==='dark'||(!t&&m))document.documentElement.classList.add('dark');}catch(e){}})()`,
      }}
    />
  </head>
  <body className="min-h-screen bg-[#FAF9F6] text-[#3C3A36] font-sans antialiased selection:bg-[#E8E4DF] selection:text-[#3C3A36] dark:bg-[#08140E] dark:text-[#D6E8C2]">
  <RegisterPWA />
  <InstallPrompt />
  {children}
  </body>
  </html>
  );
}
