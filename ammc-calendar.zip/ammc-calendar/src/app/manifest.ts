import type { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'AMMC Calendar, Events & Announcements',
    short_name: 'AMMC',
    description:
      'Official announcements, academic notices, event schedules, and calendar reservations for Dr. Aurelio Mendoza Memorial Colleges.',
    start_url: '/',
    scope: '/',
    display: 'standalone',
    // No orientation lock: this app is installed on both phones and desktops.
    background_color: '#FAF9F6',
    theme_color: '#1F9D55',
    icons: [
      {
        src: '/icons/icon-192x192.png',
        sizes: '192x192',
        type: 'image/png',
      },
      {
        src: '/icons/icon-512x512.png',
        sizes: '512x512',
        type: 'image/png',
      },
      {
        src: '/icons/maskable-512x512.png',
        sizes: '512x512',
        type: 'image/png',
        purpose: 'maskable',
      },
    ],
  };
}
