'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import EventDetailModal from '@/components/EventDetailModal';
import AdminAuthModal from '@/components/AdminAuthModal';
import { SchoolEvent, AdminUser } from '@/types';
import { format } from 'date-fns';
import {
  Layers,
  Calendar,
  Clock,
  MapPin,
  Users,
  Building2,
  ArrowLeft,
  Search,
  RefreshCw,
  Ticket,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { subscribeDataChanges } from '@/lib/data-refresh';

export default function MeetingsPage() {
  const router = useRouter();
  const [meetings, setMeetings] = useState<SchoolEvent[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCouncil, setSelectedCouncil] = useState<string>('All');
  const [activeMeeting, setActiveMeeting] = useState<SchoolEvent | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);

  // Check auth
  useEffect(() => {
    fetch('/api/auth/me')
      .then((res) => res.json())
      .then((data) => {
        if (data.authenticated && data.user) {
          setCurrentUser(data.user);
        }
      })
      .catch(() => {});
  }, []);

  const loadMeetings = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/events');
      const data = await res.json();
      if (data.events) {
        // Filter events that are Administrative & Faculty Meetings or convocations/councils
        const meetingList = data.events.filter(
          (e: SchoolEvent) =>
            e.category === 'Administrative & Faculty Meetings' ||
            e.title.toLowerCase().includes('meeting') ||
            e.title.toLowerCase().includes('assembly') ||
            e.title.toLowerCase().includes('council') ||
            e.title.toLowerCase().includes('colloquium') ||
            e.title.toLowerCase().includes('convocation')
        );
        setMeetings(meetingList);
      }
    } catch (e) {
      console.error('Failed to load meetings:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      void loadMeetings();
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  useEffect(
    () =>
      subscribeDataChanges((kind) => {
        if (kind === 'event') void loadMeetings();
      }),
    []
  );

  const handleLogout = async () => {
    await fetch('/api/auth/me', { method: 'POST' });
    setCurrentUser(null);
  };

  const filteredMeetings = meetings.filter((m) => {
    if (selectedCouncil !== 'All' && m.department !== selectedCouncil) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        m.title.toLowerCase().includes(q) ||
        m.description.toLowerCase().includes(q) ||
        m.location.toLowerCase().includes(q) ||
        m.organizer.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-[#FAF9F6] flex flex-col font-sans-ui text-[#3C3A36]">
      <Navbar
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        currentUser={currentUser}
        onLogout={handleLogout}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex-1 w-full py-8 space-y-8">
        {/* Page Header */}
        <div className="border-b border-[#E8E4DF] pb-5 space-y-2">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1F9D55] hover:text-[#3C3A36] mb-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Campus Home</span>
          </Link>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-[#1F9D55] uppercase tracking-wider block mb-1">
                Administrative & Academic Assemblies
              </span>
              <h1 className="font-serif-heading text-3xl sm:text-5xl text-[#262422]">
                Meetings & Council Sessions
              </h1>
            </div>

            {currentUser && (
              <Link
                href="/admin"
                className="px-4 py-2 rounded-full bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-semibold shadow-xs transition"
              >
                Schedule New Assembly
              </Link>
            )}
          </div>
        </div>

        {/* Filter Bar */}
        <div className="bg-white p-4 rounded-3xl border border-[#E8E4DF] shadow-sm flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-[#6B6862]">Target Body:</span>
            <select
              value={selectedCouncil}
              onChange={(e) => setSelectedCouncil(e.target.value)}
              className="px-3 py-1.5 rounded-full bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
            >
              <option value="All">All Councils & Committees</option>
              <option value="Office of the President">Executive Office of the President</option>
              <option value="Office of the Registrar">Academic Registrar & Deans</option>
              <option value="Supreme Student Council">Student Council & Clubs</option>
              <option value="College of Nursing">College of Nursing Faculty</option>
              <option value="College of Information Technology">College of IT Faculty</option>
            </select>
          </div>

          <button
            onClick={loadMeetings}
            className="p-2 rounded-full bg-[#FAF9F6] border border-[#E8E4DF] hover:bg-[#EAF8EF] text-[#6B6862] transition"
            title="Refresh Meetings"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Meetings List */}
        {isLoading ? (
          <div className="space-y-4 py-6">
            {[1, 2, 3].map((n) => (
              <div key={n} className="natural-card rounded-3xl p-6 h-36 bg-white animate-pulse" />
            ))}
          </div>
        ) : filteredMeetings.length === 0 ? (
          <div className="py-16 text-center bg-white rounded-3xl border border-[#E8E4DF] p-8 space-y-3">
            <Layers className="w-10 h-10 text-[#DDD7CE] mx-auto" />
            <h3 className="font-serif-heading text-xl text-[#262422]">
              No Scheduled Meetings Found
            </h3>
            <p className="text-xs text-[#6B6862]">
              There are currently no active administrative or academic council meetings matching this selection.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredMeetings.map((meeting) => (
              <div
                key={meeting.id}
                onClick={() => setActiveMeeting(meeting)}
                className="natural-card rounded-3xl p-6 flex flex-col justify-between cursor-pointer group hover:border-[#1F9D55] transition space-y-4 bg-white"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-[#EAF8EF] text-[#0E562D] border border-[#B2E6C4]">
                      {meeting.department}
                    </span>
                    <span className="text-xs font-mono text-[#1F9D55] font-semibold flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {format(new Date(meeting.start_time), 'h:mm a')}
                    </span>
                  </div>

                  <h3 className="font-serif-heading text-xl font-bold text-[#262422] group-hover:text-[#1F9D55] transition leading-snug">
                    {meeting.title}
                  </h3>

                  <p className="text-xs text-[#6B6862] line-clamp-2 leading-relaxed">
                    {meeting.description}
                  </p>

                  <div className="space-y-1.5 text-xs text-[#3C3A36] pt-1">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-[#1F9D55]" />
                      <span className="font-medium">
                        {format(new Date(meeting.start_time), 'EEEE, MMMM d, yyyy')}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-[#B56E4D]" />
                      <span className="text-[#6B6862] truncate">{meeting.location}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <Users className="w-3.5 h-3.5 text-[#1F9D55]" />
                      <span className="text-[#6B6862]">Audience: {meeting.target_audience}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#E8E4DF] flex items-center justify-between text-xs">
                  <span className="text-[11px] text-[#6B6862]">
                    Organized by {meeting.organizer}
                  </span>
                  {meeting.capacity > 0 && (
                    <span className="text-[11px] font-medium text-[#1F9D55]">Capacity: {meeting.capacity}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Modals */}
      <EventDetailModal
        isOpen={!!activeMeeting}
        event={activeMeeting}
        onClose={() => setActiveMeeting(null)}
        isAdmin={!!currentUser}
        onEdit={(evt) => {
          setActiveMeeting(null);
          router.push(`/admin?tab=events&edit=${encodeURIComponent(evt.id)}`);
        }}
      />
<AdminAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={(user) => setCurrentUser(user)}
      />
    </div>
  );
}
