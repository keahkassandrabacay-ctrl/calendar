import Link from 'next/link';

export const metadata = {
  title: 'Offline | AMMC',
  robots: { index: false, follow: false },
};

export default function OfflinePage() {
  return (
    <div className="min-h-screen bg-[#FAF9F6] flex items-center justify-center px-4">
      <div className="max-w-md w-full text-center space-y-4 p-8 rounded-3xl bg-white border border-[#E8E4DF] shadow-sm">
        <div className="w-12 h-12 rounded-2xl overflow-hidden border border-[#E8E4DF] bg-white mx-auto">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/logo.png" alt="AMMC Logo" className="w-full h-full object-cover" />
        </div>
        <h1 className="text-2xl font-bold text-[#262422]">You are offline</h1>
        <p className="text-sm text-[#6B6862] leading-relaxed">
          The AMMC calendar needs an internet connection to load the latest announcements and
          events. Please reconnect and try again.
        </p>
        <Link
          href="/"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-[#1F9D55] text-white text-sm font-bold hover:bg-[#168044] transition"
        >
          Retry
        </Link>
      </div>
    </div>
  );
}
