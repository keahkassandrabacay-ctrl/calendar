'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import CalendarView from '@/components/CalendarView';
import AnnouncementCard from '@/components/AnnouncementCard';
import AnnouncementModal from '@/components/AnnouncementModal';
import EventDetailModal from '@/components/EventDetailModal';
import AdminAuthModal from '@/components/AdminAuthModal';
import SubscribeModal from '@/components/SubscribeModal';
import { Announcement, SchoolEvent, AdminUser } from '@/types';
import { format } from 'date-fns';
import {
    Bell,
    Calendar,
    Sparkles,
    Layers,
    GraduationCap,
    ArrowRight,
    Pin,
    MapPin,
    Clock,
    Ticket,
    ChevronRight,
    ShieldCheck,
    CheckCircle2,
    Users,
    BookOpen,
    ArrowUpRight,
    ShieldAlert,
    Search,
    RefreshCw,
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { subscribeDataChanges } from '@/lib/data-refresh';

export default function HomePage() {
    const router = useRouter();
    const [announcements, setAnnouncements] = useState<Announcement[]>([]);
    const [events, setEvents] = useState<SchoolEvent[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [activeAnnouncement, setActiveAnnouncement] = useState<Announcement | null>(null);
    const [activeEvent, setActiveEvent] = useState<SchoolEvent | null>(null);
    const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
    const [isSubscribeOpen, setIsSubscribeOpen] = useState(false);
    const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);

    // Load bookmarks from local storage
    useEffect(() => {
        const frame = requestAnimationFrame(() => {
            try {
                const stored = localStorage.getItem('ammc_bookmarked_announcements');
                if (stored) setBookmarkedIds(JSON.parse(stored));
            } catch {
                // ignore
            }
        });
        return () => cancelAnimationFrame(frame);
    }, []);

    // Check auth
    useEffect(() => {
        fetch('/api/auth/me').then((res) => res.json()).then((data) => {
            if (data.authenticated && data.user) {
                setCurrentUser(data.user);
            }
        }).catch(() => { });
    }, []);

    const loadData = async () => {
        setIsLoading(true);
        try {
            const [annRes, evtRes] = await Promise.all([
                fetch('/api/announcements'),
                fetch('/api/events'),
            ]);
            const annData = await annRes.json();
            const evtData = await evtRes.json();
            if (annData.announcements) setAnnouncements(annData.announcements);
            if (evtData.events) setEvents(evtData.events);
        } catch (e) {
            console.error('Failed to load home data:', e);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        const frame = requestAnimationFrame(() => {
            void loadData();
        });
        return () => cancelAnimationFrame(frame);
    }, []);

    // Refresh when an announcement or event is posted/edited/deleted.
    useEffect(
        () =>
            subscribeDataChanges((kind) => {
                if (kind === 'announcement' || kind === 'event') void loadData();
            }),
        []
    );

    const handleToggleBookmark = (id: string) => {
        setBookmarkedIds((prev) => {
            const updated = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
            try {
                localStorage.setItem('ammc_bookmarked_announcements', JSON.stringify(updated));
            } catch {
                // ignore
            }
            return updated;
        });
    };

    const handleLogout = async () => {
        await fetch('/api/auth/me', { method: 'POST' });
        setCurrentUser(null);
    };

    const pinnedAnnouncements = announcements.filter((a) => a.is_pinned);
    const latestAnnouncements = [...announcements].slice(0, 3);
    const meetingsCount = events.filter(
        (e) =>
            e.category === 'Administrative & Faculty Meetings' ||
            e.title.toLowerCase().includes('meeting') ||
            e.title.toLowerCase().includes('council')
    ).length;
    const holidaysCount = events.filter((e) => e.category === 'Holidays & Observances').length;

    return (
        <div className="min-h-screen bg-[#FAF9F6] flex flex-col font-sans-ui text-[#3C3A36]">
            <Navbar
                onOpenAuthModal={() => setIsAuthModalOpen(true)}
                currentUser={currentUser}
                onLogout={handleLogout}
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
            />

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex-1 w-full py-8 space-y-10 pb-16">
                {/* Top Hero & Header Bar */}
                <section className="relative rounded-3xl bg-[#F4EFEA] border border-[#E8E4DF] p-6 sm:p-8 overflow-hidden shadow-sm">
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                        <div className="space-y-2 max-w-2xl">
                            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-[#DDD7CE] text-xs font-semibold text-[#1F9D55]">
                                <span className="w-2 h-2 rounded-full bg-[#1F9D55]" />
                                <span>Dr. Aurelio Mendoza Memorial Colleges</span>
                            </div>

                            <h1 className="font-serif-heading text-3xl sm:text-5xl text-[#262422] leading-[1.1] tracking-tight">
                                AMMC Calendar, Events & Announcements
                            </h1>

                            <p className="text-xs sm:text-sm text-[#6B6862] leading-relaxed">
                                Stay synchronized with interactive academic calendars, examination periods, campus activities, council meetings, and verified institutional circulars.
                            </p>
                        </div>

                        {/* Quick Metrics Badges */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 shrink-0">
                            <Link
                                href="/announcements"
                                className="p-3 rounded-2xl bg-white border border-[#E8E4DF] hover:border-[#1F9D55] text-center transition group shadow-2xs"
                            >
                                <div className="text-xl font-bold font-serif-heading text-[#262422] group-hover:text-[#1F9D55]">
                                    {announcements.length}
                                </div>
                                <div className="text-[11px] text-[#6B6862]">Announcements</div>
                            </Link>

                            <Link
                                href="/events"
                                className="p-3 rounded-2xl bg-white border border-[#E8E4DF] hover:border-[#B56E4D] text-center transition group shadow-2xs"
                            >
                                <div className="text-xl font-bold font-serif-heading text-[#B56E4D]">
                                    {events.length}
                                </div>
                                <div className="text-[11px] text-[#6B6862]">Campus Events</div>
                            </Link>

                            <Link
                                href="/meetings"
                                className="p-3 rounded-2xl bg-white border border-[#E8E4DF] hover:border-[#1F9D55] text-center transition group shadow-2xs"
                            >
                                <div className="text-xl font-bold font-serif-heading text-[#1F9D55]">
                                    {meetingsCount}
                                </div>
                                <div className="text-[11px] text-[#6B6862]">Meetings</div>
                            </Link>

                            <Link
                                href="/holidays"
                                className="p-3 rounded-2xl bg-white border border-[#E8E4DF] hover:border-[#8C7D6B] text-center transition group shadow-2xs"
                            >
                                <div className="text-xl font-bold font-serif-heading text-[#8C7D6B]">
                                    {holidaysCount}
                                </div>
                                <div className="text-[11px] text-[#6B6862]">Holidays</div>
                            </Link>
                        </div>
                    </div>

                    {/* Pinned Priority Alert Banner if active */}
                    {pinnedAnnouncements.length > 0 && (
                        <button
                            type="button"
                            onClick={() => setActiveAnnouncement(pinnedAnnouncements[0])}
                            className="mt-6 p-4 rounded-2xl bg-white border-2 border-[#1F9D55]/30 hover:border-[#1F9D55] transition cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs group w-full text-left"
                        >
                            <div className="flex items-start gap-3">
                                <div className="w-8 h-8 rounded-xl bg-[#FAF0EB] text-[#B56E4D] border border-[#ECCEC1] flex items-center justify-center shrink-0 mt-0.5">
                                    <ShieldAlert className="w-4 h-4" />
                                </div>
                                <div>
                                    <div className="flex items-center gap-2 mb-0.5">
                                        <span className="text-[10px] uppercase font-bold tracking-wider text-[#B56E4D]">
                                            Pinned Priority Advisory
                                        </span>
                                        <span className="text-[10px] text-[#6B6862]">• {pinnedAnnouncements[0].department}</span>
                                    </div>
                                    <h4 className="font-serif-heading text-base sm:text-lg font-bold text-[#262422] group-hover:text-[#1F9D55] transition line-clamp-1">
                                        {pinnedAnnouncements[0].title}
                                    </h4>
                                </div>
                            </div>

                            <div className="flex items-center gap-1 text-xs font-semibold text-[#1F9D55] shrink-0 self-end sm:self-center">
                                <span>Read Full Circular</span>
                                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                            </div>
                        </button>
                    )}
                </section>

                {/* PRIMARY FOCUS: Interactive Campus Calendar on Home Page */}
                <section className="space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E8E4DF] pb-3">
                        <div>
                            <span className="text-xs font-bold text-[#1F9D55] uppercase tracking-wider block mb-0.5">
                                School Schedule & Timetable
                            </span>
                            <h2 className="font-serif-heading text-2xl sm:text-4xl text-[#262422]">
                                Academic & Campus Event Calendar
                            </h2>
                        </div>

                        <div className="flex items-center gap-2">
                            <Link
                                href="/calendar"
                                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1F9D55] hover:text-[#262422] px-3.5 py-1.5 rounded-full bg-white border border-[#E8E4DF] hover:border-[#1F9D55] transition shadow-2xs"
                            >
                                <Calendar className="w-3.5 h-3.5" />
                                <span>Dedicated Calendar View</span>
                                <ArrowRight className="w-3.5 h-3.5" />
                            </Link>
                        </div>
                    </div>

                    {/* Interactive Calendar Component */}
                    {isLoading ? (
                        <div className="h-96 rounded-3xl bg-white border border-[#E8E4DF] animate-pulse flex items-center justify-center">
                            <div className="text-center space-y-2 text-[#6B6862] text-xs">
                                <Calendar className="w-8 h-8 text-[#1F9D55] mx-auto animate-bounce" />
                                <p>Loading school schedule calendar...</p>
                            </div>
                        </div>
                    ) : (
                        <CalendarView
                            events={events}
                            onSelectEvent={(evt) => setActiveEvent(evt)}
                        />
                    )}
                </section>

                {/* Navigation Bento Directory: Dedicated Sections */}
                <section className="space-y-4 pt-4">
                    <div>
                        <span className="text-xs font-bold text-[#1F9D55] uppercase tracking-wider block mb-0.5">
                            Directory
                        </span>
                        <h3 className="font-serif-heading text-2xl text-[#262422]">
                            Explore Dedicated Sections
                        </h3>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        {/* 1. Announcements */}
                        <Link
                            href="/announcements"
                            className="natural-card rounded-3xl p-5 bg-white border border-[#E8E4DF] hover:border-[#1F9D55] transition flex flex-col justify-between group space-y-3"
                        >
                            <div className="space-y-2">
                                <div className="w-9 h-9 rounded-2xl bg-[#EAF8EF] text-[#1F9D55] border border-[#B2E6C4] flex items-center justify-center group-hover:scale-105 transition">
                                    <Bell className="w-4 h-4" />
                                </div>
                                <h4 className="font-serif-heading text-xl font-bold text-[#262422] group-hover:text-[#1F9D55] transition">
                                    Announcements
                                </h4>
                                <p className="text-xs text-[#6B6862] line-clamp-2 leading-relaxed">
                                    Official circulars, exam permits, scholarships, and campus alerts.
                                </p>
                            </div>
                            <div className="flex items-center justify-between text-xs font-semibold text-[#1F9D55] pt-2 border-t border-[#E8E4DF]">
                                <span>{announcements.length} Bulletins</span>
                                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                            </div>
                        </Link>

                        {/* 2. Campus Events */}
                        <Link
                            href="/events"
                            className="natural-card rounded-3xl p-5 bg-white border border-[#E8E4DF] hover:border-[#B56E4D] transition flex flex-col justify-between group space-y-3"
                        >
                            <div className="space-y-2">
                                <div className="w-9 h-9 rounded-2xl bg-[#FAF0EB] text-[#B56E4D] border border-[#ECCEC1] flex items-center justify-center group-hover:scale-105 transition">
                                    <Sparkles className="w-4 h-4" />
                                </div>
                                <h4 className="font-serif-heading text-xl font-bold text-[#262422] group-hover:text-[#B56E4D] transition">
                                    Campus Events
                                </h4>
                                <p className="text-xs text-[#6B6862] line-clamp-2 leading-relaxed">
                                    Convocations, cultural fests and intramural sports.
                                </p>
                            </div>
                            <div className="flex items-center justify-between text-xs font-semibold text-[#B56E4D] pt-2 border-t border-[#E8E4DF]">
                                <span>{events.length} Events</span>
                                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                            </div>
                        </Link>

                        {/* 3. Meetings */}
                        <Link
                            href="/meetings"
                            className="natural-card rounded-3xl p-5 bg-white border border-[#E8E4DF] hover:border-[#1F9D55] transition flex flex-col justify-between group space-y-3"
                        >
                            <div className="space-y-2">
                                <div className="w-9 h-9 rounded-2xl bg-[#EEF3F7] text-[#3F5264] border border-[#CAD8E3] flex items-center justify-center group-hover:scale-105 transition">
                                    <Layers className="w-4 h-4" />
                                </div>
                                <h4 className="font-serif-heading text-xl font-bold text-[#262422] group-hover:text-[#1F9D55] transition">
                                    Council Meetings
                                </h4>
                                <p className="text-xs text-[#6B6862] line-clamp-2 leading-relaxed">
                                    Academic deans, faculty colloquia, and student council sessions.
                                </p>
                            </div>
                            <div className="flex items-center justify-between text-xs font-semibold text-[#3F5264] pt-2 border-t border-[#E8E4DF]">
                                <span>{meetingsCount} Assemblies</span>
                                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                            </div>
                        </Link>

                        {/* 4. Holidays */}
                        <Link
                            href="/holidays"
                            className="natural-card rounded-3xl p-5 bg-white border border-[#E8E4DF] hover:border-[#8C7D6B] transition flex flex-col justify-between group space-y-3"
                        >
                            <div className="space-y-2">
                                <div className="w-9 h-9 rounded-2xl bg-[#F6F4EE] text-[#615646] border border-[#DFD9CB] flex items-center justify-center group-hover:scale-105 transition">
                                    <GraduationCap className="w-4 h-4" />
                                </div>
                                <h4 className="font-serif-heading text-xl font-bold text-[#262422] group-hover:text-[#8C7D6B] transition">
                                    School Holidays
                                </h4>
                                <p className="text-xs text-[#6B6862] line-clamp-2 leading-relaxed">
                                    National holidays, founder&apos;s day, and academic breaks.
                                </p>
                            </div>
                            <div className="flex items-center justify-between text-xs font-semibold text-[#615646] pt-2 border-t border-[#E8E4DF]">
                                <span>{holidaysCount} Observances</span>
                                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                            </div>
                        </Link>
                    </div>
                </section>

                {/* Latest Announcements Spotlight */}
                <section className="space-y-4 pt-4">
                    <div className="flex items-center justify-between border-b border-[#E8E4DF] pb-3">
                        <div>
                            <span className="text-xs font-bold text-[#1F9D55] uppercase tracking-wider block mb-0.5">
                                Official Circulars
                            </span>
                            <h3 className="font-serif-heading text-2xl text-[#262422]">
                                Latest Institutional Announcements
                            </h3>
                        </div>
                        <Link
                            href="/announcements"
                            className="text-xs font-semibold text-[#1F9D55] hover:text-[#262422] flex items-center gap-1"
                        >
                            <span>View All Bulletins</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                        </Link>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {latestAnnouncements.map((ann) => (
                            <AnnouncementCard
                                key={ann.id}
                                announcement={ann}
                                onOpen={(a) => setActiveAnnouncement(a)}
                                isBookmarked={bookmarkedIds.includes(ann.id)}
                                onToggleBookmark={handleToggleBookmark}
                            />
                        ))}
                    </div>
                </section>

                {/* Notification Subscriber CTA — Homepage */}
                <section className="rounded-3xl bg-gradient-to-br from-[#1F9D55] to-[#168044] border border-[#1F9D55] p-6 sm:p-8 shadow-sm text-[#FAF9F6] relative overflow-hidden">
                    <div className="absolute -top-12 -right-12 w-40 h-40 rounded-full bg-white/5" />
                    <div className="absolute -bottom-10 -left-10 w-32 h-32 rounded-full bg-white/5" />
                    <div className="relative flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                        <div className="space-y-2 max-w-xl">
                            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 text-xs font-semibold">
                                <Bell className="w-3.5 h-3.5" />
                                <span>Stay Updated — Announcements & Events via SMS & Email</span>
                            </div>
                            <h3 className="font-serif-heading text-2xl sm:text-3xl leading-tight">
                                Never miss an AMMC update
                            </h3>
                            <p className="text-xs sm:text-sm text-[#E8E4DF] leading-relaxed">
                                Subscribe with your Student ID, course, phone and email. Your request will be reviewed by an admin to prevent spam — once approved, you’ll be auto-notified for every new circular and campus event.
                            </p>
                        </div>
                        <div className="shrink-0 flex flex-col items-start lg:items-end gap-3">
                            <button
                                onClick={() => setIsSubscribeOpen(true)}
                                className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-white text-[#1F9D55] hover:bg-[#FAF9F6] text-sm font-bold shadow-sm transition"
                            >
                                <GraduationCap className="w-4 h-4" />
                                Subscribe to Notifications
                                <ArrowRight className="w-4 h-4" />
                            </button>

                        </div>
                    </div>
                </section>
            </main>

            {/* Footer */}
            <footer className="bg-[#FAF9F6] border-t border-[#E8E4DF] py-10 font-sans-ui">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
                    <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-xl overflow-hidden border border-[#E8E4DF] bg-white flex items-center justify-center">
                                <img src="/logo.png" alt="AMMC Logo" className="w-full h-full object-cover" />
                            </div>
                            <div>
                                <span className="font-serif-heading text-lg text-[#262422] block font-bold">
                                    Dr. Aurelio Mendoza Memorial Colleges
                                </span>
                                {/* <span className="text-[11px] text-[#6B6862]">
 Excellence in Education, Leadership & Community Service
 </span> */}
                            </div>
                        </div>

                        <div className="flex flex-wrap items-center gap-4 text-xs text-[#6B6862]">
                            <Link href="/" className="hover:text-[#3C3A36]">Home Calendar</Link>
                            <Link href="/announcements" className="hover:text-[#3C3A36]">Announcements</Link>
                            <Link href="/events" className="hover:text-[#3C3A36]">Events</Link>
                            <Link href="/calendar" className="hover:text-[#3C3A36]">Full Calendar</Link>
                            <Link href="/meetings" className="hover:text-[#3C3A36]">Meetings</Link>
                            <Link href="/holidays" className="hover:text-[#3C3A36]">Holidays</Link>
                        </div>
                    </div>

                    <div className="pt-4 border-t border-[#E8E4DF] flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#6B6862] gap-2">
                        <p>© 2026 Dr. Aurelio Mendoza Memorial Colleges. All rights reserved.</p>
                    </div>
                </div>
            </footer>

            {/* Modals */}
            <AnnouncementModal
                isOpen={!!activeAnnouncement}
                announcement={activeAnnouncement}
                onClose={() => setActiveAnnouncement(null)}
                isAdmin={!!currentUser}
                onEdit={(ann) => {
                    setActiveAnnouncement(null);
                    router.push(`/admin?tab=announcements&edit=${encodeURIComponent(ann.id)}`);
                }}
            />

            <EventDetailModal
                isOpen={!!activeEvent}
                event={activeEvent}
                onClose={() => setActiveEvent(null)}
                isAdmin={!!currentUser}
                onEdit={(evt) => {
                    setActiveEvent(null);
                    router.push(`/admin?tab=events&edit=${encodeURIComponent(evt.id)}`);
                }}
            />
            <AdminAuthModal
                isOpen={isAuthModalOpen}
                onClose={() => setIsAuthModalOpen(false)}
                onLoginSuccess={(user) => setCurrentUser(user)}
            />

            <SubscribeModal isOpen={isSubscribeOpen} onClose={() => setIsSubscribeOpen(false)} />
        </div>
    );
}
