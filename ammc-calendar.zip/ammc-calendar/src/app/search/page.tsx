'use client';

import React, { useState, useEffect, useMemo, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import AdminAuthModal from '@/components/AdminAuthModal';
import { subscribeDataChanges } from '@/lib/data-refresh';
import AnnouncementCard from '@/components/AnnouncementCard';
import AnnouncementModal from '@/components/AnnouncementModal';
import EventDetailModal from '@/components/EventDetailModal';
import { Announcement, SchoolEvent, AdminUser } from '@/types';
import { Search, Bell, Calendar, Sparkles, ArrowLeft, Clock, ChevronDown, Filter, ArrowUpDown } from 'lucide-react';
import { format } from 'date-fns';

type UnifiedResult = {
  id: string;
  type: 'announcement' | 'event';
  title: string;
  excerpt: string;
  department: string;
  category: string;
  date: string; // ISO used for sorting (latest→oldest)
  data: Announcement | SchoolEvent;
};

function SearchContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const q = searchParams.get('q') || '';
  const [queryInput, setQueryInput] = useState(q);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [events, setEvents] = useState<SchoolEvent[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [activeAnnouncement, setActiveAnnouncement] = useState<Announcement | null>(null);
  const [activeEvent, setActiveEvent] = useState<SchoolEvent | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'announcement' | 'event'>('all');
  const [sortOrder, setSortOrder] = useState<'latest' | 'oldest'>('latest');

  // Sync input with URL (?q=)
  const [prevQ, setPrevQ] = useState(q);
  if (q !== prevQ) {
    setPrevQ(q);
    setQueryInput(q);
  }

  useEffect(() => {
    fetch('/api/auth/me')
      .then((r) => r.json())
      .then((d) => {
        if (d.authenticated && d.user) setCurrentUser(d.user);
      })
      .catch(() => { });
  }, []);

  useEffect(() => {
    const load = async () => {
      setIsLoading(true);
      try {
        const [annRes, evtRes] = await Promise.all([fetch('/api/announcements'), fetch('/api/events')]);
        const annData = await annRes.json();
        const evtData = await evtRes.json();
        if (annData.announcements) setAnnouncements(annData.announcements);
        if (evtData.events) setEvents(evtData.events);
      } catch (e) {
        console.error('search load failed', e);
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, []);

  useEffect(
    () =>
      subscribeDataChanges((kind) => {
        if (kind === 'announcement' || kind === 'event') {
          void (async () => {
            try {
              const [annRes, evtRes] = await Promise.all([fetch('/api/announcements'), fetch('/api/events')]);
              const annData = await annRes.json();
              const evtData = await evtRes.json();
              if (annData.announcements) setAnnouncements(annData.announcements);
              if (evtData.events) setEvents(evtData.events);
            } catch {
              // ignore
            }
          })();
        }
      }),
    []
  );

  const handleLogout = async () => {
    await fetch('/api/auth/me', { method: 'POST' });
    setCurrentUser(null);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = queryInput.trim();
    if (trimmed) router.push(`/search?q=${encodeURIComponent(trimmed)}`);
    else router.push('/search');
  };

  const results: UnifiedResult[] = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return [];

    const annMatches: UnifiedResult[] = announcements
      .filter((a) => {
        if (filterType === 'event') return false;
        return (
          a.title.toLowerCase().includes(needle) ||
          a.summary.toLowerCase().includes(needle) ||
          a.content.toLowerCase().includes(needle) ||
          a.department.toLowerCase().includes(needle) ||
          a.category.toLowerCase().includes(needle) ||
          a.audience.toLowerCase().includes(needle)
        );
      })
      .map((a) => ({
        id: a.id,
        type: 'announcement' as const,
        title: a.title,
        excerpt: a.summary,
        department: a.department,
        category: a.category,
        date: a.created_at,
        data: a,
      }));

    const evtMatches: UnifiedResult[] = events
      .filter((ev) => {
        if (filterType === 'announcement') return false;
        return (
          ev.title.toLowerCase().includes(needle) ||
          ev.description.toLowerCase().includes(needle) ||
          ev.location.toLowerCase().includes(needle) ||
          ev.department.toLowerCase().includes(needle) ||
          ev.category.toLowerCase().includes(needle)
        );
      })
      .map((ev) => ({
        id: ev.id,
        type: 'event' as const,
        title: ev.title,
        excerpt: ev.description,
        department: ev.department,
        category: ev.category,
        date: ev.start_time || ev.created_at,
        data: ev,
      }));

    const merged = [...annMatches, ...evtMatches];
    // Latest → oldest priority: sort by date DESC (newest first)
    merged.sort((a, b) => {
      const da = new Date(a.date).getTime();
      const db = new Date(b.date).getTime();
      return sortOrder === 'latest' ? db - da : da - db;
    });
    return merged;
  }, [q, announcements, events, filterType, sortOrder]);

  const totalAnn = results.filter((r) => r.type === 'announcement').length;
  const totalEvt = results.filter((r) => r.type === 'event').length;

  return (
    <div className="min-h-screen bg-[#FAF9F6] flex flex-col font-sans-ui text-[#3C3A36]">
      <Navbar
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        currentUser={currentUser}
        onLogout={handleLogout}
        searchQuery={queryInput}
        onSearchChange={setQueryInput}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex-1 w-full py-8 space-y-6">
        {/* Header + separate search UI */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E4DF] shadow-sm space-y-4">
          <Link href="/" className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1F9D55] hover:text-[#3C3A36]">
            <ArrowLeft className="w-3.5 h-3.5" />
            Return to Campus Home
          </Link>

          <div>
            <h1 className="font-serif-heading text-3xl sm:text-4xl text-[#262422]">Search Results</h1>
            <p className="text-xs text-[#6B6862] mt-1">
              Separate search UI — prioritized <span className="font-semibold text-[#1F9D55]">latest → oldest</span> by date. Results from Announcements & Events.
            </p>
          </div>

          {/* Separate search bar (large, prioritized) */}
          <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B6862]" />
              <input
                type="text"
                value={queryInput}
                onChange={(e) => setQueryInput(e.target.value)}
                placeholder="Search advisories, events, guidelines, schedules..."
                className="w-full pl-11 pr-4 py-3 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-sm text-[#3C3A36] placeholder-[#6B6862] focus:outline-none focus:border-[#1F9D55] focus:ring-2 focus:ring-[#1F9D55]/10 transition shadow-sm"
                autoFocus
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3 rounded-2xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-sm font-semibold shadow-sm transition flex items-center justify-center gap-2 shrink-0"
            >
              <Search className="w-4 h-4" />
              Search
            </button>
          </form>

          {/* Filter + sort controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#E8E4DF]">
            <div className="flex items-center gap-2 overflow-x-auto">
              <button
                onClick={() => setFilterType('all')}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap border transition ${filterType === 'all' ? 'bg-[#1F9D55] text-white border-[#1F9D55]' : 'bg-white text-[#6B6862] border-[#E8E4DF] hover:bg-[#FAF9F6]'}`}
              >
                All ({results.length})
              </button>
              <button
                onClick={() => setFilterType('announcement')}
                className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap border transition ${filterType === 'announcement' ? 'bg-[#1F9D55] text-white border-[#1F9D55]' : 'bg-white text-[#6B6862] border-[#E8E4DF] hover:bg-[#FAF9F6]'}`}
              >
                <Bell className="w-3.5 h-3.5" />
                Announcements ({totalAnn})
              </button>
              <button
                onClick={() => setFilterType('event')}
                className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap border transition ${filterType === 'event' ? 'bg-[#1F9D55] text-white border-[#1F9D55]' : 'bg-white text-[#6B6862] border-[#E8E4DF] hover:bg-[#FAF9F6]'}`}
              >
                <Calendar className="w-3.5 h-3.5" />
                Events ({totalEvt})
              </button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-[#6B6862] flex items-center gap-1">
                <ArrowUpDown className="w-3.5 h-3.5" />
                Sort:
              </span>
              <div className="flex items-center gap-1 p-1 rounded-full bg-[#FAF9F6] border border-[#E8E4DF]">
                <button
                  onClick={() => setSortOrder('latest')}
                  className={`px-3 py-1 rounded-full text-xs font-semibold transition ${sortOrder === 'latest' ? 'bg-[#1F9D55] text-white shadow-xs' : 'text-[#6B6862] hover:text-[#3C3A36]'}`}
                >
                  Latest → Oldest
                </button>
                <button
                  onClick={() => setSortOrder('oldest')}
                  className={`px-3 py-1 rounded-full text-xs font-semibold transition ${sortOrder === 'oldest' ? 'bg-[#1F9D55] text-white shadow-xs' : 'text-[#6B6862] hover:text-[#3C3A36]'}`}
                >
                  Oldest → Latest
                </button>
              </div>
            </div>
          </div>

          {q && (
            // <p className="text-xs text-[#6B6862]">
            //   Showing <strong className="text-[#3C3A36]">{results.length}</strong> result(s) for <span className="font-mono bg-[#EAF8EF] px-1.5 py-0.5 rounded border border-[#B2E6C4]">“{q}”</span> — sorted <strong>{sortOrder === 'latest' ? 'newest first' : 'oldest first'}</strong>
            // </p>
            <p className="text-xs text-[#6B6862]">
              Showing <strong className="text-[#3C3A36]">{results.length}</strong> result(s) for <span className="font-mono bg-[#EAF8EF] px-1.5 py-0.5 rounded border border-[#B2E6C4]">“{q}”</span>
            </p>
          )}
        </div>

        {/* Results */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 py-8">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div key={n} className="rounded-3xl p-6 h-48 bg-white border border-[#E8E4DF] animate-pulse" />
            ))}
          </div>
        ) : !q.trim() ? (
          <div className="py-16 text-center bg-white rounded-3xl border border-[#E8E4DF] p-8 space-y-3">
            <Search className="w-10 h-10 text-[#DDD7CE] mx-auto" />
            <h3 className="font-serif-heading text-xl text-[#262422]">Search AMMC</h3>
            <p className="text-xs text-[#6B6862] max-w-sm mx-auto">Enter a keyword above to search across official announcements and campus events. Results are ranked latest first.</p>
          </div>
        ) : results.length === 0 ? (
          <div className="py-16 text-center bg-white rounded-3xl border border-[#E8E4DF] p-8 space-y-3">
            <Filter className="w-10 h-10 text-[#DDD7CE] mx-auto" />
            <h3 className="font-serif-heading text-xl text-[#262422]">No results for “{q}”</h3>
            <p className="text-xs text-[#6B6862]">Try a different keyword or clear the type filter (All / Announcements / Events).</p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-xs text-[#6B6862]">
              <Clock className="w-3.5 h-3.5" />
              <span>Sorted by date — <strong className="text-[#3C3A36]">{sortOrder === 'latest' ? 'latest → oldest' : 'oldest → latest'}</strong> • {results.length} items</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.map((r) => {
                const isAnn = r.type === 'announcement';
                const ann = r.data as Announcement;
                const evt = r.data as SchoolEvent;
                return (
                  <div
                    key={`${r.type}-${r.id}`}
                    onClick={() => (isAnn ? setActiveAnnouncement(ann) : setActiveEvent(evt))}
                    className="group cursor-pointer bg-white rounded-3xl border border-[#E8E4DF] hover:border-[#1F9D55] p-5 flex flex-col gap-3 transition shadow-sm hover:shadow-md"
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${isAnn ? 'bg-[#EAF8EF] text-[#1F9D55] border border-[#B2E6C4]' : 'bg-[#FAF0EB] text-[#B56E4D] border border-[#ECCEC1]'}`}>
                        {isAnn ? <Bell className="w-3 h-3" /> : <Sparkles className="w-3 h-3" />}
                        {isAnn ? 'Announcement' : 'Event'}
                      </span>
                      <span className="text-[11px] text-[#6B6862] flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {format(new Date(r.date), 'MMM d, yyyy')}
                      </span>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#FAF9F6] border border-[#E8E4DF] text-[#6B6862]">{r.category} • {r.department}</span>
                      <h3 className="font-serif-heading text-base font-bold text-[#262422] group-hover:text-[#1F9D55] line-clamp-2 leading-snug">{r.title}</h3>
                      <p className="text-xs text-[#6B6862] line-clamp-2 leading-relaxed">{r.excerpt}</p>
                    </div>
                    <div className="mt-auto pt-2 border-t border-[#E8E4DF] flex items-center justify-between text-xs">
                      <span className="text-[#1F9D55] font-semibold group-hover:underline">
                        {isAnn ? 'Read circular →' : 'View event →'}
                      </span>
                      <ChevronDown className="w-3.5 h-3.5 text-[#6B6862] rotate-[-90deg] group-hover:translate-x-0.5 transition" />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>

      <AnnouncementModal isOpen={!!activeAnnouncement} announcement={activeAnnouncement} onClose={() => setActiveAnnouncement(null)} isAdmin={!!currentUser} onEdit={(ann) => { setActiveAnnouncement(null); router.push(`/admin?tab=announcements&edit=${encodeURIComponent(ann.id)}`); }} />
      <EventDetailModal isOpen={!!activeEvent} event={activeEvent} onClose={() => setActiveEvent(null)} isAdmin={!!currentUser} onEdit={(evt) => { setActiveEvent(null); router.push(`/admin?tab=events&edit=${encodeURIComponent(evt.id)}`); }} />
      <AdminAuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} onLoginSuccess={(u) => setCurrentUser(u)} />
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-[#FAF9F6] flex items-center justify-center text-xs text-[#6B6862]">Loading search...</div>}>
      <SearchContent />
    </Suspense>
  );
}
