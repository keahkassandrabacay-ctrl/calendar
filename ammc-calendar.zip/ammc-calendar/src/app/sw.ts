import { defaultCache } from '@serwist/next/worker';
import type { PrecacheEntry } from 'serwist';
import { Serwist } from 'serwist';
import { getDeviceIdForWorker } from '../lib/device-id';

// The worker global is hand-declared rather than pulled from lib.webworker,
// which cannot be combined with the DOM lib this app compiles against.
interface ExtendableEventLike {
  waitUntil(promise: Promise<unknown>): void;
}

interface PushEventLike extends ExtendableEventLike {
  data: { json(): unknown } | null;
}

interface NotificationEventLike extends ExtendableEventLike {
  notification: { close(): void; data?: { url?: string } };
}

interface PushSubscriptionChangeEventLike extends ExtendableEventLike {
  oldSubscription: {
    options: { userVisibleOnly: boolean; applicationServerKey?: unknown };
  } | null;
}

interface WindowClientLike {
  url: string;
  focus(): Promise<void>;
}

declare const self: {
  __SW_MANIFEST: (PrecacheEntry | string)[] | undefined;
  registration: {
    showNotification(title: string, options?: Record<string, unknown>): Promise<void>;
    pushManager: {
      subscribe(options: Record<string, unknown>): Promise<{
        toJSON(): { endpoint: string; keys?: { p256dh?: string; auth?: string } };
        unsubscribe(): Promise<boolean>;
      }>;
    };
  };
  navigator: {
    setAppBadge?: (count?: number) => Promise<void>;
    clearAppBadge?: () => Promise<void>;
  };
  addEventListener(type: string, listener: (event: never) => void): void;
  location: { origin: string };
  clients: {
    matchAll(options?: { type?: string; includeUncontrolled?: boolean }): Promise<WindowClientLike[]>;
    openWindow(url: string): Promise<WindowClientLike | null>;
  };
};

const serwist = new Serwist({
  precacheEntries: self.__SW_MANIFEST,
  skipWaiting: true,
  clientsClaim: true,
  navigationPreload: true,
  runtimeCaching: defaultCache,
  fallbacks: {
    entries: [
      {
        url: '/offline',
        matcher({ request }) {
          return request.destination === 'document';
        },
      },
    ],
  },
});

serwist.addEventListeners();

const MAX_BODY_LENGTH = 180;

function truncate(text: string): string {
  return text.length > MAX_BODY_LENGTH ? `${text.slice(0, MAX_BODY_LENGTH - 1)}…` : text;
}

async function applyBadge(count: number): Promise<void> {
  // Must be awaited *inside* waitUntil: the browser can suspend the worker the
  // moment the event's lifetime ends, silently dropping the badge update.
  if (!self.navigator.setAppBadge) return;
  try {
    if (count > 0) await self.navigator.setAppBadge(count);
    else await self.navigator.clearAppBadge?.();
  } catch {
    // A badge is best-effort — never let it block the notification.
  }
}

function urlBase64ToUint8Array(base64: string): Uint8Array<ArrayBuffer> {
  const padding = '='.repeat((4 - (base64.length % 4)) % 4);
  const normalised = (base64 + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(normalised);
  const output = new Uint8Array(new ArrayBuffer(raw.length));
  for (let i = 0; i < raw.length; i += 1) output[i] = raw.charCodeAt(i);
  return output;
}

async function markReadAndClearBadge(): Promise<void> {
  try {
    const deviceId = await getDeviceIdForWorker();
    if (!deviceId) return;
    const response = await fetch('/api/announcements/mark-read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ deviceId }),
    });
    if (!response.ok) return;
    const data = (await response.json()) as { unread?: number };
    await applyBadge(Number(data.unread) || 0);
  } catch {
    /* ignore — the page will reconcile on next open */
  }
}

self.addEventListener('push', ((event: PushEventLike) => {
  event.waitUntil(
    (async () => {
      let payload: { v?: number; title?: string; body?: string; url?: string; tag?: string; count?: number } = {};
      try {
        const parsed = (await event.data?.json()) as typeof payload | null;
        if (parsed && typeof parsed === 'object') payload = parsed;
      } catch {
        // Push services may deliver a plain-text payload; fall back to defaults.
      }

      const title = typeof payload.title === 'string' && payload.title ? payload.title : 'New announcement';
      const body = typeof payload.body === 'string' && payload.body ? payload.body : 'Tap to read.';
      const count = Number(payload.count) || 0;
      const url = typeof payload.url === 'string' && payload.url.startsWith('/') ? payload.url : '/announcements';

      await Promise.all([
        self.registration.showNotification(truncate(title), {
          body: truncate(body),
          icon: '/icons/icon-192x192.png',
          badge: '/icons/icon-192x192.png',
          tag: payload.tag || 'ammc-announcement',
          data: { url },
        }),
        applyBadge(count),
      ]);
    })()
  );
}) as (event: never) => void);

self.addEventListener('notificationclick', ((event: NotificationEventLike) => {
  event.notification.close();
  const target = event.notification.data?.url || '/announcements';

  event.waitUntil(
    (async () => {
      const clientList = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
      for (const client of clientList) {
        if (client.url.startsWith(self.location.origin)) {
          await client.focus();
          await markReadAndClearBadge();
          return;
        }
      }
      await self.clients.openWindow(target);
      await markReadAndClearBadge();
    })()
  );
}) as (event: never) => void);

// Fires when the browser rotates a subscription. Re-subscribing without
// re-POSTing would silently strand the device, so recover the id from IndexedDB.
self.addEventListener('pushsubscriptionchange', ((event: PushSubscriptionChangeEventLike) => {
  event.waitUntil(
    (async () => {
      try {
        const deviceId = await getDeviceIdForWorker();
        if (!deviceId) return;

        let applicationServerKey: unknown = event.oldSubscription?.options.applicationServerKey ?? null;
        if (!applicationServerKey) {
          const res = await fetch('/api/push/subscribe');
          const config = (await res.json()) as { publicKey?: string | null };
          if (!config.publicKey) return;
          applicationServerKey = urlBase64ToUint8Array(config.publicKey);
        }

        const subscription = await self.registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey,
        });

        await fetch('/api/push/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ deviceId, ...subscription.toJSON() }),
        });
      } catch {
        // Best effort; the page re-subscribes on next load if this fails.
      }
    })()
  );
}) as (event: never) => void);