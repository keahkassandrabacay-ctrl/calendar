'use client';

import React, { useState, useEffect } from 'react';
import {
    Announcement,
    TargetAudience,
    UrgencyLevel,
    DEFAULT_ANNOUNCEMENT_CATEGORIES,
    DEFAULT_DEPARTMENTS,
} from '@/types';
import { Pin, Send, X, Plus, Trash2, FileText, Save } from 'lucide-react';

interface AdminAnnouncementFormProps {
    onSuccess: () => void;
    onCancel: () => void;
    // When provided, the form edits this announcement instead of creating one.
    initialAnnouncement?: Announcement | null;
}

// Formats an ISO timestamp for <input type="datetime-local">.
function toLocalInputValue(iso: string): string {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '';
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

const AUDIENCES: TargetAudience[] = [
    'All Campus',
    'College Students',
    'Senior High School',
    'Faculty & Staff',
    'Alumni & Community',
    'Parents & Guardians',
];

export default function AdminAnnouncementForm({
    onSuccess,
    onCancel,
    initialAnnouncement = null,
}: AdminAnnouncementFormProps) {
    const isEditMode = initialAnnouncement !== null;
    const [title, setTitle] = useState(initialAnnouncement?.title ?? '');
    const [summary, setSummary] = useState(initialAnnouncement?.summary ?? '');
    const [content, setContent] = useState(initialAnnouncement?.content ?? '');
    // Managed vocabulary from /api/categories + /api/departments (defaults as fallback).
    const [category, setCategory] = useState<string>(initialAnnouncement?.category ?? 'Academic');
    const [department, setDepartment] = useState<string>(initialAnnouncement?.department ?? 'Office of the President');
    const [categoryOptions, setCategoryOptions] = useState<string[]>([...DEFAULT_ANNOUNCEMENT_CATEGORIES]);
    const [departmentOptions, setDepartmentOptions] = useState<string[]>([...DEFAULT_DEPARTMENTS]);
    const [audience, setAudience] = useState<TargetAudience>((initialAnnouncement?.audience as TargetAudience) ?? 'All Campus');
    const [urgency, setUrgency] = useState<UrgencyLevel>(initialAnnouncement?.urgency ?? 'normal');
    const [issueDate, setIssueDate] = useState(() =>
        toLocalInputValue(initialAnnouncement?.issue_date ?? initialAnnouncement?.created_at ?? new Date().toISOString())
    );
    const [isPinned, setIsPinned] = useState(initialAnnouncement?.is_pinned ?? false);
    const [attachments, setAttachments] = useState<Array<{ name: string; size: string; url: string }>>(initialAnnouncement?.attachments ?? []);
    const [newAttachmentName, setNewAttachmentName] = useState('');
    
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        const frame = requestAnimationFrame(() => {
            void (async () => {
                try {
                    const [catRes, deptRes] = await Promise.all([
                        fetch('/api/categories'),
                        fetch('/api/departments'),
                    ]);
                    const catData = await catRes.json();
                    const deptData = await deptRes.json();
                    if (Array.isArray(catData.categories) && catData.categories.length > 0) {
                        setCategoryOptions(catData.categories.map((c: { name: string }) => c.name));
                    }
                    if (Array.isArray(deptData.departments) && deptData.departments.length > 0) {
                        setDepartmentOptions(deptData.departments.map((d: { name: string }) => d.name));
                    }
                } catch {
                    // keep defaults
                }
            })();
        });
        return () => cancelAnimationFrame(frame);
    }, []);

    

    const handleAddAttachment = () => {
        if (!newAttachmentName.trim()) return;
        setAttachments((prev) => [...prev,
        {
            name: newAttachmentName.endsWith('.pdf') ? newAttachmentName : `${newAttachmentName}.pdf`,
            size: '1.2 MB',
            url: '#',
        },
        ]);
        setNewAttachmentName('');
    };

    const handleRemoveAttachment = (index: number) => {
        setAttachments((prev) => prev.filter((_, i) => i !== index));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setIsSubmitting(true);

        try {
            const payload = {
                title,
                summary: summary || title,
                content,
                category,
                department,
                audience,
                urgency,
                is_pinned: isPinned,
                attachments,
                issue_date: issueDate ? new Date(issueDate).toISOString() : undefined,
            };
            const res = isEditMode
                ? await fetch('/api/announcements', {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: initialAnnouncement?.id, ...payload }),
                })
                : await fetch('/api/announcements', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload),
                });

            const data = await res.json();
            if (!res.ok) {
                throw new Error(data.error || (isEditMode ? 'Failed to save announcement' : 'Failed to post announcement'));
            }

            onSuccess();
        } catch (err: unknown) {
            const msg = err instanceof Error ? err.message : 'Error posting announcement';
            setError(msg);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E4DF] shadow-sm font-sans-ui space-y-6">
            {/* Header bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E8E4DF] pb-4">
                <div>
                    <h2 className="font-serif-heading text-2xl text-[#262422]">
                        {isEditMode ? 'Edit School Announcement' : 'Create School Announcement'}
                    </h2>
                    <p className="text-xs text-[#6B6862]">
                        {isEditMode
                            ? 'Correct details or update this institutional circular. Saving does not resend notifications.'
                            : 'Draft and publish official institutional circulars to the AMMC.'}
                    </p>
                </div>
            </div>

            {error && (
                <div className="p-3.5 rounded-2xl bg-[#FAF0EB] border border-[#ECCEC1] text-[#9E5B3D] text-xs">
                    {error}
                </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
                {/* Title */}
                <div className="space-y-1">
                    <label className="text-xs font-semibold text-[#3C3A36] uppercase tracking-wider">
                        Announcement Title *
                    </label>
                    <input
                        type="text"
                        required
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="e.g. Schedule of 1st Semester Midterm Examinations A.Y. 2026-2027"
                        className="w-full px-4 py-2.5 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-sm text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                    />
                </div>

                {/* Category, Department, Urgency, Audience */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="space-y-1">
                        <label className="text-xs font-semibold text-[#3C3A36]">Category *</label>
                        <select
                            value={category}
                            onChange={(e) => setCategory(e.target.value)}
                            className="w-full px-3 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                        >
                            {!categoryOptions.includes(category) && (
                                <option value={category}>{category}</option>
                            )}
                            {categoryOptions.map((c) => (
                                <option key={c} value={c}>
                                    {c}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-semibold text-[#3C3A36]">Department *</label>
                        <select
                            value={department}
                            onChange={(e) => setDepartment(e.target.value)}
                            className="w-full px-3 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                        >
                            {!departmentOptions.includes(department) && (
                                <option value={department}>{department}</option>
                            )}
                            {departmentOptions.map((d) => (
                                <option key={d} value={d}>
                                    {d}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-semibold text-[#3C3A36]">Urgency Level *</label>
                        <select
                            value={urgency}
                            onChange={(e) => setUrgency(e.target.value as UrgencyLevel)}
                            className="w-full px-3 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                        >
                            <option value="normal">Normal Notice</option>
                            <option value="important">Important Advisory</option>
                            <option value="critical">Critical Alert / Emergency</option>
                        </select>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-semibold text-[#3C3A36]">Target Audience *</label>
                        <select
                            value={audience}
                            onChange={(e) => setAudience(e.target.value as TargetAudience)}
                            className="w-full px-3 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                        >
                            {AUDIENCES.map((a) => (
                                <option key={a} value={a}>
                                    {a}
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                {/* Issue Date */}
                <div className="space-y-1">
                    <label className="text-xs font-semibold text-[#3C3A36]">
                        Date &amp; Time Issued *
                    </label>
                    <input
                        type="datetime-local"
                        required
                        value={issueDate}
                        onChange={(e) => setIssueDate(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-sm text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                    />
                    <p className="text-[11px] text-[#6B6862]">
                        Shown on the public bulletin and printed on exported PDFs.
                    </p>
                </div>

                {/* Summary */}
                <div className="space-y-1">
                    <label className="text-xs font-semibold text-[#3C3A36]">
                        Brief Summary / Lead Synopsis
                    </label>
                    <input
                        type="text"
                        value={summary}
                        onChange={(e) => setSummary(e.target.value)}
                        placeholder="A short one or two sentence overview shown on preview cards..."
                        className="w-full px-4 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                    />
                </div>

                {/* Full Content */}
                <div className="space-y-1">
                    <label className="text-xs font-semibold text-[#3C3A36]">
                        Official Announcement Content (Markdown Supported) *
                    </label>
                    <textarea
                        required
                        rows={7}
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                        placeholder="Enter the full text, guidelines, instructions, and room schedules here..."
                        className="w-full p-4 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs font-editorial text-[#3C3A36] leading-relaxed focus:outline-none focus:border-[#1F9D55]"
                    />
                </div>

                {/* Attachments & Pinning */}
                <div className="p-4 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] space-y-3">
                    <div className="flex items-center justify-between">
                        <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-[#3C3A36]">
                            <input
                                type="checkbox"
                                checked={isPinned}
                                onChange={(e) => setIsPinned(e.target.checked)}
                                className="rounded accent-[#1F9D55] w-4 h-4"
                            />
                            <span className="flex items-center gap-1">
                                <Pin className="w-3.5 h-3.5 text-[#1F9D55]" />
                                Pin Announcement to Top Banner
                            </span>
                        </label>
                    </div>

                    {/* Attachments Section */}
                    <div className="pt-2 border-t border-[#E8E4DF] space-y-2">
                        <span className="text-[11px] font-semibold text-[#6B6862] block">
                            Attach Official Documents (PDF)
                        </span>
                        <div className="flex gap-2">
                            <input
                                type="text"
                                value={newAttachmentName}
                                onChange={(e) => setNewAttachmentName(e.target.value)}
                                placeholder="e.g. AMMC_Midterm_Schedule_2026.pdf"
                                className="flex-1 px-3 py-1.5 rounded-xl bg-white border border-[#E8E4DF] text-xs text-[#3C3A36]"
                            />
                            <button
                                type="button"
                                onClick={handleAddAttachment}
                                className="px-3 py-1.5 rounded-xl bg-white hover:bg-[#EAF8EF] border border-[#E8E4DF] text-xs font-medium text-[#1F9D55] flex items-center gap-1"
                            >
                                <Plus className="w-3.5 h-3.5" />
                                <span>Add</span>
                            </button>
                        </div>

                        {attachments.length > 0 && (
                            <div className="flex flex-wrap gap-2 pt-1">
                                {attachments.map((att, i) => (
                                    <span
                                        key={i}
                                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-[#E8E4DF] text-xs text-[#3C3A36]"
                                    >
                                        <FileText className="w-3 h-3 text-[#1F9D55]" />
                                        <span>{att.name}</span>
                                        <button
                                            type="button"
                                            onClick={() => handleRemoveAttachment(i)}
                                            className="text-[#9E5B3D] hover:text-red-700 ml-1"
                                        >
                                            <Trash2 className="w-3 h-3" />
                                        </button>
                                    </span>
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                {/* Submit Actions */}
                <div className="flex items-center justify-end gap-3 pt-3">
                    <button
                        type="button"
                        onClick={onCancel}
                        className="px-5 py-2.5 rounded-2xl bg-[#FAF9F6] hover:bg-[#F2EFE9] border border-[#E8E4DF] text-xs font-semibold text-[#3C3A36] transition"
                    >
                        Cancel
                    </button>
                    <button
                        type="submit"
                        disabled={isSubmitting}
                        className="px-6 py-2.5 rounded-2xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-semibold flex items-center gap-2 shadow-sm transition disabled:opacity-50"
                    >
                        {isSubmitting ? (
                            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        ) : (
                            <>
                                {isEditMode ? <Save className="w-3.5 h-3.5" /> : <Send className="w-3.5 h-3.5" />}
                                <span>{isEditMode ? 'Save Changes' : 'Publish Official Announcement'}</span>
                            </>
                        )}
                    </button>
                </div>
            </form>
        </div>
    );
}
