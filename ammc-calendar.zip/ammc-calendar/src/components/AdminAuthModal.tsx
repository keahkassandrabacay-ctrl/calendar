'use client';

import React, { useState } from 'react';
import { X, Lock, Mail, ShieldCheck, ArrowRight, AlertCircle, Sparkles } from 'lucide-react';
import { AdminUser } from '@/types';

interface AdminAuthModalProps {
    isOpen: boolean;
    onClose: () => void;
    onLoginSuccess: (user: AdminUser) => void;
}

export default function AdminAuthModal({
    isOpen,
    onClose,
    onLoginSuccess,
}: AdminAuthModalProps) {
    // const [email, setEmail] = useState('admin@ammc.edu.ph');
    const [email, setEmail] = useState('');

    // const [password, setPassword] = useState('admin123');
    const [password, setPassword] = useState('');

    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    if (!isOpen) return null;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setIsLoading(true);

        try {
            const res = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password }),
            });

            const data = await res.json();

            if (!res.ok) {
                throw new Error(data.error || 'Authentication failed');
            }

            onLoginSuccess(data.user);
            onClose();
        } catch (err: unknown) {
            const msg = err instanceof Error ? err.message : 'Login failed';
            setError(msg);
        } finally {
            setIsLoading(false);
        }
    };

    const setPreset = (roleEmail: string) => {
        setEmail(roleEmail);
        setPassword('admin123');
        setError('');
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2C2A26]/50 backdrop-blur-sm animate-fade-in font-sans-ui">
            <div className="relative w-full max-w-md bg-[#FAF9F6] rounded-3xl border border-[#E8E4DF] shadow-2xl overflow-hidden">
                {/* Header decoration */}
                <div className="bg-[#1F9D55] text-[#FAF9F6] px-6 py-5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-2xl bg-[#168044] flex items-center justify-center border border-[#717154]">
                            <ShieldCheck className="w-5 h-5 text-[#FAF9F6]" />
                        </div>
                        <div>
                            <h3 className="font-serif-heading text-xl text-[#FAF9F6] tracking-tight">Admin Access</h3>
                            <p className="text-[12px] text-[#DDD8CE]">AMMC Administration & Editorial Suite</p>
                        </div>
                    </div>
                    <button
                        onClick={onClose}
                        className="w-8 h-8 rounded-full bg-[#168044]/80 hover:bg-[#168044] text-[#DDD8CE] hover:text-white flex items-center justify-center transition"
                    >
                        <X className="w-4 h-4" />
                    </button>
                </div>

                {/* Content Body */}
                <div className="p-6 sm:p-7 space-y-5">
                    {error && (
                        <div className="p-3.5 rounded-2xl bg-[#FAF0EB] border border-[#ECCEC1] text-[#9E5B3D] text-xs flex items-start gap-2.5">
                            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                            <span>{error}</span>
                        </div>
                    )}

                    {/* Quick Pre-fill Credentials */}
                    {/* <div className="p-3.5 rounded-2xl bg-[#EAF8EF] border border-[#B2E6C4] text-xs">
 <div className="flex items-center gap-1.5 font-semibold text-[#0E562D] mb-2">
 <Sparkles className="w-3.5 h-3.5" />
 <span>Quick Test Accounts (Password: <code>admin123</code>):</span>
 </div>
 <div className="flex flex-wrap gap-1.5">
 <button
 type="button"
 onClick={() => setPreset('admin@ammc.edu.ph')}
 className="px-2.5 py-1 rounded-full bg-white border border-[#B2E6C4] hover:border-[#1F9D55] text-[#0E562D] transition text-[11px] font-medium"
 >
 Super Admin
 </button>
 <button
 type="button"
 onClick={() => setPreset('registrar@ammc.edu.ph')}
 className="px-2.5 py-1 rounded-full bg-white border border-[#B2E6C4] hover:border-[#1F9D55] text-[#0E562D] transition text-[11px] font-medium"
 >
 Registrar
 </button>
 <button
 type="button"
 onClick={() => setPreset('studentaffairs@ammc.edu.ph')}
 className="px-2.5 py-1 rounded-full bg-white border border-[#B2E6C4] hover:border-[#1F9D55] text-[#0E562D] transition text-[11px] font-medium"
 >
 Student Affairs
 </button>
 </div>
 </div> */}

                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="space-y-1.5">
                            <label className="text-xs font-semibold text-[#3C3A36] uppercase tracking-wider">
                                Email
                            </label>
                            <div className="relative">
                                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6B6862]" />
                                <input
                                    type="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                    placeholder="email@ammc.edu.ph"
                                    className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white border border-[#E8E4DF] text-sm text-[#3C3A36] focus:outline-none focus:border-[#1F9D55] focus:ring-2 focus:ring-[#1F9D55]/15 transition"
                                />
                            </div>
                        </div>

                        <div className="space-y-1.5">
                            <label className="text-xs font-semibold text-[#3C3A36] uppercase tracking-wider">
                                Password
                            </label>
                            <div className="relative">
                                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6B6862]" />
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                    placeholder="••••••••"
                                    className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white border border-[#E8E4DF] text-sm text-[#3C3A36] focus:outline-none focus:border-[#1F9D55] focus:ring-2 focus:ring-[#1F9D55]/15 transition"
                                />
                            </div>
                        </div>

                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full py-3 px-5 rounded-2xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] font-medium text-sm flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition duration-200 disabled:opacity-50"
                        >
                            {isLoading ? (
                                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            ) : (
                                <>
                                    <span>Authenticate</span>
                                    <ArrowRight className="w-4 h-4" />
                                </>
                            )}
                        </button>
                    </form>
                </div>

                <div className="bg-[#F4EFEA] px-6 py-3 border-t border-[#E8E4DF] text-center">
                    <p className="text-[11px] text-[#6B6862]">
                        Dr. Aurelio Mendoza Memorial Colleges • Authentication
                    </p>
                </div>
            </div>
        </div>
    );
}
