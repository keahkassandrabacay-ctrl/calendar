'use client';

import React, { useState, useEffect } from 'react';
import { EventCategory, TargetAudience, SchoolEvent, DEFAULT_DEPARTMENTS } from '@/types';
import { Calendar, Clock, MapPin, Users, Send, X, Sparkles, Save } from 'lucide-react';

interface AdminEventFormProps {
  onSuccess: () => void;
  onCancel: () => void;
  // When provided, the form edits this event instead of creating one.
  initialEvent?: SchoolEvent | null;
}

const EVENT_CATEGORIES: EventCategory[] = [
  'Academic Calendar',
  'Campus Life & Culture',
  'Athletics & Sports',
  'Seminars & Workshops',
  'Examinations',
  'Holidays & Observances',
  'Alumni & Community',
];

// Module scope: formats an ISO timestamp for <input type="datetime-local">.
function toLocalInputValue(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export default function AdminEventForm({
  onSuccess,
  onCancel,
  initialEvent = null,
}: AdminEventFormProps) {
  const isEditMode = initialEvent !== null;
  const [title, setTitle] = useState(initialEvent?.title ?? '');
  const [description, setDescription] = useState(initialEvent?.description ?? '');
  const [location, setLocation] = useState(initialEvent?.location ?? '');
  const [category, setCategory] = useState<EventCategory>((initialEvent?.category as EventCategory) ?? 'Campus Life & Culture');
  const [startTime, setStartTime] = useState(initialEvent ? toLocalInputValue(initialEvent.start_time) : '2026-09-10T09:00');
  const [endTime, setEndTime] = useState(initialEvent ? toLocalInputValue(initialEvent.end_time) : '2026-09-10T12:00');
  const [capacity, setCapacity] = useState(initialEvent ? String(initialEvent.capacity) : '250');
  const [organizer, setOrganizer] = useState(initialEvent?.organizer ?? 'Office of Student Affairs');
  const [targetAudience, setTargetAudience] = useState<TargetAudience>(initialEvent?.target_audience ?? 'All Campus');
  const [department, setDepartment] = useState<string>('All Departments');
  const [departmentOptions, setDepartmentOptions] = useState<string[]>([...DEFAULT_DEPARTMENTS]);
  const [isFeatured, setIsFeatured] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      void (async () => {
        try {
          const res = await fetch('/api/departments');
          const data = await res.json();
          if (Array.isArray(data.departments) && data.departments.length > 0) {
            setDepartmentOptions(data.departments.map((d: { name: string }) => d.name));
          }
        } catch {
          // keep defaults
        }
      })();
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  const isHoliday = category === 'Holidays & Observances';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!isHoliday && !location.trim()) {
      setError('Venue / Location is required for non-holiday events.');
      return;
    }
    setIsSubmitting(true);

    try {
      const payload = {
        title,
        description,
        location: location.trim() || (isHoliday ? 'Nationwide Observance' : ''),
        category,
        start_time: new Date(startTime).toISOString(),
        end_time: new Date(endTime).toISOString(),
        capacity: Number(capacity) || 0,
        organizer,
        target_audience: targetAudience,
        department,
        is_featured: isFeatured,
      };
      const res = isEditMode
        ? await fetch('/api/events', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: initialEvent?.id, ...payload }),
        })
        : await fetch('/api/events', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || (isEditMode ? 'Failed to save event' : 'Failed to create event'));
      }

      onSuccess();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error creating event';
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E8E4DF] shadow-sm font-sans-ui space-y-6">
      <div className="border-b border-[#E8E4DF] pb-4">
        <h2 className="font-serif-heading text-2xl text-[#262422]">
          {isEditMode ? 'Edit Campus Event' : 'Schedule New Campus Event'}
        </h2>
        <p className="text-xs text-[#6B6862]">
          {isEditMode
            ? 'Correct details or reschedule this entry. Saving does not resend notifications.'
            : 'Create calendar entries, symposiums, athletic matches and institutional gatherings.'}
        </p>
      </div>

      {error && (
        <div className="p-3.5 rounded-2xl bg-[#FAF0EB] border border-[#ECCEC1] text-[#9E5B3D] text-xs">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Title */}
        <div className="space-y-1">
          <label className="text-xs font-semibold text-[#3C3A36] uppercase tracking-wider">
            Event Title *
          </label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. General Student Convocation & Leadership Assembly 2026"
            className="w-full px-4 py-2.5 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-sm text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
          />
        </div>

        {/* Category & Location */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-[#3C3A36]">Category *</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as EventCategory)}
              className="w-full px-3 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36]"
            >
              {!EVENT_CATEGORIES.includes(category) && (
                <option value={category}>{category}</option>
              )}
              {EVENT_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-[#3C3A36]">
              Venue / Location {isHoliday ? <span className="font-normal text-[#6B6862]">(optional for Holidays)</span> : '*'}
            </label>
            <input
              type="text"
              required={!isHoliday}
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder={isHoliday ? 'e.g. Nationwide Observance or leave empty' : 'e.g. AMMC Main Auditorium & Performing Arts Hall'}
              className="w-full px-4 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
            />
            {isHoliday && <p className="text-[11px] text-[#6B6862]">Holidays use `Nationwide Observance` if left empty.</p>}
          </div>
        </div>

        {/* Start and End Date Time */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-[#3C3A36]">Start Date & Time *</label>
            <input
              type="datetime-local"
              required
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              className="w-full px-3 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36]"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-[#3C3A36]">End Date & Time *</label>
            <input
              type="datetime-local"
              required
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
              className="w-full px-3 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36]"
            />
          </div>
        </div>

        {/* Capacity, Organizer, Target Audience, Department */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-[#3C3A36]">Seating Limit (0 = Unlimited)</label>
            <input
              type="number"
              min="0"
              value={capacity}
              onChange={(e) => setCapacity(e.target.value)}
              placeholder="e.g. 300"
              className="w-full px-3 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36]"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-[#3C3A36]">Organizer / Unit</label>
            <input
              type="text"
              value={organizer}
              onChange={(e) => setOrganizer(e.target.value)}
              placeholder="e.g. Supreme Student Council"
              className="w-full px-3 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36]"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-[#3C3A36]">Department</label>
            <select
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="w-full px-3 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36]"
            >
              {!departmentOptions.includes(department) && (
                <option value={department}>{department}</option>
              )}
              {departmentOptions.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-[#3C3A36]">Audience</label>
            <select
              value={targetAudience}
              onChange={(e) => setTargetAudience(e.target.value as TargetAudience)}
              className="w-full px-3 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36]"
            >
              <option>All Campus</option>
              <option>College Students</option>
              <option>Senior High School</option>
              <option>Faculty & Staff</option>
              <option>Alumni & Community</option>
            </select>
          </div>
        </div>

        {/* Description */}
        <div className="space-y-1">
          <label className="text-xs font-semibold text-[#3C3A36]">
            Event Description & Program Agenda
          </label>
          <textarea
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Provide program flow, requirements, speaker backgrounds..."
            className="w-full p-4 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs font-editorial text-[#3C3A36] leading-relaxed"
          />
        </div>

        {/* Featured Flag */}
        <div className="p-3.5 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF]">
          <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-[#3C3A36]">
            <input
              type="checkbox"
              checked={isFeatured}
              onChange={(e) => setIsFeatured(e.target.checked)}
              className="rounded accent-[#1F9D55] w-4 h-4"
            />
            <span>Highlight as Featured Campus Event</span>
          </label>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-3 pt-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-5 py-2.5 rounded-2xl bg-[#FAF9F6] hover:bg-[#F2EFE9] border border-[#E8E4DF] text-xs font-semibold text-[#3C3A36]"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-6 py-2.5 rounded-2xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-semibold flex items-center gap-2 shadow-sm disabled:opacity-50"
          >
            {isSubmitting ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                {isEditMode ? <Save className="w-3.5 h-3.5" /> : <Send className="w-3.5 h-3.5" />}
                <span>{isEditMode ? 'Save Changes' : 'Publish Event to School Calendar'}</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
