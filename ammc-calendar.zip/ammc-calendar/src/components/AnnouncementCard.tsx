'use client';

import React, { useState } from 'react';
import { Announcement } from '@/types';
import { format } from 'date-fns';
import { Pin, Bookmark, Sparkles, Clock, Share2, FileText, ArrowRight, Heart, ThumbsUp, PartyPopper } from 'lucide-react';

interface AnnouncementCardProps {
  announcement: Announcement;
  onOpen: (announcement: Announcement) => void;
  isBookmarked?: boolean;
  onToggleBookmark?: (id: string) => void;
}

export default function AnnouncementCard({
  announcement,
  onOpen,
  isBookmarked = false,
  onToggleBookmark,
}: AnnouncementCardProps) {
  const [reactions, setReactions] = useState(
    announcement.reactions || { helpful: 0, heart: 0, celebrate: 0 }
  );
  const [hasReacted, setHasReacted] = useState<{ [key: string]: boolean }>({});

  const handleReact = async (e: React.MouseEvent, type: 'helpful' | 'heart' | 'celebrate') => {
    e.stopPropagation();
    if (hasReacted[type]) return;

    // Optimistic update
    setReactions((prev) => ({
      ...prev,
      [type]: (prev[type] || 0) + 1,
    }));
    setHasReacted((prev) => ({ ...prev, [type]: true }));

    try {
      await fetch(`/api/announcements/${announcement.id}/react`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type }),
      });
    } catch {
      // ignore
    }
  };

  const getUrgencyBadge = () => {
    switch (announcement.urgency) {
      case 'critical':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-[#FAF0EB] text-[#B56E4D] border border-[#ECCEC1]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#B56E4D] animate-pulse" />
            Critical Alert
          </span>
        );
      case 'important':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-[#FBF2EC] text-[#AC6243] border border-[#F0D5C7]">
            Important Advisory
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-[#EAF8EF] text-[#1F9D55] border border-[#B2E6C4]">
            General Notice
          </span>
        );
    }
  };

  const getCategoryClass = () => {
    switch (announcement.category) {
      case 'Academic':
        return 'badge-olive';
      case 'Student Affairs':
        return 'badge-terracotta';
      case 'Sports & Athletics':
        return 'badge-clay';
      case 'Scholarships & Grants':
        return 'badge-sage';
      case 'Campus Advisory':
        return 'badge-slate';
      default:
        return 'badge-sandstone';
    }
  };

  return (
    <article
      onClick={() => onOpen(announcement)}
      className="natural-card rounded-3xl p-6 cursor-pointer flex flex-col justify-between group relative overflow-hidden"
    >
      {/* Top Meta Line */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2 flex-wrap">
            {announcement.is_pinned && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-[#1F9D55] text-[#FAF9F6]">
                <Pin className="w-3 h-3 fill-current" />
                Pinned
              </span>
            )}
            {getUrgencyBadge()}
            <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-medium ${getCategoryClass()}`}>
              {announcement.category}
            </span>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              if (onToggleBookmark) onToggleBookmark(announcement.id);
            }}
            title={isBookmarked ? 'Remove Bookmark' : 'Bookmark Announcement'}
            className={`p-2 rounded-full border transition ${
              isBookmarked
                ? 'bg-[#1F9D55] border-[#168044] text-[#FAF9F6]'
                : 'bg-white/80 border-[#E8E4DF] text-[#6B6862] hover:text-[#3C3A36] hover:bg-[#FAF9F6]'
            }`}
          >
            <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Title */}
        <h3 className="font-serif-heading text-xl sm:text-2xl text-[#262422] group-hover:text-[#1F9D55] transition-colors line-clamp-2 leading-snug mb-2.5">
          {announcement.title}
        </h3>

        {/* Summary */}
        <p className="text-xs sm:text-sm text-[#6B6862] line-clamp-3 leading-relaxed mb-4">
          {announcement.summary}
        </p>
      </div>

      {/* Footer Info */}
      <div className="pt-4 border-t border-[#E8E4DF] space-y-3">
        {/* Issued date/time */}
        <div className="flex items-center justify-between text-xs text-[#6B6862]">
          <span className="font-medium text-[#3C3A36] truncate max-w-[160px]">
            {announcement.department}
          </span>
          <span
            className="shrink-0 font-medium text-[#3C3A36]"
            title={`Issued ${format(new Date(announcement.issue_date ?? announcement.created_at), 'PPP')}`}
          >
            {format(new Date(announcement.issue_date ?? announcement.created_at), 'MMM d, yyyy • h:mm a')}
          </span>
        </div>

        {/* Interactive Reactions and Read More */}
        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={(e) => handleReact(e, 'helpful')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs transition border ${
                hasReacted.helpful
                  ? 'bg-[#EAF8EF] text-[#0E562D] border-[#B2E6C4]'
                  : 'bg-[#FAF9F6] text-[#6B6862] border-[#E8E4DF] hover:border-[#1F9D55]'
              }`}
            >
              <ThumbsUp className="w-3 h-3" />
              <span>{reactions.helpful || 0}</span>
            </button>

            <button
              type="button"
              onClick={(e) => handleReact(e, 'heart')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs transition border ${
                hasReacted.heart
                  ? 'bg-[#FAF0EB] text-[#B56E4D] border-[#ECCEC1]'
                  : 'bg-[#FAF9F6] text-[#6B6862] border-[#E8E4DF] hover:border-[#B56E4D]'
              }`}
            >
              <Heart className="w-3 h-3" />
              <span>{reactions.heart || 0}</span>
            </button>

            <button
              type="button"
              onClick={(e) => handleReact(e, 'celebrate')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs transition border ${
                hasReacted.celebrate
                  ? 'bg-[#FBF2EC] text-[#AC6243] border-[#F0D5C7]'
                  : 'bg-[#FAF9F6] text-[#6B6862] border-[#E8E4DF] hover:border-[#AC6243]'
              }`}
            >
              <PartyPopper className="w-3 h-3" />
              <span>{reactions.celebrate || 0}</span>
            </button>
          </div>

          <div className="flex items-center gap-1 text-xs font-semibold text-[#1F9D55] group-hover:translate-x-0.5 transition">
            <span>Read Details</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>
    </article>
  );
}
