'use client';

import React, { useState } from 'react';
import { Announcement } from '@/types';
import { X, Calendar, User, Eye, Share2, Volume2, VolumeX, Download, FileText, Check, MessageSquare, Send, Sparkles, Pencil } from 'lucide-react';
import { format } from 'date-fns';
import PdfDownloadButton from './PdfDownloadButton';

interface AnnouncementModalProps {
    announcement: Announcement | null;
    isOpen: boolean;
    onClose: () => void;
    // When the viewer is an admin, show an Edit button that jumps to the editor.
    isAdmin?: boolean;
    onEdit?: (announcement: Announcement) => void;
}

export default function AnnouncementModal({
    announcement,
    isOpen,
    onClose,
    isAdmin = false,
    onEdit,
}: AnnouncementModalProps) {
    const [copied, setCopied] = useState(false);
    const [isSpeaking, setIsSpeaking] = useState(false);
    const [commentText, setCommentText] = useState('');
    // const [comments, setComments] = useState<Array<{ name: string; dept: string; text: string; time: string }>>([
    // {
    // name: 'Angela Nicole Cruz',
    // dept: 'BS Nursing (Level III)',
    // text: 'Thank you for this official advisory! Will clinical makeup duties follow the same schedule?',
    // time: '2 hours ago',
    // },
    // ]);
    const [comments, setComments] = useState<Array<{ name: string; dept: string; text: string; time: string }>>([]);

    if (!isOpen || !announcement) return null;

    const handleShare = async () => {
        const url = typeof window !== 'undefined' ? window.location.href : '';
        if (!url) return;
        try {
            if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
                await navigator.clipboard.writeText(url);
            } else if (typeof document !== 'undefined') {
                // Fallback for insecure contexts / old browsers
                const ta = document.createElement('textarea');
                ta.value = url;
                ta.setAttribute('readonly', '');
                ta.style.position = 'fixed';
                ta.style.opacity = '0';
                document.body.appendChild(ta);
                ta.select();
                // document.execCommand is deprecated but kept as a fallback
                // for insecure contexts / old browsers without Clipboard API.
                document.execCommand('copy');
                document.body.removeChild(ta);
            } else {
                throw new Error('Clipboard not available');
            }
            setCopied(true);
            setTimeout(() => setCopied(false), 2500);
        } catch (err) {
            console.error('Share failed:', err);
            // Still give feedback; fallback to prompt
            try {
                if (typeof window !== 'undefined' && typeof window.prompt === 'function') {
                    window.prompt('Copy this link:', url);
                }
            } catch {
                // ignore
            }
        }
    };

    

    const handleToggleSpeech = () => {
        try {
            if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
            if (isSpeaking) {
                window.speechSynthesis?.cancel();
                setIsSpeaking(false);
            } else {
                const text = `${announcement.title}. ${announcement.content}`;
                if (!text.trim()) return;
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.onend = () => setIsSpeaking(false);
                utterance.onerror = () => setIsSpeaking(false);
                window.speechSynthesis.speak(utterance);
                setIsSpeaking(true);
            }
        } catch (err) {
            console.error('Speech failed:', err);
            setIsSpeaking(false);
        }
    };

    const handleAddComment = (e: React.FormEvent) => {
        e.preventDefault();
        if (!commentText.trim()) return;
        setComments((prev) => [...prev,
        {
            name: 'AMMC Student Inquirer',
            dept: 'Collegiate Division',
            text: commentText.trim(),
            time: 'Just now',
        },
        ]);
        setCommentText('');
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2C2A26]/50 backdrop-blur-sm animate-fade-in font-sans-ui">
            <div className="relative w-full max-w-3xl max-h-[90vh] bg-[#FAF9F6] rounded-3xl border border-[#E8E4DF] shadow-2xl flex flex-col overflow-hidden">
                {/* Header Toolbar */}
                <div className="bg-[#FAF9F6] border-b border-[#E8E4DF] px-6 py-4 flex items-center justify-between shrink-0">
                    <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-[#1F9D55] text-[#FAF9F6]">
                            {announcement.category}
                        </span>
                        <span className="text-xs text-[#6B6862]">
                            {announcement.department}
                        </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                        {isAdmin && onEdit && (
                            <button
                                onClick={() => onEdit(announcement)}
                                title="Edit Announcement"
                                className="p-2 rounded-full bg-[#EAF8EF] border border-[#B2E6C4] text-[#1F9D55] hover:bg-[#E4E6DA] text-xs transition flex items-center gap-1.5 px-3"
                            >
                                <Pencil className="w-4 h-4" />
                                <span className="font-semibold">Edit</span>
                            </button>
                        )}
                        <button
                            onClick={handleToggleSpeech}
                            title={isSpeaking ? 'Stop Reading' : 'Listen with Audio Reader'}
                            className={`p-2 rounded-full border text-xs transition ${isSpeaking
                                ? 'bg-[#B56E4D] border-[#9E5B3D] text-white animate-pulse'
                                : 'bg-white border-[#E8E4DF] text-[#6B6862] hover:text-[#3C3A36]'
                                }`}
                        >
                            {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                        </button>

                        <button
                            onClick={handleShare}
                            title="Copy Announcement Link"
                            className="p-2 rounded-full bg-white border border-[#E8E4DF] text-[#6B6862] hover:text-[#3C3A36] text-xs transition"
                        >
                            {copied ? <Check className="w-4 h-4 text-[#5B7B68]" /> : <Share2 className="w-4 h-4" />}
                        </button>

                        <PdfDownloadButton
                            id={announcement.id}
                            title="Download this circular as PDF"
                            className="p-2 rounded-full bg-white border border-[#E8E4DF] text-[#6B6862] hover:text-[#3C3A36] transition"
                        />

                        <button
                            onClick={onClose}
                            className="w-8 h-8 rounded-full bg-[#E8E4DF] hover:bg-[#DDD7CE] text-[#3C3A36] flex items-center justify-center transition ml-2"
                        >
                            <X className="w-4 h-4" />
                        </button>
                    </div>
                </div>

                {/* Modal Scrollable Body */}
                <div className="p-6 sm:p-8 overflow-y-auto space-y-6 flex-1">
                    {/* Title and Metadata */}
                    <div>
                        <div className="flex flex-wrap items-center gap-y-1 gap-x-3 text-xs text-[#6B6862] mb-2">
                            <span className="flex items-center gap-1">
                                <Calendar className="w-3.5 h-3.5 text-[#1F9D55]" />
                                Issued {format(new Date(announcement.issue_date ?? announcement.created_at), 'EEEE, MMMM d, yyyy • h:mm a')}
                            </span>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                                <User className="w-3.5 h-3.5 text-[#1F9D55]" />
                                {announcement.author_name}
                            </span>
                            <span>•</span>
                            <span className="px-2 py-0.5 rounded-full bg-[#EAF8EF] text-[#0E562D] font-medium text-[11px]">
                                Target: {announcement.audience}
                            </span>
                        </div>

                        <h1 className="font-serif-heading text-2xl sm:text-3xl text-[#262422] leading-tight">
                            {announcement.title}
                        </h1>
                    </div>

                    {/* Highlight Summary */}
                    <div className="p-4 rounded-2xl bg-[#F4EFEA] border-l-4 border-l-[#1F9D55] text-sm text-[#3C3A36] font-medium leading-relaxed">
                        {announcement.summary}
                    </div>

                    {/* Rich Content */}
                    <div className="font-editorial text-[#3C3A36] text-base leading-relaxed space-y-4 whitespace-pre-line bg-white p-6 rounded-2xl border border-[#E8E4DF]">
                        {announcement.content}
                    </div>

                    {/* Official Attachments */}
                    {announcement.attachments && announcement.attachments.length > 0 && (
                        <div className="space-y-2">
                            <h4 className="text-xs font-semibold text-[#6B6862] uppercase tracking-wider">
                                Official Documents & Circular Attachments
                            </h4>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                {announcement.attachments.map((file, idx) => (
                                    <div
                                        key={idx}
                                        className="flex items-center justify-between p-3 rounded-xl bg-white border border-[#E8E4DF] hover:border-[#1F9D55] transition"
                                    >
                                        <div className="flex items-center gap-2.5 min-w-0">
                                            <FileText className="w-4 h-4 text-[#1F9D55] shrink-0" />
                                            <div className="truncate">
                                                <p className="text-xs font-medium text-[#3C3A36] truncate">{file.name}</p>
                                                <p className="text-[10px] text-[#6B6862]">{file.size}</p>
                                            </div>
                                        </div>
                                        <button
                                            onClick={() => alert(`Downloading verified document: ${file.name}`)}
                                            className="p-1.5 rounded-lg bg-[#FAF9F6] hover:bg-[#EAF8EF] text-[#1F9D55] border border-[#E8E4DF] transition"
                                            title="Download PDF"
                                        >
                                            <Download className="w-3.5 h-3.5" />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Student Q&A & Inquiries */}
                    {/* <div className="pt-4 border-t border-[#E8E4DF] space-y-3">
                        <div className="flex items-center gap-2 text-xs font-semibold text-[#3C3A36]">
                            <MessageSquare className="w-4 h-4 text-[#1F9D55]" />
                            <span>Student Inquiries & Discussion ({comments.length})</span>
                        </div>

                        <div className="space-y-2">
                            {comments.map((c, i) => (
                                <div key={i} className="p-3 rounded-2xl bg-white border border-[#E8E4DF] text-xs space-y-1">
                                    <div className="flex items-center justify-between">
                                        <span className="font-semibold text-[#3C3A36]">{c.name}</span>
                                        <span className="text-[10px] text-[#6B6862]">{c.time}</span>
                                    </div>
                                    <div className="text-[11px] text-[#1F9D55] font-medium">{c.dept}</div>
                                    <p className="text-[#3C3A36] text-xs pt-1">{c.text}</p>
                                </div>
                            ))}
                        </div>

                        <form onSubmit={handleAddComment} className="flex gap-2 pt-1">
                            <input
                                type="text"
                                value={commentText}
                                onChange={(e) => setCommentText(e.target.value)}
                                placeholder="Ask a question or post a query regarding this advisory..."
                                className="flex-1 px-3.5 py-2 rounded-2xl bg-white border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                            />
                            <button
                                type="submit"
                                className="px-4 py-2 rounded-2xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-medium flex items-center gap-1.5 transition"
                            >
                                <Send className="w-3.5 h-3.5" />
                                <span>Post</span>
                            </button>
                        </form>
                    </div> */}
                </div>

                {/* Modal Footer */}
                <div className="bg-[#FAF9F6] border-t border-[#E8E4DF] px-6 py-3 flex items-center justify-between text-xs text-[#6B6862]">
                    <span>Dr. Aurelio Mendoza Memorial Colleges Public </span>
                    <button
                        onClick={onClose}
                        className="px-4 py-1.5 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#F2EFE9] text-[#3C3A36] font-medium transition"
                    >
                        Close
                    </button>
                </div>
            </div>
        </div>
    );
}
