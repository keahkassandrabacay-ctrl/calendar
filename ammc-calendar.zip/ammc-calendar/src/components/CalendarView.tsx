'use client';

import React, { useState, useEffect } from 'react';
import { SchoolEvent, EventCategory } from '@/types';
import {
  format,
  addMonths,
  subMonths,
  startOfWeek,
  endOfWeek,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  addDays,
  subDays,
} from 'date-fns';
import {
  ChevronLeft,
  ChevronRight,
  Calendar as CalendarIcon,
  MapPin,
  Clock,
  Filter,
  List,
  Grid,
  ChevronDown,
  X,
} from 'lucide-react';
import PdfDownloadButton from './PdfDownloadButton';

interface CalendarViewProps {
  events: SchoolEvent[];
  onSelectEvent: (event: SchoolEvent) => void;
}

const CATEGORIES: Array<EventCategory | 'All'> = [
  'All',
  'Academic Calendar',
  'Campus Life & Culture',
  'Athletics & Sports',
  'Seminars & Workshops',
  'Examinations',
  'Holidays & Observances',
  'Administrative & Faculty Meetings',
  'Alumni & Community',
];

// Surfaced as one-tap pills; the full list stays in the dropdown.
const HOT_CATEGORIES: EventCategory[] = [
  'Academic Calendar',
  'Examinations',
  'Holidays & Observances',
  'Campus Life & Culture',
];

// School timezone: bucket and display event times in Asia/Manila so the
// calendar reads the same for every viewer regardless of device timezone.
const MANILA_TZ = 'Asia/Manila';
const manilaDayFmt = new Intl.DateTimeFormat('en-CA', {
  timeZone: MANILA_TZ,
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
});
const manilaTimeFmt = new Intl.DateTimeFormat('en-US', {
  timeZone: MANILA_TZ,
  hour: 'numeric',
  minute: '2-digit',
});
const manilaWeekdayFmt = new Intl.DateTimeFormat('en-US', {
  timeZone: MANILA_TZ,
  weekday: 'long',
});
const manilaMonthFmt = new Intl.DateTimeFormat('en-US', {
  timeZone: MANILA_TZ,
  month: 'short',
});
const manilaDayNumFmt = new Intl.DateTimeFormat('en-US', {
  timeZone: MANILA_TZ,
  day: 'numeric',
});
const manilaLongFmt = new Intl.DateTimeFormat('en-US', {
  timeZone: MANILA_TZ,
  weekday: 'long',
  month: 'long',
  day: 'numeric',
  year: 'numeric',
});
const manilaDayKey = (d: Date) => manilaDayFmt.format(d);

export default function CalendarView({
  events,
  onSelectEvent,
}: CalendarViewProps) {
  // Real today, set post-mount to avoid a server/client hydration mismatch.
  const [currentDate, setCurrentDate] = useState<Date | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [activeCategory, setActiveCategory] = useState<EventCategory | 'All'>('All');
  const [viewMode, setViewMode] = useState<'month' | 'agenda'>('month');
  const [isCategoryPanelOpen, setIsCategoryPanelOpen] = useState(false);
  const categoryFilterCount = activeCategory !== 'All' ? 1 : 0;

  const filteredEvents = events.filter((e) => {
    if (activeCategory !== 'All' && e.category !== activeCategory) {
      return false;
    }
    return true;
  });

  const nextMonth = () => setCurrentDate((d) => (d ? addMonths(d, 1) : d));
  const prevMonth = () => setCurrentDate((d) => (d ? subMonths(d, 1) : d));
  const goToToday = () => {
    const today = new Date();
    setCurrentDate(today);
    setSelectedDate(today);
  };

  // Real today is set post-mount (see state above).
  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      const today = new Date();
      setCurrentDate(today);
      setSelectedDate(today);
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  if (!currentDate || !selectedDate) {
    return (
      <div className="h-96 rounded-3xl bg-white border border-[#E8E4DF] animate-pulse flex items-center justify-center">
        <div className="text-center space-y-2 text-[#6B6862] text-xs">
          <CalendarIcon className="w-8 h-8 text-[#1F9D55] mx-auto animate-bounce" />
          <p>Loading school schedule calendar...</p>
        </div>
      </div>
    );
  }

  // Month grid days calculation
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart);
  const endDate = endOfWeek(monthEnd);
  const daysInMonthGrid = eachDayOfInterval({ start: startDate, end: endDate });
  const todayKey = manilaDayKey(new Date());

  const getEventsForDay = (day: Date) => {
    const key = manilaDayKey(day);
    return filteredEvents.filter((e) => manilaDayKey(new Date(e.start_time)) === key);
  };

  const selectedDayEvents = getEventsForDay(selectedDate);

  const getCategoryDotColor = (category: EventCategory) => {
    switch (category) {
      case 'Academic Calendar':
        return 'bg-[#1F9D55]';
      case 'Campus Life & Culture':
        return 'bg-[#5B7B68]';
      case 'Athletics & Sports':
        return 'bg-[#C47C5D]';
      case 'Seminars & Workshops':
        return 'bg-[#5A6B7C]';
      case 'Examinations':
        return 'bg-[#B56E4D]';
      case 'Holidays & Observances':
        return 'bg-[#8C7D6B]';
      default:
        return 'bg-[#1F9D55]';
    }
  };

  return (
    <div className="space-y-6 font-sans-ui">
      {/* Top Filter and View Switcher Bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-white p-4 rounded-3xl border border-[#E8E4DF]">
        {/* Category Pills */}
        <div className="w-full md:w-auto min-w-0">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
          <span className="text-xs font-semibold text-[#6B6862] mr-1 shrink-0 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-[#1F9D55]" />
            Filter:
          </span>
          {(['All', ...HOT_CATEGORIES] as Array<EventCategory | 'All'>).map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition ${
                activeCategory === cat
                  ? 'bg-[#1F9D55] text-[#FAF9F6] shadow-sm'
                  : 'bg-[#FAF9F6] text-[#6B6862] hover:text-[#3C3A36] border border-[#E8E4DF]'
              }`}
            >
              {cat === 'All' ? 'All' : cat}
            </button>
          ))}
          <button
            onClick={() => setIsCategoryPanelOpen((v) => !v)}
            aria-expanded={isCategoryPanelOpen}
            className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium border transition ${
              categoryFilterCount > 0
                ? 'bg-[#1F9D55] border-[#168044] text-[#FAF9F6]'
                : 'bg-[#FAF9F6] border-[#E8E4DF] text-[#6B6862] hover:text-[#3C3A36]'
            }`}
          >
            <span>
              {categoryFilterCount > 0 && !HOT_CATEGORIES.includes(activeCategory as EventCategory)
                ? activeCategory
                : 'More'}
            </span>
            <ChevronDown className={`w-3 h-3 transition-transform ${isCategoryPanelOpen ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {isCategoryPanelOpen && (
          <div className="mt-3 pt-3 border-t border-[#E8E4DF] flex flex-wrap gap-1.5 animate-fade-in">
            {CATEGORIES.filter((c) => c !== 'All').map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition ${
                  activeCategory === cat
                    ? 'bg-[#1F9D55] text-[#FAF9F6] shadow-sm'
                    : 'bg-[#FAF9F6] text-[#6B6862] hover:text-[#3C3A36] border border-[#E8E4DF]'
                }`}
              >
                {cat}
              </button>
            ))}
            {categoryFilterCount > 0 && (
              <button
                onClick={() => setActiveCategory('All')}
                className="flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium bg-[#FAF0EB] border border-[#ECCEC1] text-[#9E5B3D] transition hover:bg-[#F8E3D8]"
              >
                <X className="w-3 h-3" />
                <span>Clear</span>
              </button>
            )}
          </div>
        )}
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center gap-1 bg-[#FAF9F6] p-1 rounded-2xl border border-[#E8E4DF] shrink-0">
          <button
            onClick={() => setViewMode('month')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-medium transition ${
              viewMode === 'month'
                ? 'bg-white text-[#3C3A36] shadow-xs'
                : 'text-[#6B6862] hover:text-[#3C3A36]'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span>Month View</span>
          </button>
          <button
            onClick={() => setViewMode('agenda')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-medium transition ${
              viewMode === 'agenda'
                ? 'bg-white text-[#3C3A36] shadow-xs'
                : 'text-[#6B6862] hover:text-[#3C3A36]'
            }`}
          >
            <List className="w-3.5 h-3.5" />
            <span>Schedule Agenda</span>
          </button>
        </div>
      </div>

      {viewMode === 'month' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Month Grid (8 columns) */}
          <div className="lg:col-span-8 bg-white rounded-3xl p-5 sm:p-6 border border-[#E8E4DF] shadow-sm">
            {/* Calendar Controls */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <h2 className="font-serif-heading text-2xl sm:text-3xl text-[#262422]">
                  {format(currentDate, 'MMMM yyyy')}
                </h2>
                <button
                  onClick={goToToday}
                  className="text-xs px-2.5 py-1 rounded-lg bg-[#FAF9F6] border border-[#E8E4DF] hover:bg-[#F2EFE9] text-[#3C3A36] font-medium transition"
                >
                  Today
                </button>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={prevMonth}
                  className="p-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] hover:bg-[#EAF8EF] text-[#3C3A36] transition"
                  title="Previous Month"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={nextMonth}
                  className="p-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] hover:bg-[#EAF8EF] text-[#3C3A36] transition"
                  title="Next Month"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Days of Week Header */}
            <div className="grid grid-cols-7 gap-1 text-center mb-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                <div
                  key={day}
                  className="text-xs font-semibold text-[#6B6862] uppercase tracking-wider py-1.5"
                >
                  {day}
                </div>
              ))}
            </div>

            {/* Day Cells */}
            <div className="grid grid-cols-7 gap-1 sm:gap-2">
              {daysInMonthGrid.map((day, idx) => {
                const dayEvents = getEventsForDay(day);
                const isSelected = isSameDay(day, selectedDate);
                const isCurrentMonth = isSameMonth(day, currentDate);
                const isCurrentDay = manilaDayKey(day) === todayKey;
                const selectDay = () => {
                  setSelectedDate(day);
                  if (!isSameMonth(day, currentDate)) setCurrentDate(day);
                };

                return (
                  <div
                    key={idx}
                    onClick={selectDay}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        selectDay();
                      }
                    }}
                    role="button"
                    tabIndex={0}
                    aria-label={`${format(day, 'MMMM d, yyyy')}${dayEvents.length > 0 ? `, ${dayEvents.length} events` : ''}`}
                    className={`min-h-[72px] sm:min-h-[90px] p-1.5 sm:p-2 rounded-2xl border transition cursor-pointer flex flex-col justify-between ${
                      !isCurrentMonth
                        ? 'opacity-30 bg-[#FAF9F6]/50 border-transparent'
                        : isSelected
                        ? 'bg-[#EAF8EF] border-[#1F9D55] shadow-sm'
                        : 'bg-[#FAF9F6] border-[#E8E4DF] hover:border-[#DDD7CE] hover:bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className={`text-xs font-semibold w-6 h-6 rounded-full flex items-center justify-center ${
                          isCurrentDay
                            ? 'bg-[#1F9D55] text-[#FAF9F6]'
                            : isSelected
                            ? 'text-[#262422]'
                            : 'text-[#6B6862]'
                        }`}
                      >
                        {format(day, 'd')}
                      </span>

                      {dayEvents.length > 0 && (
                        <span className="text-[10px] font-bold text-[#1F9D55] bg-white px-1.5 py-0.5 rounded-full border border-[#B2E6C4]">
                          {dayEvents.length}
                        </span>
                      )}
                    </div>

                    {/* Dot indicators */}
                    <div className="space-y-1 mt-1">
                      {dayEvents.slice(0, 2).map((ev) => (
                        <div
                          key={ev.id}
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectEvent(ev);
                          }}
                          className="text-[10px] truncate px-1.5 py-0.5 rounded-md bg-white border border-[#E8E4DF] text-[#3C3A36] hover:text-[#1F9D55] font-medium hidden sm:block"
                          title={ev.title}
                        >
                          <span
                            className={`inline-block w-1.5 h-1.5 rounded-full mr-1 ${getCategoryDotColor(
                              ev.category
                            )}`}
                          />
                          {ev.title}
                        </div>
                      ))}

                      {dayEvents.length > 2 && (
                        <div className="text-[9px] text-[#6B6862] font-semibold text-center hidden sm:block">
                          +{dayEvents.length - 2} more
                        </div>
                      )}

                      {/* Mobile dot only */}
                      <div className="flex gap-1 justify-center sm:hidden">
                        {dayEvents.map((ev) => (
                          <span
                            key={ev.id}
                            className={`w-1.5 h-1.5 rounded-full ${getCategoryDotColor(ev.category)}`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected Day Agenda Sidebar (4 columns) */}
          <div className="lg:col-span-4 bg-white rounded-3xl p-5 sm:p-6 border border-[#E8E4DF] shadow-sm flex flex-col">
            <div className="border-b border-[#E8E4DF] pb-3 mb-4">
              <span className="text-xs font-bold text-[#B56E4D] uppercase tracking-wider block">
                Selected Day Schedule
              </span>
              <h3 className="font-serif-heading text-xl text-[#262422]">
                {manilaLongFmt.format(selectedDate)}
              </h3>
            </div>

            <div className="space-y-3 flex-1 overflow-y-auto max-h-[500px] pr-1">
              {selectedDayEvents.length === 0 ? (
                <div className="py-12 text-center text-[#6B6862] space-y-2">
                  <CalendarIcon className="w-8 h-8 text-[#DDD7CE] mx-auto" />
                  <p className="text-xs">No school events scheduled for this day.</p>
                </div>
              ) : (
                selectedDayEvents.map((event) => (
                  <div
                    key={event.id}
                    onClick={() => onSelectEvent(event)}
                    className="p-3.5 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] hover:border-[#1F9D55] transition cursor-pointer space-y-2 group"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#EAF8EF] text-[#0E562D]">
                        {event.category}
                      </span>
                      <span className="text-[11px] text-[#6B6862] flex items-center gap-1">
                        <Clock className="w-3 h-3 text-[#1F9D55]" />
                        {manilaTimeFmt.format(new Date(event.start_time))}
                      </span>
                    </div>

                    <h4 className="font-serif-heading text-base text-[#262422] group-hover:text-[#1F9D55] transition line-clamp-2">
                      {event.title}
                    </h4>

                    <div className="flex items-center gap-1 text-xs text-[#6B6862]">
                      <MapPin className="w-3 h-3 text-[#B56E4D] shrink-0" />
                      <span className="truncate">{event.location}</span>
                    </div>

                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Agenda List View */
        <div className="bg-white rounded-3xl p-6 border border-[#E8E4DF] shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 border-b border-[#E8E4DF] pb-3">
            <div>
              <h2 className="font-serif-heading text-2xl text-[#262422]">
                Academic & Campus Event Agenda
              </h2>
              <p className="text-xs text-[#6B6862]">
                Chronological schedule of events, examinations, and institutional holidays
              </p>
            </div>
            <PdfDownloadButton
              label="Export Announcements (PDF)"
              title="Download every published announcement as one PDF"
              className="px-3.5 py-2 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#EAF8EF] text-[#1F9D55] text-xs font-semibold transition shrink-0 self-start"
            />
          </div>

          <div className="divide-y divide-[#E8E4DF] space-y-3">
            {filteredEvents.map((event) => (
              <div
                key={event.id}
                onClick={() => onSelectEvent(event)}
                className="pt-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:bg-[#FAF9F6] p-3 rounded-2xl transition cursor-pointer"
              >
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-xl bg-[#EAF8EF] border border-[#B2E6C4] flex flex-col items-center justify-center shrink-0 text-center">
                    <span className="text-[9px] uppercase font-bold text-[#1F9D55]">
                      {manilaMonthFmt.format(new Date(event.start_time))}
                    </span>
                    <span className="text-base font-bold font-serif-heading text-[#262422]">
                      {manilaDayNumFmt.format(new Date(event.start_time))}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-[#FAF0EB] text-[#B56E4D]">
                        {event.category}
                      </span>
                      <span className="text-xs text-[#6B6862]">
                        {`${manilaWeekdayFmt.format(new Date(event.start_time))} • ${manilaTimeFmt.format(new Date(event.start_time))}`}
                      </span>
                    </div>
                    <h3 className="font-serif-heading text-base sm:text-lg text-[#262422]">
                      {event.title}
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-[#6B6862]">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-[#B56E4D]" />
                        {event.location}
                      </span>
                      <span>•</span>
                      <span>Audience: {event.target_audience}</span>
                    </div>
                  </div>
                </div>

                </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
