'use client';

import React from 'react';
import { X, AlertTriangle } from 'lucide-react';

interface ConfirmDialogProps {
  isOpen: boolean;
  title: string;
  message: React.ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  tone?: 'danger' | 'default';
  onConfirm: () => void;
  onCancel: () => void;
}

export default function ConfirmDialog({
  isOpen,
  title,
  message,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  tone = 'default',
  onConfirm,
  onCancel,
}: ConfirmDialogProps) {
  if (!isOpen) return null;

  const isDanger = tone === 'danger';

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-[#2C2A26]/50 backdrop-blur-sm animate-fade-in font-sans-ui"
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-title"
    >
      <div className="relative w-full max-w-md bg-white rounded-3xl border border-[#E8E4DF] shadow-2xl overflow-hidden">
        <div className="p-6 space-y-4">
          <div className="flex items-start gap-3">
            <div
              className={`w-10 h-10 rounded-2xl border flex items-center justify-center shrink-0 ${
                isDanger
                  ? 'bg-[#FAF0EB] border-[#ECCEC1] text-[#9E5B3D]'
                  : 'bg-[#EAF8EF] border-[#B2E6C4] text-[#1F9D55]'
              }`}
            >
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 id="confirm-title" className="font-serif-heading text-xl text-[#262422] leading-snug">
                {title}
              </h3>
              <div className="text-sm text-[#6B6862] mt-1.5 leading-relaxed break-words">{message}</div>
            </div>
          </div>

          <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2 pt-2">
            <button
              onClick={onCancel}
              className="px-4 py-2.5 rounded-2xl bg-[#FAF9F6] hover:bg-[#F2EFE9] border border-[#E8E4DF] text-xs font-semibold text-[#3C3A36] transition"
            >
              {cancelLabel}
            </button>
            <button
              onClick={onConfirm}
              className={`px-5 py-2.5 rounded-2xl text-xs font-semibold text-[#FAF9F6] transition ${
                isDanger
                  ? 'bg-[#B56E4D] hover:bg-[#9E5B3D]'
                  : 'bg-[#1F9D55] hover:bg-[#168044]'
              }`}
            >
              {confirmLabel}
            </button>
          </div>
        </div>

        <button
          onClick={onCancel}
          aria-label="Close"
          className="absolute top-4 right-4 p-1.5 rounded-lg text-[#6B6862] hover:bg-[#F2EFE9] transition"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}