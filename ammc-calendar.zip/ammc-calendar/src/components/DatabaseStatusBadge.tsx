'use client';

import React, { useState, useEffect } from 'react';
import { Database, CheckCircle2, AlertCircle, RefreshCw, Server } from 'lucide-react';
import { DatabaseStatus } from '@/types';

export default function DatabaseStatusBadge() {
 const [status, setStatus] = useState<DatabaseStatus | null>(null);
 const [loading, setLoading] = useState(false);
 const [isOpen, setIsOpen] = useState(false);

 const checkStatus = async () => {
 setLoading(true);
 try {
 const res = await fetch('/api/setup-db');
 const data = await res.json();
 if (data.status) {
 setStatus(data.status);
 }
 } catch {
 setStatus({
 connected: false,
 engine: 'mysql',
 error: 'Could not contact MySQL database endpoint',
 });
 } finally {
 setLoading(false);
 }
 };

 const triggerReconnect = async () => {
 setLoading(true);
 try {
 const res = await fetch('/api/setup-db', { method: 'POST' });
 const data = await res.json();
 if (data.status) {
 setStatus(data.status);
 }
 } catch {
 // ignore
 } finally {
 setLoading(false);
 }
 };

 useEffect(() => {
 const frame = requestAnimationFrame(() => {
 void checkStatus();
 });
 return () => cancelAnimationFrame(frame);
 }, []);

 if (!status) return null;

 return (
 <div className="relative inline-block text-left text-xs font-sans-ui">
 <button
 onClick={() => setIsOpen(!isOpen)}
 title="Click to view XAMPP MySQL status"
 className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border transition-all ${
 status.connected
 ? 'bg-[#ECF3EF] border-[#C8DFD2] text-[#385544] hover:bg-[#E2ECE6]'
 : 'bg-[#FAF0EB] border-[#ECCEC1] text-[#9E5B3D] hover:bg-[#F8E3D8]'
 }`}
 >
 <span
 className={`w-2 h-2 rounded-full ${
 status.connected ? 'bg-[#5B7B68] animate-pulse' : 'bg-[#B56E4D]'
 }`}
 />
 <Database className="w-3.5 h-3.5" />
 <span className="font-medium hidden sm:inline">
 {status.connected ? 'XAMPP MySQL Online' : 'MySQL Offline'}
 </span>
 <span className="text-[10px] opacity-75 sm:hidden">
 {status.connected ? 'MySQL Online' : 'MySQL Error'}
 </span>
 </button>

 {isOpen && (
 <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-white border border-[#E8E4DF] shadow-xl p-4 z-50 animate-fade-in text-[#3C3A36]">
 <div className="flex items-center justify-between pb-3 border-b border-[#E8E4DF]">
 <div className="flex items-center gap-2">
 <Server className="w-4 h-4 text-[#1F9D55]" />
 <h4 className="font-semibold text-sm">MySQL Database Status</h4>
 </div>
 <button
 onClick={triggerReconnect}
 disabled={loading}
 className="p-1.5 rounded-lg hover:bg-[#EAF8EF] text-[#1F9D55] transition disabled:opacity-50"
 title="Test & Reconnect MySQL"
 >
 <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
 </button>
 </div>

 <div className="py-3 space-y-2.5 text-xs">
 <div className="flex items-center justify-between">
 <span className="text-[#6B6862]">Database Engine:</span>
 <span className="font-medium px-2 py-0.5 rounded-md bg-[#FAF9F6] border border-[#E8E4DF]">
 {status.connected ? 'MySQL in XAMPP (Port 3306)' : 'MySQL (Disconnected)'}
 </span>
 </div>

 <div className="flex items-center justify-between">
 <span className="text-[#6B6862]">Target Database:</span>
 <span className="font-mono text-[11px] font-semibold text-[#1F9D55]">
 {status.database || 'ammc'}
 </span>
 </div>

 {status.item_counts && (
 <div className="grid grid-cols-2 gap-2 pt-1">
 <div className="bg-[#FAF9F6] p-2 rounded-xl text-center border border-[#E8E4DF]">
 <div className="text-base font-bold text-[#3C3A36]">
 {status.item_counts.announcements}
 </div>
 <div className="text-[10px] text-[#6B6862]">Announcements</div>
 </div>
 <div className="bg-[#FAF9F6] p-2 rounded-xl text-center border border-[#E8E4DF]">
 <div className="text-base font-bold text-[#3C3A36]">
 {status.item_counts.events}
 </div>
 <div className="text-[10px] text-[#6B6862]">Events</div>
 </div>
 </div>
 )}

 {!status.connected && (
 <div className="mt-2 p-2.5 rounded-xl bg-[#FAF0EB] border border-[#ECCEC1] text-[#9E5B3D]">
 <div className="flex items-start gap-2">
 <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
 <div className="space-y-1">
 <p className="font-semibold text-[11px]">To connect to XAMPP MySQL:</p>
 <p className="text-[11px] leading-relaxed">
 1. Open <strong>XAMPP Control Panel</strong> and click <strong>Start</strong> next to <strong>MySQL</strong>.<br />
 2. Click the refresh button above to synchronize automatically.
 </p>
 </div>
 </div>
 </div>
 )}

 {status.connected && (
 <div className="mt-2 p-2.5 rounded-xl bg-[#ECF3EF] border border-[#C8DFD2] text-[#385544]">
 <div className="flex items-center gap-2">
 <CheckCircle2 className="w-4 h-4 shrink-0" />
 <p className="text-[11px] font-medium">
 Successfully connected to XAMPP MySQL database <code className="font-mono">ammc</code>!
 </p>
 </div>
 </div>
 )}
 </div>

 <div className="pt-2 border-t border-[#E8E4DF] flex justify-end">
 <button
 onClick={() => setIsOpen(false)}
 className="text-xs px-3 py-1 rounded-lg bg-[#FAF9F6] hover:bg-[#EAF8EF] text-[#3C3A36] border border-[#E8E4DF]"
 >
 Close
 </button>
 </div>
 </div>
 )}
 </div>
 );
}
