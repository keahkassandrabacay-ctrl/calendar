'use client';

import React from 'react';
import { SchoolEvent } from '@/types';
import { formatDistanceToNow, format } from 'date-fns';
import { Calendar, MapPin, Clock, ArrowRight, Download, Sparkles } from 'lucide-react';

interface EventCardProps {
  event: SchoolEvent;
  onOpenDetail: (event: SchoolEvent) => void;
}

export default function EventCard({ event, onOpenDetail }: EventCardProps) {
  const startDate = new Date(event.start_time);

  const downloadICS = (e: React.MouseEvent) => {
    e.stopPropagation();
    const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);
    const toICSDate = (d: Date) =>
      `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
    const endDate = new Date(event.end_time);
    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//AMMC//School Calendar//EN',
      'BEGIN:VEVENT',
      `UID:${event.id}@ammc.edu.ph`,
      `DTSTAMP:${toICSDate(new Date())}`,
      `DTSTART:${toICSDate(startDate)}`,
      `DTEND:${toICSDate(endDate)}`,
      `SUMMARY:${event.title}`,
      `DESCRIPTION:${event.description.replace(/\n/g, '\\n')}`,
      `LOCATION:${event.location}`,
      'END:VEVENT',
      'END:VCALENDAR',
    ].join('\r\n');
    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${event.title.replace(/[^a-zA-Z0-9]/g, '_')}.ics`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <article
      onClick={() => onOpenDetail(event)}
      className="natural-card rounded-3xl p-6 cursor-pointer flex flex-col justify-between group relative overflow-hidden"
    >
      {/* Top Meta — neat like Announcement */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-[#EAF8EF] text-[#0E562D] border border-[#B2E6C4]">
              {event.category}
            </span>
            <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#F1F8E9] text-[#5A7D4A] border border-[#D6E8C2]">
              <MapPin className="w-3 h-3" />
              {event.location}
            </span>
          </div>

          {/* <button
            type="button"
            onClick={downloadICS}
            title="Add to Calendar (.ics)"
            className="p-2 rounded-full bg-white/80 border border-[#E8E4DF] text-[#6B6862] hover:text-[#1F9D55] hover:border-[#B2E6C4] hover:bg-[#EAF8EF] transition shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
          </button> */}
        </div>

        {/* Title — same scale as announcement */}
        <h3 className="font-serif-heading text-xl sm:text-2xl text-[#262422] group-hover:text-[#1F9D55] transition-colors line-clamp-2 leading-snug mb-2.5">
          {event.title}
        </h3>

        {/* Description — summary style */}
        <p className="text-xs sm:text-sm text-[#6B6862] line-clamp-3 leading-relaxed mb-4">
          {event.description}
        </p>
      </div>

      {/* Footer — department + date + view */}
      <div className="pt-4 border-t border-[#E8E4DF] space-y-3">
        <div className="flex items-center justify-between text-xs text-[#6B6862]">
          <span className="font-medium text-[#3C3A36] truncate max-w-[180px] flex items-center gap-1.5">
            <Sparkles className="w-3 h-3 text-[#5A7D4A] shrink-0" />
            {event.department}
          </span>
          <span className="flex items-center gap-1.5 shrink-0" title={format(startDate, 'PPP p')}>
            <Clock className="w-3 h-3 text-[#5A7D4A]" />
            {formatDistanceToNow(startDate, { addSuffix: true })}
          </span>
        </div>

        <div className="flex items-center justify-between pt-1">
          <div className="flex items-center gap-1.5 text-xs text-[#6B6862]">
            <Calendar className="w-3.5 h-3.5 text-[#5A7D4A]" />
            <span>{format(startDate, 'MMM d • h:mm a')}</span>
            <span className="hidden sm:inline text-[#8AA88A]">• {event.target_audience}</span>
          </div>

          <div className="flex items-center gap-1 text-xs font-semibold text-[#1F9D55] group-hover:translate-x-0.5 transition">
            <span>View Details</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>
    </article>
  );
}
