'use client';

import React from 'react';
import { SchoolEvent } from '@/types';
import { format } from 'date-fns';
import { X, Calendar, Clock, MapPin, Users, Share2, Building2, User, ExternalLink, Pencil } from 'lucide-react';

interface EventDetailModalProps {
  event: SchoolEvent | null;
  isOpen: boolean;
  onClose: () => void;
  // When the viewer is an admin, show an Edit button that jumps to the editor.
  isAdmin?: boolean;
  onEdit?: (event: SchoolEvent) => void;
}

export default function EventDetailModal({
  event,
  isOpen,
  onClose,
  isAdmin = false,
  onEdit,
}: EventDetailModalProps) {
  if (!isOpen || !event) return null;

  const startDate = new Date(event.start_time);
  const endDate = new Date(event.end_time);
  const isFull = event.capacity > 0 && event.rsvp_count >= event.capacity;

  const googleCalendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(
    event.title
  )}&dates=${startDate.toISOString().replace(/-|:|\.\d\d\d/g, '')}/${endDate
    .toISOString()
    .replace(/-|:|\.\d\d\d/g, '')}&details=${encodeURIComponent(
    event.description
  )}&location=${encodeURIComponent(event.location)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2C2A26]/50 backdrop-blur-sm animate-fade-in font-sans-ui">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-[#FAF9F6] rounded-3xl border border-[#E8E4DF] shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-[#1F9D55] text-[#FAF9F6] px-6 py-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-[#168044] text-[#FAF9F6] border border-[#717154]">
              {event.category}
            </span>
            <span className="text-xs text-[#DDD8CE]">
              {event.department}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {isAdmin && onEdit && (
              <button
                onClick={() => onEdit(event)}
                title="Edit Event"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#FAF9F6] text-[#1F9D55] hover:bg-white text-xs font-semibold transition"
              >
                <Pencil className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-[#168044]/80 hover:bg-[#168044] text-[#DDD8CE] hover:text-white flex items-center justify-center transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 flex-1">
          <div>
            <div className="flex flex-wrap items-center gap-3 text-xs text-[#6B6862] mb-2">
              <span className="px-2.5 py-0.5 rounded-full bg-[#FAF0EB] text-[#B56E4D] font-medium text-[11px]">
                Audience: {event.target_audience}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-[#1F9D55]" />
                Organized by {event.organizer}
              </span>
            </div>

            <h1 className="font-serif-heading text-2xl sm:text-3xl text-[#262422] leading-tight">
              {event.title}
            </h1>
          </div>

          {/* Time and Venue highlight grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-4 rounded-2xl bg-white border border-[#E8E4DF] space-y-1">
              <div className="flex items-center gap-2 text-xs font-bold text-[#1F9D55] uppercase tracking-wider">
                <Calendar className="w-4 h-4" />
                <span>Date & Schedule</span>
              </div>
              <div className="text-sm font-semibold text-[#3C3A36]">
                {format(startDate, 'EEEE, MMMM d, yyyy')}
              </div>
              <div className="text-xs text-[#6B6862]">
                {format(startDate, 'h:mm a')} – {format(endDate, 'h:mm a')}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white border border-[#E8E4DF] space-y-1">
              <div className="flex items-center gap-2 text-xs font-bold text-[#B56E4D] uppercase tracking-wider">
                <MapPin className="w-4 h-4" />
                <span>Campus Venue</span>
              </div>
              <div className="text-sm font-semibold text-[#3C3A36]">
                {event.location}
              </div>
              <div className="text-xs text-[#6B6862]">
                AMMC Main Campus Pavilion
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-[#6B6862] uppercase tracking-wider">
              Event Overview & Program Details
            </h4>
            <div className="p-5 rounded-2xl bg-white border border-[#E8E4DF] text-sm text-[#3C3A36] leading-relaxed whitespace-pre-line font-editorial">
              {event.description}
            </div>
          </div>

          {/* Attendance Capacity */}
          {/* <div>
          {event.capacity > 0 && (
            <div className="p-4 rounded-2xl bg-[#EAF8EF]/60 border border-[#B2E6C4] space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-[#0E562D] flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-[#1F9D55]" />
                  Seating & Registration Status
                </span>
                <span className="font-bold text-[#3C3A36]">
                  {event.rsvp_count} of {event.capacity} Confirmed Attendees
                </span>
              </div>
              <div className="w-full h-2 bg-white rounded-full overflow-hidden border border-[#B2E6C4]">
                <div
                  className={`h-full rounded-full ${
                    isFull ? 'bg-[#B56E4D]' : 'bg-[#1F9D55]'
                  }`}
                  style={{
                    width: `${Math.min(100, (event.rsvp_count / event.capacity) * 100)}%`,
                  }}
                />
              </div>
            </div>
          )}
          </div> */}

          {/* External Calendar Links */}
          <div className="flex items-center justify-between pt-2">
            <span className="text-xs text-[#6B6862]">External Calendar Synchronization:</span>
            <a
              href={googleCalendarUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-[#1F9D55] hover:text-[#3C3A36] font-semibold flex items-center gap-1 underline underline-offset-4"
            >
              <span>Add to Google Calendar</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="bg-[#FAF9F6] border-t border-[#E8E4DF] px-6 py-4 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-2xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-semibold shadow-md transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
