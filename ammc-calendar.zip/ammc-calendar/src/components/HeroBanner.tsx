'use client';

import React from 'react';
import { Announcement } from '@/types';
import { Sparkles, Pin, Bell, ArrowRight, ShieldAlert, Calendar, CheckCircle2, ChevronRight } from 'lucide-react';

interface HeroBannerProps {
 pinnedAnnouncements: Announcement[];
 onOpenAnnouncement: (announcement: Announcement) => void;
 totalAnnouncementsCount: number;
 totalEventsCount: number;
}

export default function HeroBanner({
 pinnedAnnouncements,
 onOpenAnnouncement,
 totalAnnouncementsCount,
 totalEventsCount,
}: HeroBannerProps) {
 const topPinned = pinnedAnnouncements[0];

 return (
 <section className="relative overflow-hidden pt-6 pb-4">
 {/* Decorative subtle background gradient */}
 <div className="rounded-3xl bg-[#F4EFEA] border border-[#E8E4DF] p-6 sm:p-10 relative shadow-sm">
 <div className="max-w-4xl space-y-4">
 {/* Institution Chip */}
 <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-[#DDD7CE] text-xs font-semibold text-[#1F9D55] shadow-xs">
 <span className="w-2 h-2 rounded-full bg-[#1F9D55]" />
 <span>Dr. Aurelio Mendoza Memorial Colleges • Official Broadcast </span>
 </div>

 {/* Heading */}
 <h1 className="font-serif-heading text-3xl sm:text-5xl lg:text-6xl text-[#262422] leading-[1.08] tracking-tight">
 Institutional Notices, Academic Advisories & Campus Schedules
 </h1>

 {/* Subtitle */}
 <p className="text-sm sm:text-base text-[#6B6862] max-w-2xl leading-relaxed font-sans-ui">
 Stay informed with verified collegiate memoranda, academic examination dates, institutional holiday advisories, and campus event reservations.
 </p>

 {/* Key Metrics / Highlights */}
 <div className="pt-3 flex flex-wrap items-center gap-2 sm:gap-4 font-sans-ui">
 <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-white border border-[#E8E4DF] text-xs">
 <Bell className="w-3.5 h-3.5 text-[#1F9D55]" />
 <span className="font-semibold text-[#262422]">{totalAnnouncementsCount}</span>
 <span className="text-[#6B6862]">Active Bulletins</span>
 </div>

 <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-white border border-[#E8E4DF] text-xs">
 <Calendar className="w-3.5 h-3.5 text-[#B56E4D]" />
 <span className="font-semibold text-[#262422]">{totalEventsCount}</span>
 <span className="text-[#6B6862]">Scheduled Events</span>
 </div>

 <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-[#EAF8EF] border border-[#B2E6C4] text-xs text-[#0E562D]">
 <CheckCircle2 className="w-3.5 h-3.5 text-[#5B7B68]" />
 <span className="font-medium">1st Semester A.Y. 2026-2027</span>
 </div>
 </div>
 </div>

 {/* Top Pinned Critical Alert Callout if available */}
 {topPinned && (
 <div
 onClick={() => onOpenAnnouncement(topPinned)}
 className="mt-6 p-4 rounded-2xl bg-white border-2 border-[#1F9D55]/30 hover:border-[#1F9D55] transition cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs group"
 >
 <div className="flex items-start gap-3">
 <div className="w-8 h-8 rounded-xl bg-[#FAF0EB] text-[#B56E4D] border border-[#ECCEC1] flex items-center justify-center shrink-0 mt-0.5">
 <ShieldAlert className="w-4 h-4" />
 </div>
 <div>
 <div className="flex items-center gap-2 mb-0.5">
 <span className="text-[10px] uppercase font-bold tracking-wider text-[#B56E4D]">
 Pinned Official Advisory
 </span>
 <span className="text-[10px] text-[#6B6862]">• {topPinned.department}</span>
 </div>
 <h4 className="font-serif-heading text-base sm:text-lg font-bold text-[#262422] group-hover:text-[#1F9D55] transition line-clamp-1">
 {topPinned.title}
 </h4>
 </div>
 </div>

 <div className="flex items-center gap-1 text-xs font-semibold text-[#1F9D55] shrink-0 self-end sm:self-center">
 <span>Read Notice</span>
 <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
 </div>
 </div>
 )}
 </div>
 </section>
 );
}
