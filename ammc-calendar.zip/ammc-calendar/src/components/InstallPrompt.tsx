'use client';

import React, { useState, useEffect } from 'react';
import { Download, X, Smartphone } from 'lucide-react';

const DISMISS_KEY = 'ammc_install_prompt_dismissed';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export default function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let dismissed = false;
    try {
      dismissed = localStorage.getItem(DISMISS_KEY) === '1';
    } catch {
      // ignore
    }
    if (dismissed || window.matchMedia('(display-mode: standalone)').matches) return;

    const handler = (e: Event) => {
      // Chrome fires this when the app qualifies as installable.
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setVisible(true);
    };
    window.addEventListener('beforeinstallprompt', handler);

    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    setDeferredPrompt(null);
    setVisible(false);
  };

  const handleDismiss = () => {
    setVisible(false);
    try {
      localStorage.setItem(DISMISS_KEY, '1');
    } catch {
      // ignore
    }
  };

  if (!visible || !deferredPrompt) return null;

  return (
    <div className="fixed bottom-4 right-4 z-40 w-[calc(100vw-2rem)] max-w-xs bg-white border border-[#E8E4DF] rounded-3xl shadow-xl p-4 flex gap-3 items-start animate-fade-in font-sans-ui">
      <div className="w-10 h-10 rounded-2xl bg-[#EAF8EF] text-[#1F9D55] border border-[#B2E6C4] flex items-center justify-center shrink-0">
        <Smartphone className="w-5 h-5" />
      </div>

      <div className="flex-1 min-w-0 space-y-2">
        <p className="text-xs font-bold text-[#262422]">Install the AMMC App</p>
        <p className="text-[11px] text-[#6B6862] leading-relaxed">
          Add AMMC to your home screen for quick access to announcements and the
          campus calendar, even without a browser tab.
        </p>

        <div className="flex items-center gap-2 pt-0.5">
          <button
            onClick={() => void handleInstall()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-[11px] font-semibold transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Install</span>
          </button>
          <button
            onClick={handleDismiss}
            className="px-3 py-1.5 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-[11px] font-medium text-[#3C3A36] transition"
          >
            Not now
          </button>
        </div>
      </div>

      <button
        onClick={handleDismiss}
        aria-label="Dismiss install prompt"
        className="p-1 rounded-lg text-[#6B6862] hover:bg-[#F2EFE9] transition shrink-0"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}