'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { subscribeDataChanges } from '@/lib/data-refresh';
import { ensureDeviceId } from '@/lib/device-id';
import { setBadge } from '@/lib/badge';
import PushOptIn from '@/components/PushOptIn';
import {
  GraduationCap,
  Calendar,
  Bell,
  Search,
  ShieldCheck,
  LogOut,
  Menu,
  X,
  Sparkles,
  BookOpen,
  School,
  Clock,
  Layers,
  ChevronDown,
  Clock3,
  Sun,
  Moon,
} from 'lucide-react';
import { AdminUser } from '@/types';

interface NavbarProps {
 onOpenAuthModal: () => void;
 currentUser: AdminUser | null;
 onLogout: () => void;
 searchQuery: string;
 onSearchChange: (val: string) => void;
}

export default function Navbar({
  onOpenAuthModal,
  currentUser,
  onLogout,
  searchQuery,
  onSearchChange,
}: NavbarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [adminMenuOpen, setAdminMenuOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState('');
  const [isDark, setIsDark] = useState(false);
  const [recentAnnouncementCount, setRecentAnnouncementCount] = useState(0);

  // Unread-announcement count for the nav badge and the installed app icon.
  // Unread is tracked server-side per device (announcement_reads), so this is a
  // real "since you last read" number rather than a rolling time window.
  const fetchRecentCount = useCallback(() => {
    void (async () => {
      try {
        const deviceId = await ensureDeviceId();
        const res = await fetch(`/api/announcements/recent-count?deviceId=${encodeURIComponent(deviceId)}`);
        const data = await res.json();
        const count = Number(data?.count) || 0;
        setRecentAnnouncementCount(count);
        // Best-effort: the taskbar badge is only drawn for an installed app.
        await setBadge(count);
      } catch {
        // ignore — the badge is a convenience, never a blocker
      }
    })();
  }, []);

  // Viewing the announcements list is what marks them read.
  useEffect(() => {
    if (pathname !== '/announcements') return;
    let cancelled = false;
    void (async () => {
      try {
        const deviceId = await ensureDeviceId();
        const res = await fetch('/api/announcements/mark-read', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ deviceId }),
        });
        if (!res.ok) return;
        const data = await res.json();
        const unread = Number(data?.unread) || 0;
        if (cancelled) return;
        setRecentAnnouncementCount(unread);
        await setBadge(unread);
      } catch {
        // ignore
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [pathname]);

  useEffect(() => {
    const frame = requestAnimationFrame(fetchRecentCount);
    return () => cancelAnimationFrame(frame);
  }, [fetchRecentCount]);

  useEffect(
    () => subscribeDataChanges((kind) => {
      if (kind === 'announcement') fetchRecentCount();
    }),
    [fetchRecentCount]
  );

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchQuery.trim();
    if (q) router.push(`/search?q=${encodeURIComponent(q)}`);
    else router.push('/search');
    setMobileMenuOpen(false);
  };

  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      setCurrentTime(
        d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000 * 30);
    return () => clearInterval(interval);
  }, []);

  // Dark mode — matcha night
  useEffect(() => {
    let shouldDark = false;
    try {
      const saved = localStorage.getItem('ammc-theme');
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      shouldDark = saved === 'dark' || (!saved && prefersDark);
    } catch {}
    document.documentElement.classList.toggle('dark', shouldDark);
    const frame = requestAnimationFrame(() => {
      setIsDark(shouldDark);
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  const toggleDark = () => {
    const next = !isDark;
    setIsDark(next);
    document.documentElement.classList.toggle('dark', next);
    try {
      localStorage.setItem('ammc-theme', next ? 'dark' : 'light');
    } catch {}
  };

 // Close admin dropdown on outside click
 useEffect(() => {
 if (!adminMenuOpen) return;
 const handleClickOutside = (e: MouseEvent) => {
 const target = e.target as HTMLElement;
 if (!target.closest('[data-admin-menu]')) {
 setAdminMenuOpen(false);
 }
 };
 document.addEventListener('mousedown', handleClickOutside);
 return () => document.removeEventListener('mousedown', handleClickOutside);
 }, [adminMenuOpen]);

 // Close menus on route change
 const [prevPathname, setPrevPathname] = useState(pathname);
 if (pathname !== prevPathname) {
 setPrevPathname(pathname);
 setAdminMenuOpen(false);
 setMobileMenuOpen(false);
 }

 const navLinks = [
 { label: 'Home', href: '/', icon: School },
 { label: 'Announcements', href: '/announcements', icon: Bell },
 { label: 'Events', href: '/events', icon: Sparkles },
 { label: 'Calendar', href: '/calendar', icon: Calendar },
 { label: 'Meetings', href: '/meetings', icon: Layers },
 { label: 'Holidays', href: '/holidays', icon: GraduationCap },
 ];

 return (
 <header className="sticky top-0 z-40 bg-[#FAF9F6]/95 backdrop-blur-md border-b border-[#E8E4DF] font-sans-ui transition-all">
 {/* Top micro-bar with College motto and Term Info */}
 <div className="bg-[#1F9D55] text-[#FAF9F6] px-4 sm:px-8 py-1 text-[11px] flex items-center justify-between">
 <div className="flex items-center gap-3">
 <span className="font-semibold tracking-wider uppercase text-[10px] text-[#DDD8CE]">
 Dr. Aurelio Mendoza Memorial Colleges
 </span>
 <span className="hidden md:inline text-[#DDD8CE]">•</span>
 {/* <span className="hidden md:inline italic text-[#DDD8CE]">
 Virtus, Scientia, Servitium
 </span> */}
 </div>

 <div className="flex items-center gap-3 text-[#DDD8CE]">
 <span className="hidden sm:inline">1st Semester A.Y. 2026-2027</span>
 <span className="flex items-center gap-1 font-mono text-[10px] bg-[#168044] px-2 py-0.5 rounded-full border border-[#717154]">
 <Clock className="w-3 h-3 text-[#FAF9F6]" />
 {currentTime || '08:00 AM'} PHT
 </span>
 </div>
 </div>

 {/* Main Navigation Bar */}
 <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
 <div className="flex items-center justify-between h-18 gap-4">
 {/* Brand Logo & Name */}
 <Link href="/" className="flex items-center gap-3 group shrink-0">
 <div className="w-10 h-10 rounded-2xl overflow-hidden border border-[#E8E4DF] shadow-xs group-hover:scale-105 transition bg-white flex items-center justify-center">
 <img src="/logo.png" alt="AMMC Logo" className="w-full h-full object-cover" />
 </div>
 <div>
 <span className="font-serif-heading text-xl sm:text-2xl font-bold text-[#262422] group-hover:text-[#1F9D55] transition tracking-tight leading-none block">
 AMMC
 </span>
 <span className="text-[10px] uppercase font-semibold tracking-wider text-[#6B6862]">
 Official Announcements & Events
 </span>
 </div>
 </Link>

          {/* Search Bar in center — separate search UI, latest→oldest */}
          <form onSubmit={handleSearchSubmit} className="hidden md:flex flex-1 max-w-xl lg:max-w-2xl mx-1">
            <div className="relative w-full">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B6862] pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search..."
                className="w-full pl-11 pr-3 py-2 rounded-2xl bg-white border border-[#E8E4DF] text-sm text-[#3C3A36] placeholder-[#6B6862] shadow-sm focus:outline-none focus:border-[#1F9D55] focus:ring-2 focus:ring-[#1F9D55]/10 transition"
              />
            </div>
          </form>

 {/* Navigation Links & Action Buttons */}
 <div className="hidden md:flex items-center gap-3">
 <nav className="flex items-center gap-1">
 {navLinks.map((item) => {
 const Icon = item.icon;
 const isActive = pathname === item.href;
 return (
 <Link
 key={item.href}
 href={item.href}
 className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold transition ${isActive
 ? 'bg-[#1F9D55] text-[#FAF9F6] shadow-xs'
 : 'text-[#6B6862] hover:text-[#3C3A36] hover:bg-[#EAF8EF]'
 }`}
 >
 <Icon className="w-3.5 h-3.5" />
 <span>{item.label}</span>
 {item.href === '/announcements' && recentAnnouncementCount > 0 && (
 <span
 className={`ml-0.5 min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center text-[10px] font-bold ${isActive
 ? 'bg-[#FAF9F6] text-[#1F9D55]'
 : 'bg-[#B56E4D] text-white'
 }`}
 title={`${recentAnnouncementCount} recent announcement(s)`}
 >
 {recentAnnouncementCount}
 </span>
 )}
 </Link>
 );
 })}
            </nav>

            {/* Dark mode — matcha night */}
            <button
              onClick={toggleDark}
              aria-label="Toggle dark mode"
              title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              className="p-2 rounded-full bg-white border border-[#E8E4DF] text-[#6B6862] hover:text-[#1F9D55] hover:border-[#B2E6C4] hover:bg-[#EAF8EF] transition"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Announcement alerts + taskbar badge opt-in (hides once enabled) */}
            <PushOptIn />

            {/* Admin Actions — organized submenu */}
            {currentUser ? (
 <div className="relative pl-3 border-l border-[#E8E4DF]" data-admin-menu>
 <button
 type="button"
 onClick={() => setAdminMenuOpen((v) => !v)}
 aria-expanded={adminMenuOpen}
 aria-haspopup="menu"
 className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-full bg-white border border-[#E8E4DF] hover:border-[#B2E6C4] hover:bg-[#FAF9F6] shadow-xs transition"
 >
 <span className="w-7 h-7 rounded-full bg-[#1F9D55] text-[#FAF9F6] flex items-center justify-center text-[11px] font-bold border border-[#168044]">
 {currentUser.name.charAt(0).toUpperCase()}
 </span>
 {/* <span className="hidden lg:inline text-xs font-semibold text-[#3C3A36] max-w-[120px] truncate">
 {currentUser.name}
 </span> */}
 {/* <span className="hidden lg:inline text-[10px] px-1.5 py-0.5 rounded-full bg-[#EAF8EF] text-[#0E562D] border border-[#B2E6C4]">
 {currentUser.role === 'Super Admin' ? 'Admin' : currentUser.role}
 </span> */}
 <ChevronDown className={`w-3.5 h-3.5 text-[#6B6862] transition-transform ${adminMenuOpen ? 'rotate-180' : ''}`} />
 </button>

 {adminMenuOpen && (
 <div className="absolute right-0 mt-3 w-64 rounded-2xl bg-white border border-[#E8E4DF] shadow-xl overflow-hidden animate-fade-in z-50">
 {/* User header */}
 <div className="px-4 py-3 bg-[#FAF9F6] border-b border-[#E8E4DF]">
 <p className="text-xs font-bold text-[#262422] truncate">{currentUser.name}</p>
 <p className="text-[11px] text-[#6B6862] truncate">{currentUser.email}</p>
 <p className="text-[10px] text-[#1F9D55] font-medium">{currentUser.department || 'Administration'} • {currentUser.role}</p>
 </div>

 {/* Organized sub-menu */}
 <div className="p-2 space-y-0.5" role="menu">
 <Link
 href="/admin"
 onClick={() => setAdminMenuOpen(false)}
 className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-[#3C3A36] hover:bg-[#EAF8EF] hover:text-[#1F9D55] transition"
 role="menuitem"
 >
 <ShieldCheck className="w-4 h-4 text-[#1F9D55]" />
 Admin Studio
 <span className="ml-auto text-[10px] text-[#6B6862]">Dashboard</span>
 </Link>

 <div className="pt-1.5 mt-1 border-t border-[#E8E4DF]">
 <p className="px-3 py-1 text-[10px] font-bold tracking-wider uppercase text-[#6B6862]">Posting</p>
 <Link
 href="/admin?tab=announcements"
 onClick={() => setAdminMenuOpen(false)}
 className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-[#3C3A36] hover:bg-[#FAF9F6] transition"
 role="menuitem"
 >
 <Bell className="w-4 h-4 text-[#B56E4D]" />
 Announcements
 </Link>
 <Link
 href="/admin?tab=events"
 onClick={() => setAdminMenuOpen(false)}
 className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-[#3C3A36] hover:bg-[#FAF9F6] transition"
 role="menuitem"
 >
 <Calendar className="w-4 h-4 text-[#5A6B7C]" />
 Events
 </Link>
 </div>

 <div className="pt-1.5 mt-1 border-t border-[#E8E4DF]">
 <p className="px-3 py-1 text-[10px] font-bold tracking-wider uppercase text-[#6B6862]">Students</p>
 <Link
 href="/admin?tab=students"
 onClick={() => setAdminMenuOpen(false)}
 className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-[#3C3A36] hover:bg-[#FAF9F6] transition"
 role="menuitem"
 >
 <GraduationCap className="w-4 h-4 text-[#5B7B68]" />
 Students — Approved
 </Link>
 <Link
 href="/admin?tab=subscribers"
 onClick={() => setAdminMenuOpen(false)}
 className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-[#3C3A36] hover:bg-[#FAF9F6] transition"
 role="menuitem"
 >
 <Clock3 className="w-4 h-4 text-[#B56E4D]" />
 Subscribers — Pending
 </Link>
 </div>

 <div className="pt-2 mt-2 border-t border-[#E8E4DF]">
 <button
 onClick={() => {
 setAdminMenuOpen(false);
 onLogout();
 }}
 className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-[#9E5B3D] hover:bg-[#FAF0EB] transition"
 role="menuitem"
 >
 <LogOut className="w-4 h-4" />
 Sign Out
 </button>
 </div>
 </div>
 </div>
 )}
 </div>
 ) : (
 <button
 onClick={onOpenAuthModal}
 className="flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold bg-white border border-[#E8E4DF] text-[#3C3A36] hover:border-[#1F9D55] hover:text-[#1F9D55] shadow-xs transition"
 >
 <ShieldCheck className="w-3.5 h-3.5 text-[#1F9D55]" />
 <span>Login</span>
 </button>
 )}
 </div>

          {/* Mobile Menu Toggle + Dark mode */}
          <div className="flex items-center gap-2 md:hidden relative z-10 shrink-0">
            <PushOptIn />
            <button
              onClick={toggleDark}
              aria-label="Toggle dark mode"
              className="p-3 min-w-11 min-h-11 flex items-center justify-center rounded-xl bg-white border border-[#E8E4DF] text-[#6B6862] shadow-sm"
            >
              {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button
              type="button"
              aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={mobileMenuOpen}
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="relative z-10 p-3 min-w-11 min-h-11 flex items-center justify-center rounded-xl bg-white border border-[#E8E4DF] text-[#3C3A36] shadow-sm cursor-pointer touch-manipulation active:scale-95 transition hover:bg-[#FAF9F6] hover:border-[#D6D8C8]"
            >
              {mobileMenuOpen ? <X className="w-5 h-5 pointer-events-none" /> : <Menu className="w-5 h-5 pointer-events-none" />}
            </button>
          </div>
 </div>

 {/* Mobile Menu Dropdown */}
 {mobileMenuOpen && (
 <div className="md:hidden py-4 border-t border-[#E8E4DF] space-y-3 animate-fade-in">
            <form onSubmit={handleSearchSubmit} className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B6862] pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search advisories and events..."
                className="w-full pl-11 pr-4 py-3 rounded-2xl bg-white border border-[#E8E4DF] text-sm text-[#3C3A36] placeholder-[#6B6862] shadow-sm focus:outline-none focus:border-[#1F9D55] focus:ring-2 focus:ring-[#1F9D55]/10 transition"
              />
            </form>

 <div className="grid grid-cols-2 gap-2">
 {navLinks.map((item) => {
 const Icon = item.icon;
 const isActive = pathname === item.href;
 return (
 <Link
 key={item.href}
 href={item.href}
 onClick={() => setMobileMenuOpen(false)}
 className={`flex items-center gap-2 p-2.5 rounded-xl text-xs font-medium ${isActive
 ? 'bg-[#1F9D55] text-[#FAF9F6]'
 : 'bg-white border border-[#E8E4DF] text-[#3C3A36]'
 }`}
 >
 <Icon className="w-4 h-4" />
 <span>{item.label}</span>
 {item.href === '/announcements' && recentAnnouncementCount > 0 && (
 <span className="ml-auto min-w-[18px] h-[18px] px-1 rounded-full bg-[#B56E4D] text-white text-[10px] font-bold flex items-center justify-center">
 {recentAnnouncementCount}
 </span>
 )}
 </Link>
 );
 })}
 </div>

 <div className="pt-3 border-t border-[#E8E4DF]">
 {currentUser ? (
 <div className="space-y-2">
 <div className="px-3 py-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF]">
 <p className="text-xs font-bold text-[#262422] truncate">{currentUser.name}</p>
 <p className="text-[11px] text-[#6B6862] truncate">{currentUser.email} • {currentUser.role}</p>
 </div>

 <Link
 href="/admin"
 onClick={() => setMobileMenuOpen(false)}
 className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-[#1F9D55] text-[#FAF9F6] text-xs font-bold shadow-sm"
 >
 <ShieldCheck className="w-4 h-4" />
 Admin Studio Dashboard
 </Link>

 <div className="space-y-1">
 <p className="px-1 text-[10px] font-bold tracking-wider uppercase text-[#1F9D55]">Posting — separated from Students</p>
 <div className="grid grid-cols-2 gap-2">
 <Link href="/admin?tab=announcements" onClick={() => setMobileMenuOpen(false)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-[#E8E4DF] text-xs font-medium text-[#3C3A36]">
 <Bell className="w-3.5 h-3.5 text-[#B56E4D]" />
 Announcements
 </Link>
 <Link href="/admin?tab=events" onClick={() => setMobileMenuOpen(false)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-[#E8E4DF] text-xs font-medium text-[#3C3A36]">
 <Calendar className="w-3.5 h-3.5 text-[#5A6B7C]" />
 Events
 </Link>
 </div>
 </div>
 <div className="space-y-1">
 <p className="px-1 text-[10px] font-bold tracking-wider uppercase text-[#5B7B68]">Students</p>
 <div className="grid grid-cols-2 gap-2">
 <Link href="/admin?tab=students" onClick={() => setMobileMenuOpen(false)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-[#E8E4DF] text-xs font-medium text-[#3C3A36]">
 <GraduationCap className="w-3.5 h-3.5 text-[#5B7B68]" />
 Students
 </Link>
 <Link href="/admin?tab=subscribers" onClick={() => setMobileMenuOpen(false)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-[#E8E4DF] text-xs font-medium text-[#3C3A36]">
 <Clock3 className="w-3.5 h-3.5 text-[#B56E4D]" />
 Subscribers
 </Link>
 </div>
 </div>

 <button
 onClick={() => {
 onLogout();
 setMobileMenuOpen(false);
 }}
 className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white border border-[#ECCEC1] text-[#9E5B3D] text-xs font-semibold"
 >
 <LogOut className="w-4 h-4" />
 Sign Out
 </button>
 </div>
 ) : (
 <button
 onClick={() => {
 setMobileMenuOpen(false);
 onOpenAuthModal();
 }}
 className="w-full py-2.5 rounded-xl bg-[#1F9D55] text-[#FAF9F6] text-xs font-semibold flex items-center justify-center gap-1.5"
 >
 <ShieldCheck className="w-4 h-4" />
 <span>Admin Authentication</span>
 </button>
 )}
 </div>
 </div>
 )}
 </div>
 </header>
 );
}
