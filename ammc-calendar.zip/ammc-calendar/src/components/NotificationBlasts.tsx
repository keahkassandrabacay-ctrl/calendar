'use client';

import React, { useState, useEffect } from 'react';
import { MailOpen, Send, ChevronDown, RefreshCw, Inbox } from 'lucide-react';
import type { BlastStats } from '@/lib/db';
import ConfirmDialog from './ConfirmDialog';

interface NonOpener {
  email: string;
  sent_at: string;
  reminders_sent: number;
  last_reminder_at?: string;
}

const MIN_AGE_DAYS = 3;
const MAX_REMINDERS = 2;

export default function NotificationBlasts() {
  const [blasts, setBlasts] = useState<BlastStats[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedKey, setExpandedKey] = useState<string | null>(null);
  const [nonOpeners, setNonOpeners] = useState<NonOpener[]>([]);
  const [isExpanding, setIsExpanding] = useState(false);
  const [status, setStatus] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [pendingRemind, setPendingRemind] = useState<BlastStats | null>(null);

  const loadBlasts = async () => {
    setIsLoading(true);
    setStatus('');
    try {
      const res = await fetch('/api/notifications/blasts');
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to load notification stats.');
      setBlasts(Array.isArray(data.blasts) ? data.blasts : []);
    } catch (err: unknown) {
      setStatus(err instanceof Error ? err.message : 'Failed to load notification stats.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      void loadBlasts();
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  const blastKey = (b: BlastStats) => `${b.kind}:${b.ref_id}`;

  const handleToggle = async (blast: BlastStats) => {
    const key = blastKey(blast);
    if (expandedKey === key) {
      setExpandedKey(null);
      setNonOpeners([]);
      return;
    }
    setExpandedKey(key);
    setNonOpeners([]);
    setStatus('');
    setIsExpanding(true);
    try {
      const res = await fetch(
        `/api/notifications/blasts?kind=${encodeURIComponent(blast.kind)}&refId=${encodeURIComponent(blast.ref_id)}`
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to load recipients.');
      setNonOpeners(Array.isArray(data.nonOpeners) ? data.nonOpeners : []);
    } catch (err: unknown) {
      setStatus(err instanceof Error ? err.message : 'Failed to load recipients.');
    } finally {
      setIsExpanding(false);
    }
  };

  const handleRemind = async (blast: BlastStats) => {
    setPendingRemind(blast);
  };

  const confirmRemind = async (blast: BlastStats) => {
    setPendingRemind(null);
    setIsSending(true);
    setStatus('');
    try {
      const res = await fetch('/api/notifications/remind', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kind: blast.kind,
          refId: blast.ref_id,
          minAgeDays: MIN_AGE_DAYS,
          maxReminders: MAX_REMINDERS,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to send reminders.');
      setStatus(`Reminded ${data.reminded} of ${data.total} unopened recipient(s). ${data.skipped} skipped (too recent or at the reminder cap).`);
      await loadBlasts();
      setExpandedKey(null);
      setNonOpeners([]);
    } catch (err: unknown) {
      setStatus(err instanceof Error ? err.message : 'Failed to send reminders.');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-3xl p-6 border border-[#E8E4DF] shadow-sm">
        <h3 className="font-serif-heading text-2xl text-[#262422]">
          Notification Read Tracking
        </h3>
        <p className="text-xs text-[#6B6862]">
          Opens are counted when a recipient loads images in the email — some mail
          clients block them, so treat these as a lower bound. Recipients shown as
          not opened may still have read the message another way.
        </p>
      </div>

      {status && (
        <div className="p-3.5 rounded-2xl bg-[#EAF8EF] border border-[#B2E6C4] text-[#0E562D] text-xs">
          {status}
        </div>
      )}

      <div className="bg-white rounded-3xl p-6 border border-[#E8E4DF] shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-[#E8E4DF] pb-3">
          <h4 className="font-serif-heading text-xl text-[#262422]">Recent Blasts</h4>
          <button
            onClick={() => void loadBlasts()}
            className="p-2 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#FAF9F6] text-[#6B6862] transition"
            title="Refresh"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {isLoading ? (
          <div className="py-6 text-center text-xs text-[#6B6862] animate-pulse">Loading blasts…</div>
        ) : blasts.length === 0 ? (
          <div className="py-12 text-center text-[#6B6862] text-xs space-y-2">
            <Inbox className="w-8 h-8 text-[#DDD7CE] mx-auto" />
            <p>No notification blasts recorded yet.</p>
            <p className="text-[11px]">Posting an announcement or event creates the first entry.</p>
          </div>
        ) : (
          <ul className="divide-y divide-[#E8E4DF]">
            {blasts.map((blast) => {
              const key = blastKey(blast);
              const isOpen = expandedKey === key;
              const openRate = blast.sent > 0 ? Math.round((blast.opened / blast.sent) * 100) : 0;
              return (
                <li key={key} className="py-3 space-y-2">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-[#FAF0EB] text-[#B56E4D]">
                          {blast.kind === 'announcement' ? 'Announcement' : 'Event'}
                        </span>
                        <span className="text-[11px] text-[#6B6862] flex items-center gap-1">
                          <MailOpen className="w-3 h-3 text-[#1F9D55]" />
                          {blast.opened}/{blast.sent} opened ({openRate}%)
                        </span>
                        {blast.reminders > 0 && (
                          <span className="text-[11px] text-[#6B6862]">
                            • {blast.reminders} reminder(s) sent
                          </span>
                        )}
                      </div>
                      <p className="text-sm font-medium text-[#262422] truncate mt-1">{blast.ref_title}</p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => void handleToggle(blast)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#FAF9F6] text-xs font-medium text-[#3C3A36] transition"
                      >
                        <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                        <span>{isOpen ? 'Hide' : 'Not opened'}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRemind(blast)}
                        disabled={isSending || blast.sent - blast.opened === 0}
                        title={`Email everyone who has not opened this yet (blast must be ${MIN_AGE_DAYS}+ days old, max ${MAX_REMINDERS} reminders each)`}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-semibold transition disabled:opacity-50"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Remind</span>
                      </button>
                    </div>
                  </div>
                  {isOpen && (
                    <div className="rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] p-3">
                      {isExpanding ? (
                        <p className="text-xs text-[#6B6862] animate-pulse">Loading recipients…</p>
                      ) : nonOpeners.length === 0 ? (
                        <p className="text-xs text-[#6B6862]">Everyone has opened this.</p>
                      ) : (
                        <ul className="divide-y divide-[#E8E4DF] text-xs">
                          {nonOpeners.map((r) => (
                            <li key={r.email} className="py-1.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                              <span className="font-mono text-[11px] text-[#3C3A36]">{r.email}</span>
                              <span className="text-[11px] text-[#6B6862]">
                                sent {new Date(r.sent_at).toLocaleDateString()}
                                {r.reminders_sent > 0 ? ` • reminded ${r.reminders_sent}x` : ' • not reminded yet'}
                              </span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <ConfirmDialog
        isOpen={!!pendingRemind}
        title="Send reminder emails?"
        message={
          <>
            Everyone who has not opened &ldquo;<strong>{pendingRemind?.ref_title}</strong>&rdquo;
            {' '}will receive a reminder email. Reminders stop after {MAX_REMINDERS} per person.
          </>
        }
        confirmLabel="Send reminders"
        onConfirm={() => pendingRemind && void confirmRemind(pendingRemind)}
        onCancel={() => setPendingRemind(null)}
      />
    </div>
  );
}
