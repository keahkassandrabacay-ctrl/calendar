'use client';

import { Download } from 'lucide-react';

// Downloads a generated PDF. `id` targets one circular; omit it for the
// all-announcements export.
export default function PdfDownloadButton({
  id,
  label,
  title,
  className = 'p-2 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#EAF8EF] text-[#1F9D55] transition',
}: {
  id?: string;
  label?: string;
  title?: string;
  className?: string;
}) {
  const handleClick = async () => {
    const url = id ? `/api/announcements/pdf?id=${encodeURIComponent(id)}` : '/api/announcements/pdf';
    const res = await fetch(url);
    if (!res.ok) {
      alert('Could not generate the PDF. Please try again.');
      return;
    }
    const blob = await res.blob();
    const disposition = res.headers.get('Content-Disposition') || '';
    const match = /filename="([^"]+)"/.exec(disposition);
    const fileName = match ? match[1] : 'ammc-announcements.pdf';
    const href = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = href;
    link.download = fileName;
    link.click();
    URL.revokeObjectURL(href);
  };

  return (
    <button
      type="button"
      onClick={() => void handleClick()}
      title={title || (id ? 'Download this circular as PDF' : 'Download all announcements as PDF')}
      className={`flex items-center justify-center gap-1.5 ${className}`}
    >
      <Download className="w-3.5 h-3.5" />
      {label && <span>{label}</span>}
    </button>
  );
}