'use client';

import { useCallback, useEffect, useState } from 'react';
import { BellRing, BellOff } from 'lucide-react';
import { ensureDeviceId } from '@/lib/device-id';

type PushState = 'unsupported' | 'denied' | 'subscribed' | 'idle' | 'busy';

function urlBase64ToUint8Array(base64: string): Uint8Array<ArrayBuffer> {
  const padding = '='.repeat((4 - (base64.length % 4)) % 4);
  const normalised = (base64 + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(normalised);
  // Allocating the backing ArrayBuffer explicitly keeps the type compatible
  // with the DOM signature for applicationServerKey.
  const output = new Uint8Array(new ArrayBuffer(raw.length));
  for (let i = 0; i < raw.length; i += 1) output[i] = raw.charCodeAt(i);
  return output;
}

function isSecurePushContext(): boolean {
  return typeof window !== 'undefined' && window.isSecureContext && 'serviceWorker' in navigator;
}

// Registers this browser for push so the installed app's taskbar badge updates
// while it is closed. Chrome only allows Notification.requestPermission() from a
// user gesture, hence the button rather than an automatic prompt.
export default function PushOptIn() {
  const [state, setState] = useState<PushState>('idle');

  const syncFromPermission = useCallback(() => {
    if (typeof Notification === 'undefined') {
      setState('unsupported');
      return;
    }
    if (Notification.permission === 'granted') setState('subscribed');
    else if (Notification.permission === 'denied') setState('denied');
    else setState('idle');
  }, []);

  useEffect(() => {
    // Deferred to the next frame to match the codebase's other data-load effects
    // and avoid a synchronous setState during the effect body.
    const frame = requestAnimationFrame(syncFromPermission);
    return () => cancelAnimationFrame(frame);
  }, [syncFromPermission]);

  // Keep the server-side subscription in step with the browser's own, without
  // ever prompting: if permission already exists we can re-register silently.
  useEffect(() => {
    if (state !== 'subscribed') return;
    if (!isSecurePushContext() || !('PushManager' in window)) return;
    if (!process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY) return;

    void (async () => {
      try {
        const registration = await navigator.serviceWorker.ready;
        const existing = await registration.pushManager.getSubscription();
        if (!existing) return;
        const deviceId = await ensureDeviceId();
        await fetch('/api/push/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ deviceId, ...existing.toJSON() }),
        });
      } catch {
        /* the opt-in button will retry */
      }
    })();
  }, [state]);

  const subscribe = useCallback(async () => {
    if (!isSecurePushContext() || !('PushManager' in window) || !process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY) {
      setState('unsupported');
      return;
    }
    setState('busy');
    try {
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        setState(permission === 'denied' ? 'denied' : 'idle');
        return;
      }
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY),
      });
      const deviceId = await ensureDeviceId();
      await fetch('/api/push/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deviceId, ...subscription.toJSON() }),
      });
      setState('subscribed');
    } catch {
      setState('idle');
    }
  }, []);

  if (state === 'unsupported' || state === 'subscribed') return null;

  const label = state === 'denied' ? 'Alerts blocked' : state === 'busy' ? 'Enabling…' : 'Get alerts';

  return (
    <button
      type="button"
      onClick={() => void subscribe()}
      disabled={state === 'busy' || state === 'denied'}
      title={
        state === 'denied'
          ? 'Notifications are blocked for this site. Re-enable them in your browser settings.'
          : 'Notify me and badge the app when new announcements are posted.'
      }
      aria-label={label}
      className="p-2 rounded-full bg-white border border-[#E8E4DF] text-[#6B6862] hover:text-[#1F9D55] hover:border-[#B2E6C4] hover:bg-[#EAF8EF] transition disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {state === 'denied' ? <BellOff className="w-4 h-4" /> : <BellRing className="w-4 h-4" />}
    </button>
  );
}