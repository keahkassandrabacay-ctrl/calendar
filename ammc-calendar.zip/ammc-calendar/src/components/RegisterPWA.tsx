'use client';

import { useEffect } from 'react';

// Registers the service worker on production builds.
export default function RegisterPWA() {
  useEffect(() => {
    if (process.env.NODE_ENV !== 'production') return;
    if (!('serviceWorker' in navigator)) return;
    const register = async () => {
      try {
        if (window.serwist !== undefined) {
          await window.serwist.register();
        } else {
          await navigator.serviceWorker.register('/sw.js', { scope: '/' });
        }
      } catch {
        // App works without a service worker.
      }
    };
    register();
  }, []);
  return null;
}

declare global {
  interface Window {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    serwist?: { register: () => Promise<any> };
  }
}
