'use client';

import React, { useState } from 'react';
import { X, Bell, GraduationCap, CheckCircle2, AlertCircle, Mail, Phone } from 'lucide-react';

interface SubscribeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SubscribeModal({ isOpen, onClose }: SubscribeModalProps) {
  const [form, setForm] = useState({ student_id: '', fname: '', lname: '', mname: '', course: '', year: '1', phone: '', email: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  if (!isOpen) return null;

  const handleChange = (k: string, v: string) => setForm((prev) => ({ ...prev, [k]: v }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    if (!form.student_id.trim() || !form.fname.trim() || !form.lname.trim() || !form.course.trim() || !form.phone.trim() || !form.email.trim()) {
      setError('Please fill all required fields.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/students/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, year: Number(form.year) }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to subscribe');
      setSuccess(data.message || 'Request submitted! Wait for admin approval.');
      setForm({ student_id: '', fname: '', lname: '', mname: '', course: '', year: '1', phone: '', email: '' });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to subscribe');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setError('');
    setSuccess('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[#262422]/40 backdrop-blur-sm" onClick={handleClose} />
      <div className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto bg-white rounded-3xl shadow-xl border border-[#E8E4DF] p-6 space-y-5">
        <button onClick={handleClose} className="absolute top-4 right-4 p-2 rounded-full hover:bg-[#FAF9F6] text-[#6B6862]">
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-start gap-3 pr-8">
          <div className="w-10 h-10 rounded-2xl bg-[#EAF8EF] border border-[#B2E6C4] text-[#1F9D55] flex items-center justify-center shrink-0">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-serif-heading text-xl text-[#262422]">Subscribe to AMMC Notifications</h3>
            <p className="text-xs text-[#6B6862] leading-relaxed mt-1">
              Enter your student details to receive SMS and email alerts for every new Announcement and Event. Your request will be reviewed by an admin to prevent spam.
            </p>
          </div>
        </div>

        {error && (
          <div className="flex items-start gap-2 p-3 rounded-xl bg-[#FAF0EB] border border-[#ECCEC1] text-xs text-[#9E5B3D]">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
        {success && (
          <div className="flex items-start gap-2 p-3 rounded-xl bg-[#EAF8EF] border border-[#B2E6C4] text-xs text-[#1F9D55]">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{success}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label className="space-y-1">
              <span className="text-[11px] font-semibold text-[#6B6862]">Student ID *</span>
              <input value={form.student_id} onChange={(e) => handleChange('student_id', e.target.value)} placeholder="e.g. 2024-0001" className="w-full px-3 py-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs focus:outline-none focus:border-[#1F9D55]" required />
            </label>
            <label className="space-y-1">
              <span className="text-[11px] font-semibold text-[#6B6862]">Program *</span>
              <input value={form.course} onChange={(e) => handleChange('course', e.target.value)} placeholder="BSIT, BSN, BSED…" className="w-full px-3 py-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs focus:outline-none focus:border-[#1F9D55]" required />
            </label>
            <label className="space-y-1">
              <span className="text-[11px] font-semibold text-[#6B6862]">First Name *</span>
              <input value={form.fname} onChange={(e) => handleChange('fname', e.target.value)} className="w-full px-3 py-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs" required />
            </label>
            <label className="space-y-1">
              <span className="text-[11px] font-semibold text-[#6B6862]">Last Name *</span>
              <input value={form.lname} onChange={(e) => handleChange('lname', e.target.value)} className="w-full px-3 py-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs" required />
            </label>
            <label className="space-y-1">
              <span className="text-[11px] font-semibold text-[#6B6862]">Middle Name</span>
              <input value={form.mname} onChange={(e) => handleChange('mname', e.target.value)} className="w-full px-3 py-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs" />
            </label>
            <label className="space-y-1">
              <span className="text-[11px] font-semibold text-[#6B6862]">Year *</span>
              <select value={form.year} onChange={(e) => handleChange('year', e.target.value)} className="w-full px-3 py-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs">
                <option value="1">1st Year</option>
                <option value="2">2nd Year</option>
                <option value="3">3rd Year</option>
                <option value="4">4th Year</option>
              </select>
            </label>
            <label className="space-y-1">
              <span className="text-[11px] font-semibold text-[#6B6862] flex items-center gap-1"><Phone className="w-3 h-3" /> Phone *</span>
              <input value={form.phone} onChange={(e) => handleChange('phone', e.target.value)} placeholder="+639XXXXXXXXX" className="w-full px-3 py-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs" required />
            </label>
            <label className="space-y-1">
              <span className="text-[11px] font-semibold text-[#6B6862] flex items-center gap-1"><Mail className="w-3 h-3" /> Email *</span>
              <input type="email" value={form.email} onChange={(e) => handleChange('email', e.target.value)} placeholder="student@ammc.edu.ph" className="w-full px-3 py-2 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs" required />
            </label>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button type="submit" disabled={loading} className="flex-1 py-2.5 rounded-xl bg-[#1F9D55] hover:bg-[#168044] text-white text-xs font-semibold disabled:opacity-60 transition flex items-center justify-center gap-2">
              <GraduationCap className="w-4 h-4" />
              {loading ? 'Submitting…' : 'Request Subscription'}
            </button>
            <button type="button" onClick={handleClose} className="px-5 py-2.5 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#FAF9F6] text-[#3C3A36] text-xs font-semibold">
              Cancel
            </button>
          </div>

          <p className="text-[11px] text-[#6B6862] text-center">
            We’ll notify you by SMS and email once an admin approves your request.
          </p>
        </form>
      </div>
    </div>
  );
}
