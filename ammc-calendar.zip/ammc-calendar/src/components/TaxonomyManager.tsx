'use client';

import React, { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, Check, X } from 'lucide-react';
import { TaxonomyEntry } from '@/types';
import ConfirmDialog from './ConfirmDialog';

type EntryWithUsage = TaxonomyEntry & { usage?: { announcements: number; events: number } };

interface TaxonomyManagerProps {
  title: string;
  description: string;
  endpoint: '/api/categories' | '/api/departments';
  itemLabel: string;
  onChanged?: () => void;
}

export default function TaxonomyManager({ title, description, endpoint, itemLabel, onChanged }: TaxonomyManagerProps) {
  const [entries, setEntries] = useState<EntryWithUsage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [newName, setNewName] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const loadEntries = async () => {
    setIsLoading(true);
    setError('');
    try {
      const res = await fetch(endpoint);
      const data = await res.json();
      const key = endpoint === '/api/categories' ? 'categories' : 'departments';
      if (!res.ok) throw new Error(data.error || `Failed to load ${title.toLowerCase()}.`);
      setEntries(Array.isArray(data[key]) ? data[key] : []);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to load entries.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      void loadEntries();
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  const refresh = async () => {
    await loadEntries();
    onChanged?.();
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || isSaving) return;
    setIsSaving(true);
    setError('');
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `Failed to add ${itemLabel.toLowerCase()}.`);
      setNewName('');
      await refresh();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to add entry.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRename = async (id: string) => {
    if (!editingName.trim() || isSaving) return;
    setIsSaving(true);
    setError('');
    try {
      const res = await fetch(endpoint, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, name: editingName.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `Failed to rename ${itemLabel.toLowerCase()}.`);
      setEditingId(null);
      setEditingName('');
      await refresh();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to rename entry.');
    } finally {
      setIsSaving(false);
    }
  };

  const [pendingDelete, setPendingDelete] = useState<EntryWithUsage | null>(null);

  const handleDelete = async (entry: EntryWithUsage) => {
    const used = (entry.usage?.announcements || 0) + (entry.usage?.events || 0);
    if (used > 0) return;
    setPendingDelete(entry);
  };

  const confirmDelete = async () => {
    const entry = pendingDelete;
    if (!entry) return;
    setPendingDelete(null);
    setError('');
    try {
      const res = await fetch(`${endpoint}?id=${encodeURIComponent(entry.id)}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `Failed to delete ${itemLabel.toLowerCase()}.`);
      await refresh();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to delete entry.');
    }
  };

  return (
    <div className="bg-white rounded-3xl p-6 border border-[#E8E4DF] shadow-sm space-y-4">
      <div className="border-b border-[#E8E4DF] pb-3">
        <h3 className="font-serif-heading text-xl text-[#262422]">{title}</h3>
        <p className="text-xs text-[#6B6862]">{description}</p>
      </div>

      {error && (
        <div className="p-3 rounded-2xl bg-[#FAF0EB] border border-[#ECCEC1] text-[#9E5B3D] text-xs">
          {error}
        </div>
      )}

      <form onSubmit={handleAdd} className="flex gap-2">
        <input
          type="text"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          placeholder={`e.g. New ${itemLabel}`}
          maxLength={endpoint === '/api/categories' ? 64 : 128}
          className="flex-1 px-4 py-2 rounded-2xl bg-[#FAF9F6] border border-[#E8E4DF] text-sm text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
        />
        <button
          type="submit"
          disabled={isSaving || !newName.trim()}
          className="px-4 py-2 rounded-2xl bg-[#1F9D55] hover:bg-[#168044] text-[#FAF9F6] text-xs font-semibold flex items-center gap-1.5 transition disabled:opacity-50"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add</span>
        </button>
      </form>

      {isLoading ? (
        <div className="py-6 text-center text-xs text-[#6B6862] animate-pulse">Loading entries…</div>
      ) : entries.length === 0 ? (
        <div className="py-6 text-center text-xs text-[#6B6862]">No entries yet.</div>
      ) : (
        <ul className="divide-y divide-[#E8E4DF]">
          {entries.map((entry) => {
            const used = (entry.usage?.announcements || 0) + (entry.usage?.events || 0);
            const isEditing = editingId === entry.id;
            return (
              <li key={entry.id} className="py-2.5 flex items-center justify-between gap-3">
                {isEditing ? (
                  <div className="flex items-center gap-2 flex-1">
                    <input
                      type="text"
                      value={editingName}
                      onChange={(e) => setEditingName(e.target.value)}
                      maxLength={endpoint === '/api/categories' ? 64 : 128}
                      className="flex-1 px-3 py-1.5 rounded-xl bg-[#FAF9F6] border border-[#E8E4DF] text-xs text-[#3C3A36] focus:outline-none focus:border-[#1F9D55]"
                      autoFocus
                    />
                    <button
                      type="button"
                      onClick={() => void handleRename(entry.id)}
                      disabled={isSaving}
                      title="Save rename"
                      className="p-2 rounded-xl bg-[#EAF8EF] border border-[#B2E6C4] text-[#1F9D55] transition disabled:opacity-50"
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => { setEditingId(null); setEditingName(''); }}
                      title="Cancel rename"
                      className="p-2 rounded-xl bg-white border border-[#E8E4DF] text-[#6B6862] transition"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-[#262422] truncate">{entry.name}</p>
                      <p className="text-[11px] text-[#6B6862]">
                        {used === 0
                          ? 'Not used yet'
                          : `Used by ${used} record${used === 1 ? '' : 's'}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => { setEditingId(entry.id); setEditingName(entry.name); setError(''); }}
                        title={`Rename ${itemLabel.toLowerCase()}`}
                        className="p-2 rounded-xl bg-white border border-[#E8E4DF] hover:bg-[#FAF9F6] text-[#3C3A36] transition"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(entry)}
                        disabled={used > 0}
                        title={used > 0 ? `In use by ${used} record${used === 1 ? '' : 's'} — cannot delete` : `Delete ${itemLabel.toLowerCase()}`}
                        className="p-2 rounded-xl bg-white border border-[#E8E4DF] text-[#9E5B3D] transition enabled:hover:bg-[#FAF0EB] disabled:opacity-40 disabled:cursor-not-allowed"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </>
                )}
              </li>
            );
          })}
        </ul>
      )}

      <ConfirmDialog
        isOpen={!!pendingDelete}
        title={`Delete ${itemLabel.toLowerCase()}?`}
        message={
          <>
            &ldquo;<strong>{pendingDelete?.name}</strong>&rdquo; will be removed. This cannot be undone.
          </>
        }
        confirmLabel="Delete"
        tone="danger"
        onConfirm={() => void confirmDelete()}
        onCancel={() => setPendingDelete(null)}
      />
    </div>
  );
}
