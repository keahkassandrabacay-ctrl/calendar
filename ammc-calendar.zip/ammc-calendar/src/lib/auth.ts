import jwt from 'jsonwebtoken';
import { AdminUser } from '@/types';
import { INITIAL_ADMINS } from './seed-data';

const JWT_SECRET = process.env.JWT_SECRET || 'ammc-secret-natural-tones-key-2026';

export function signAdminToken(user: AdminUser): string {
    return jwt.sign(
        {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
            department: user.department,
        },
        JWT_SECRET,
        { expiresIn: '7d' }
    );
}

export function verifyAdminToken(token: string): AdminUser | null {
    try {
        const decoded = jwt.verify(token, JWT_SECRET) as AdminUser;
        return decoded;
    } catch {
        return null;
    }
}

export function authenticateAdminCredentials(email: string, password: string): AdminUser | null {
    const cleanEmail = email.toLowerCase().trim();

    if (cleanEmail === 'admin@ammc.edu.ph' && password === 'admin123') {
        return INITIAL_ADMINS[0];
    }
    if (cleanEmail === 'registrar@ammc.edu.ph' && password === 'admin123') {
        return INITIAL_ADMINS[1];
    }
    if (cleanEmail === 'studentaffairs@ammc.edu.ph' && password === 'admin123') {
        return INITIAL_ADMINS[2];
    }

    // Quick fallback check for any @ammc.edu.ph address with demo password
    if (cleanEmail.endsWith('@ammc.edu.ph') && password === 'admin123') {
        return {
            id: `admin-${Date.now()}`,
            email: cleanEmail,
            name: cleanEmail.split('@')[0].toUpperCase(),
            role: 'Dean / Dept Head',
            department: 'Academic Department',
        };
    }

    return null;
}
