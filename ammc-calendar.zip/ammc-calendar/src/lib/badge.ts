'use client';

// Single place that talks to the OS badge surface, so the Navbar and the push
// service worker never disagree about how a badge is set.

function badgeSupported(): boolean {
  return typeof navigator !== 'undefined' && 'setAppBadge' in navigator;
}

// Chromium resolves setAppBadge in an ordinary browser tab without drawing
// anything, so the promise is not proof of success. Gating on standalone keeps
// us from reporting a badge that was silently dropped.
export function isBadgeCapable(): boolean {
  if (!badgeSupported()) return false;
  try {
    return window.matchMedia('(display-mode: standalone)').matches;
  } catch {
    return false;
  }
}

export async function setBadge(count: number): Promise<boolean> {
  if (!badgeSupported()) return false;
  try {
    if (count > 0) await navigator.setAppBadge(count);
    else await navigator.clearAppBadge?.();
    return true;
  } catch {
    return false;
  }
}