'use client';

// Lightweight "something changed" signal so open views refresh after a write.
// Fires locally (same tab) and across tabs via BroadcastChannel.

const CHANNEL = 'ammc-data-refresh';
const EVENT = 'ammc:data-refresh';

export type RefreshKind = 'announcement' | 'event' | 'student' | 'taxonomy';

let channel: BroadcastChannel | null = null;

function getChannel(): BroadcastChannel | null {
  if (typeof window === 'undefined' || typeof BroadcastChannel === 'undefined') return null;
  if (!channel) channel = new BroadcastChannel(CHANNEL);
  return channel;
}

export function announceDataChange(kind: RefreshKind): void {
  if (typeof window === 'undefined') return;
  window.dispatchEvent(new CustomEvent(EVENT, { detail: { kind } }));
  void getChannel()?.postMessage({ kind });
}

export function subscribeDataChanges(handler: (kind: RefreshKind) => void): () => void {
  if (typeof window === 'undefined') return () => {};

  const onLocal = (e: Event) => {
    handler((e as CustomEvent<{ kind: RefreshKind }>).detail?.kind ?? 'announcement');
  };
  window.addEventListener(EVENT, onLocal);

  let onRemote: ((e: MessageEvent<{ kind: RefreshKind }>) => void) | null = null;
  const ch = getChannel();
  if (ch) {
    onRemote = (e: MessageEvent<{ kind: RefreshKind }>) => handler(e.data?.kind ?? 'announcement');
    ch.addEventListener('message', onRemote);
  }

  return () => {
    window.removeEventListener(EVENT, onLocal);
    if (ch && onRemote) ch.removeEventListener('message', onRemote);
  };
}