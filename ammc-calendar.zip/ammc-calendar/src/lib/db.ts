import mysql from 'mysql2/promise';
import crypto from 'crypto';
import { Announcement, SchoolEvent, DatabaseStatus, Student, TaxonomyEntry } from '@/types';
import { INITIAL_ANNOUNCEMENTS, INITIAL_EVENTS, INITIAL_ADMINS } from './seed-data';
import { DEFAULT_ANNOUNCEMENT_CATEGORIES, DEFAULT_DEPARTMENTS } from '@/types';

// Database config from environment or standard XAMPP defaults
const DB_HOST = (process.env.DB_HOST || '127.0.0.1').trim();
const DB_PORT = Number((process.env.DB_PORT || '3306').trim()) || 3306;
const DB_USER = (process.env.DB_USER || 'root').trim();
const DB_PASSWORD = (process.env.DB_PASSWORD || '').trim();
const DB_NAME = (process.env.DB_NAME || 'ammc').trim();

// Aiven and other cloud MySQL require SSL. Enable via DB_SSL=true or auto-detect aiven hosts.
const DB_SSL = process.env.DB_SSL?.trim().toLowerCase() === 'true' || DB_HOST.includes('aivencloud.com') || DB_HOST.includes('aiven');
const DB_SSL_CA = process.env.DB_SSL_CA?.trim(); // optional base64 or PEM string for Aiven CA
const DB_SSL_REJECT = process.env.DB_SSL_REJECT_UNAUTHORIZED?.trim().toLowerCase() !== 'false'; // default true

function getSslConfig(): unknown | undefined {
    if (!DB_SSL) return undefined;
    if (DB_SSL_CA) {
        try {
            // Support base64-encoded CA (Aiven provides ca.pem)
            const ca = DB_SSL_CA.includes('BEGIN CERTIFICATE') ? DB_SSL_CA : Buffer.from(DB_SSL_CA, 'base64').toString('utf-8');
            return { ca, rejectUnauthorized: DB_SSL_REJECT };
        } catch {
            return { rejectUnauthorized: false };
        }
    }
    return { rejectUnauthorized: DB_SSL_REJECT };
}

let mysqlPool: mysql.Pool | null = null;
let isInitialized = false;

export async function getPool(): Promise<mysql.Pool> {
    if (mysqlPool && isInitialized) {
        return mysqlPool;
    }

    try {
        const ssl = getSslConfig() as never;
        // 1. Create temporary connection to ensure database exists (skip for managed cloud where CREATE DATABASE may be restricted)
        const tempConnection = await mysql.createConnection({
            host: DB_HOST,
            port: DB_PORT,
            user: DB_USER,
            password: DB_PASSWORD, ...(ssl ? { ssl } : {}),
            connectTimeout: 10000,
        });

        try {
            await tempConnection.query(
                `CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`
            );
        } catch (createErr) {
            // On managed hosts (Aiven) user may lack CREATE DATABASE privilege or DB already exists
            console.warn(`[DB] CREATE DATABASE skipped/failed for ${DB_NAME}:`, createErr instanceof Error ? createErr.message : String(createErr));
        }
        await tempConnection.end();

        // 2. Create the main application connection pool
        if (!mysqlPool) {
            mysqlPool = mysql.createPool({
                host: DB_HOST,
                port: DB_PORT,
                user: DB_USER,
                password: DB_PASSWORD,
                database: DB_NAME, ...(ssl ? { ssl } : {}),
                waitForConnections: true,
                connectionLimit: 10,
                queueLimit: 0,
                connectTimeout: 10000,
                enableKeepAlive: true,
                keepAliveInitialDelay: 10000,
            });
        }

        // 3. Ensure tables and default seed exist in MySQL
        await initializeTables(mysqlPool);
        isInitialized = true;

        return mysqlPool;
    } catch (err: unknown) {
        mysqlPool = null;
        isInitialized = false;
        const errorMsg = err instanceof Error ? err.message : String(err);
        const hint = DB_SSL
            ? ` For Aiven/cloud MySQL ensure DB_SSL=true, DB_SSL_CA (if provided), and that the host/port/user are correct. Check Vercel env vars and redeploy after changes.`
            : ` For local Docker ensure docker compose up -d is running.`;
        throw new Error(
            `Database Connection Error: Could not connect to MySQL at ${DB_HOST}:${DB_PORT}${DB_SSL ? ' (SSL enabled)' : ''}.${hint} (${errorMsg})`
        );
    }
}

async function initializeTables(pool: mysql.Pool) {
    // Admins table
    await pool.query(`
 CREATE TABLE IF NOT EXISTS \`admins\` (
 \`id\` VARCHAR(64) PRIMARY KEY,
 \`email\` VARCHAR(191) NOT NULL UNIQUE,
 \`password_hash\` VARCHAR(255) NOT NULL,
 \`name\` VARCHAR(191) NOT NULL,
 \`role\` VARCHAR(64) NOT NULL DEFAULT 'Super Admin',
 \`department\` VARCHAR(128) NULL,
 \`created_at\` DATETIME DEFAULT CURRENT_TIMESTAMP
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
 `);

    // Announcements table
    await pool.query(`
 CREATE TABLE IF NOT EXISTS \`announcements\` (
 \`id\` VARCHAR(64) PRIMARY KEY,
 \`title\` VARCHAR(255) NOT NULL,
 \`slug\` VARCHAR(255) NOT NULL,
 \`summary\` TEXT NOT NULL,
 \`content\` LONGTEXT NOT NULL,
 \`category\` VARCHAR(64) NOT NULL,
 \`department\` VARCHAR(128) NOT NULL,
 \`audience\` VARCHAR(64) NOT NULL DEFAULT 'All Campus',
 \`urgency\` VARCHAR(32) NOT NULL DEFAULT 'normal',
 \`is_pinned\` BOOLEAN NOT NULL DEFAULT FALSE,
 \`is_published\` BOOLEAN NOT NULL DEFAULT TRUE,
 \`views\` INT NOT NULL DEFAULT 0,
 \`helpful_reactions\` INT NOT NULL DEFAULT 0,
 \`heart_reactions\` INT NOT NULL DEFAULT 0,
 \`celebrate_reactions\` INT NOT NULL DEFAULT 0,
 \`attachments_json\` LONGTEXT NULL,
 \`author_name\` VARCHAR(128) NOT NULL DEFAULT 'AMMC Administration',
 \`created_at\` DATETIME DEFAULT CURRENT_TIMESTAMP,
 \`updated_at\` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
 `);

    // Events table
    await pool.query(`
 CREATE TABLE IF NOT EXISTS \`events\` (
 \`id\` VARCHAR(64) PRIMARY KEY,
 \`title\` VARCHAR(255) NOT NULL,
 \`description\` LONGTEXT NOT NULL,
 \`location\` VARCHAR(255) NOT NULL,
 \`category\` VARCHAR(64) NOT NULL,
 \`start_time\` DATETIME NOT NULL,
 \`end_time\` DATETIME NOT NULL,
 \`capacity\` INT NOT NULL DEFAULT 0,
 \`rsvp_count\` INT NOT NULL DEFAULT 0,
 \`is_featured\` BOOLEAN NOT NULL DEFAULT FALSE,
 \`organizer\` VARCHAR(191) NOT NULL,
 \`target_audience\` VARCHAR(64) NOT NULL DEFAULT 'All Campus',
 \`department\` VARCHAR(128) NOT NULL DEFAULT 'All Departments',
 \`banner_color\` VARCHAR(32) NOT NULL DEFAULT '#1F9D55',
 \`created_at\` DATETIME DEFAULT CURRENT_TIMESTAMP
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
 `);

    // Students table
    await pool.query(`
 CREATE TABLE IF NOT EXISTS \`students\` (
 \`student_id\` VARCHAR(64) PRIMARY KEY,
 \`fname\` VARCHAR(191) NOT NULL,
 \`lname\` VARCHAR(191) NOT NULL,
 \`mname\` VARCHAR(191) NULL,
 \`course\` VARCHAR(128) NOT NULL,
 \`year\` INT NOT NULL,
 \`phone\` VARCHAR(32) NOT NULL,
 \`email\` VARCHAR(191) NOT NULL UNIQUE,
 \`status\` ENUM('pending','approved','declined') NOT NULL DEFAULT 'approved',
 \`created_at\` DATETIME DEFAULT CURRENT_TIMESTAMP
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
 `);
    // Migration: add status column if table existed before this update
    try {
        const [cols] = await pool.query<mysql.RowDataPacket[]>(`SHOW COLUMNS FROM \`students\` LIKE 'status'`);
        if (cols.length === 0) {
            await pool.query(`ALTER TABLE \`students\` ADD COLUMN \`status\` ENUM('pending','approved','declined') NOT NULL DEFAULT 'approved' AFTER \`email\``);
        }
    } catch {
        // ignore migration errors (e.g. permission)
    }

    // Managed taxonomy tables (admin-editable categories & departments)
    await pool.query(`
 CREATE TABLE IF NOT EXISTS \`categories\` (
 \`id\` VARCHAR(64) PRIMARY KEY,
 \`name\` VARCHAR(64) NOT NULL UNIQUE,
 \`created_at\` DATETIME DEFAULT CURRENT_TIMESTAMP
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
 `);
    await pool.query(`
 CREATE TABLE IF NOT EXISTS \`departments\` (
 \`id\` VARCHAR(64) PRIMARY KEY,
 \`name\` VARCHAR(128) NOT NULL UNIQUE,
 \`created_at\` DATETIME DEFAULT CURRENT_TIMESTAMP
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
 `);

    // Announcements: issue date (the date/time printed on the circular).
    try {
        const [cols] = await pool.query<mysql.RowDataPacket[]>(
            `SHOW COLUMNS FROM \`announcements\` LIKE 'issue_date'`
        );
        if (cols.length === 0) {
            await pool.query(
                `ALTER TABLE \`announcements\` ADD COLUMN \`issue_date\` DATETIME NULL AFTER \`author_name\``
            );
        }
        // Backfill any rows still missing a value from their creation timestamp.
        await pool.query(
            `UPDATE \`announcements\` SET \`issue_date\` = \`created_at\` WHERE \`issue_date\` IS NULL`
        );
    } catch {
        // ignore migration errors (e.g. permission)
    }

    // Seed default taxonomy entries.
    for (const name of DEFAULT_ANNOUNCEMENT_CATEGORIES) {
        const id = `cat-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')}`;
        await pool.query(`INSERT IGNORE INTO \`categories\` (id, name) VALUES (?, ?)`, [id, name]);
    }
    for (const name of DEFAULT_DEPARTMENTS) {
        const id = `dept-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')}`;
        await pool.query(`INSERT IGNORE INTO \`departments\` (id, name) VALUES (?, ?)`, [id, name]);
    }

    // Notification engagement log (open tracking + reminders).
    await pool.query(`
 CREATE TABLE IF NOT EXISTS \`notification_logs\` (
 \`id\` VARCHAR(64) PRIMARY KEY,
 \`kind\` ENUM('announcement','event') NOT NULL,
 \`ref_id\` VARCHAR(64) NOT NULL,
 \`ref_title\` VARCHAR(255) NOT NULL DEFAULT '',
 \`student_email\` VARCHAR(191) NOT NULL,
 \`token\` VARCHAR(64) NOT NULL UNIQUE,
 \`sent_at\` DATETIME DEFAULT CURRENT_TIMESTAMP,
 \`opened_at\` DATETIME NULL,
 \`reminders_sent\` INT NOT NULL DEFAULT 0,
 \`last_reminder_at\` DATETIME NULL,
 INDEX \`idx_blast\` (\`kind\`, \`ref_id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

    // Web Push endpoints from installed PWAs.
    await pool.query(`
    CREATE TABLE IF NOT EXISTS \`push_subscriptions\` (
      \`id\` VARCHAR(64) PRIMARY KEY,
      \`endpoint\` VARCHAR(512) NOT NULL UNIQUE,
      \`p256dh\` VARCHAR(255) NOT NULL,
      \`auth\` VARCHAR(255) NOT NULL,
      \`device_id\` VARCHAR(64) NOT NULL,
      \`created_at\` DATETIME DEFAULT CURRENT_TIMESTAMP,
      INDEX \`idx_device\` (\`device_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    // Per-device "last read" marker for the true unread badge count.
    await pool.query(`
    CREATE TABLE IF NOT EXISTS \`announcement_reads\` (
      \`device_id\` VARCHAR(64) PRIMARY KEY,
      \`last_read_at\` DATETIME NOT NULL,
      \`updated_at\` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);

    // Seed default announcements if table is empty
    const [rows] = await pool.query<mysql.RowDataPacket[]>('SELECT COUNT(*) as count FROM announcements');
    if (rows[0]?.count === 0) {
        for (const ann of INITIAL_ANNOUNCEMENTS) {
            await pool.query(
                `INSERT INTO announcements (id, title, slug, summary, content, category, department, audience, urgency, is_pinned, is_published, views, helpful_reactions, heart_reactions, celebrate_reactions, attachments_json, author_name, created_at, updated_at)
 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    ann.id,
                    ann.title,
                    ann.slug,
                    ann.summary,
                    ann.content,
                    ann.category,
                    ann.department,
                    ann.audience,
                    ann.urgency,
                    ann.is_pinned ? 1 : 0,
                    ann.is_published ? 1 : 0,
                    ann.views,
                    ann.reactions?.helpful || 0,
                    ann.reactions?.heart || 0,
                    ann.reactions?.celebrate || 0,
                    JSON.stringify(ann.attachments || []),
                    ann.author_name,
                    new Date(ann.created_at),
                    new Date(ann.updated_at),
                ]
            );
        }
    }

    // Seed default events if table is empty
    const [evtRows] = await pool.query<mysql.RowDataPacket[]>('SELECT COUNT(*) as count FROM events');
    if (evtRows[0]?.count === 0) {
        for (const evt of INITIAL_EVENTS) {
            await pool.query(
                `INSERT INTO events (id, title, description, location, category, start_time, end_time, capacity, rsvp_count, is_featured, organizer, target_audience, department, banner_color, created_at)
 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    evt.id,
                    evt.title,
                    evt.description,
                    evt.location,
                    evt.category,
                    new Date(evt.start_time),
                    new Date(evt.end_time),
                    evt.capacity,
                    evt.rsvp_count,
                    evt.is_featured ? 1 : 0,
                    evt.organizer,
                    evt.target_audience,
                    evt.department,
                    evt.banner_color || '#1F9D55',
                    new Date(evt.created_at),
                ]
            );
        }
    }
}

// ----------------------------------------------------
// Web Push + unread state
// ----------------------------------------------------

export interface PushSubscriptionRow {
    id: string;
    endpoint: string;
    p256dh: string;
    auth: string;
    device_id: string;
    last_read_at: Date | null;
}

// Registers (or refreshes) the push endpoint for a device. Re-subscribing with
// the same endpoint just rebinds it, so a rotated browser subscription is safe.
export async function upsertPushSubscription(
    endpoint: string,
    keys: { p256dh: string; auth: string },
    deviceId: string
): Promise<void> {
    const pool = await getPool();
    await pool.query(
        `INSERT INTO \`push_subscriptions\` (\`id\`, \`endpoint\`, \`p256dh\`, \`auth\`, \`device_id\`)
 VALUES (?, ?, ?, ?, ?)
 ON DUPLICATE KEY UPDATE \`p256dh\` = VALUES(\`p256dh\`), \`auth\` = VALUES(\`auth\`), \`device_id\` = VALUES(\`device_id\`)`,
        [`ps-${Date.now().toString(36)}${crypto.randomBytes(4).toString('hex')}`, endpoint, keys.p256dh, keys.auth, deviceId]
    );
    // Seed the read marker on first subscribe so a brand-new device starts at
    // zero unread instead of counting every announcement ever posted.
    await pool.query(
        `INSERT IGNORE INTO \`announcement_reads\` (\`device_id\`, \`last_read_at\`) VALUES (?, NOW())`,
        [deviceId]
    );
}

export async function deletePushSubscription(endpoint: string): Promise<void> {
    const pool = await getPool();
    await pool.query('DELETE FROM `push_subscriptions` WHERE `endpoint` = ?', [endpoint]);
}

// Subscriptions joined with each device's read marker. Used to compute a
// per-device unread count, since the count differs per reader.
export async function fetchSubscriptionsWithReadState(): Promise<PushSubscriptionRow[]> {
    const pool = await getPool();
    const [rows] = await pool.query<mysql.RowDataPacket[]>(
        `SELECT s.id, s.endpoint, s.p256dh, s.auth, s.device_id, r.last_read_at
         FROM \`push_subscriptions\` s
         LEFT JOIN \`announcement_reads\` r ON r.device_id = s.device_id`
    );
    return rows.map((r) => ({
        id: r.id,
        endpoint: r.endpoint,
        p256dh: r.p256dh,
        auth: r.auth,
        device_id: r.device_id,
        last_read_at: r.last_read_at ? new Date(r.last_read_at) : null,
    }));
}

export async function fetchLastReadAt(deviceId: string): Promise<Date | null> {
    const pool = await getPool();
    const [rows] = await pool.query<mysql.RowDataPacket[]>(
        'SELECT `last_read_at` FROM `announcement_reads` WHERE `device_id` = ?',
        [deviceId]
    );
    return rows[0]?.last_read_at ? new Date(rows[0].last_read_at) : null;
}

// Published announcements newer than this device's read marker.
export async function getUnreadCount(deviceId: string | null): Promise<number> {
    const pool = await getPool();
    if (!deviceId) return 0;
    const lastRead = await fetchLastReadAt(deviceId);
    if (!lastRead) return 0;
    const [rows] = await pool.query<mysql.RowDataPacket[]>(
        'SELECT COUNT(*) as count FROM announcements WHERE `is_published` = 1 AND `created_at` > ?',
        [lastRead]
    );
    return rows[0]?.count || 0;
}

export async function markAnnouncementsRead(deviceId: string): Promise<number> {
    const pool = await getPool();
    await pool.query(
        `INSERT INTO \`announcement_reads\` (\`device_id\`, \`last_read_at\`) VALUES (?, NOW())
         ON DUPLICATE KEY UPDATE \`last_read_at\` = NOW()`,
        [deviceId]
    );
    const unread = await getUnreadCount(deviceId);
    // Returning the fresh count lets the caller clear the OS badge in one hop.
    return unread;
}

// ----------------------------------------------------
// Public Unified Data API (Strict MySQL)
// ----------------------------------------------------

export async function getDbStatus(): Promise<DatabaseStatus> {
    try {
        const pool = await getPool();
        const [annCount] = await pool.query<mysql.RowDataPacket[]>('SELECT COUNT(*) as count FROM announcements');
        const [evtCount] = await pool.query<mysql.RowDataPacket[]>('SELECT COUNT(*) as count FROM events');
        const [studentCount] = await pool.query<mysql.RowDataPacket[]>('SELECT COUNT(*) as count FROM students WHERE status = \'approved\'');
        const [pendingCount] = await pool.query<mysql.RowDataPacket[]>('SELECT COUNT(*) as count FROM students WHERE status = \'pending\'');

        return {
            connected: true,
            engine: 'mysql',
            host: `${DB_HOST}:${DB_PORT}`,
            database: DB_NAME,
            item_counts: {
                announcements: annCount[0]?.count || 0,
                events: evtCount[0]?.count || 0,
                students: studentCount[0]?.count || 0,
                pending_students: pendingCount[0]?.count || 0,
            } as DatabaseStatus['item_counts'],
        };
    } catch (err: unknown) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        return {
            connected: false,
            engine: 'mysql',
            host: `${DB_HOST}:${DB_PORT}`,
            database: DB_NAME,
            error: errorMsg,
        };
    }
}

export async function fetchAnnouncements(): Promise<Announcement[]> {
    const pool = await getPool();
    const [rows] = await pool.query<mysql.RowDataPacket[]>(
        'SELECT * FROM announcements ORDER BY is_pinned DESC, created_at DESC'
    );

    return rows.map((r) => ({
        id: r.id,
        title: r.title,
        slug: r.slug,
        summary: r.summary,
        content: r.content,
        category: r.category,
        department: r.department,
        audience: r.audience,
        urgency: r.urgency,
        is_pinned: Boolean(r.is_pinned),
        is_published: Boolean(r.is_published),
        views: r.views || 0,
        reactions: {
            helpful: r.helpful_reactions || 0,
            heart: r.heart_reactions || 0,
            celebrate: r.celebrate_reactions || 0,
        },
        attachments: r.attachments_json ? JSON.parse(r.attachments_json) : [],
        author_name: r.author_name,
        issue_date: new Date(r.issue_date || r.created_at).toISOString(),
        created_at: new Date(r.created_at).toISOString(),
        updated_at: new Date(r.updated_at).toISOString(),
    }));
}

export async function createAnnouncement(
    announcement: Omit<Announcement, 'id' | 'views' | 'reactions' | 'created_at' | 'updated_at'>
): Promise<Announcement> {
    const pool = await getPool();
    const id = `ann-${Date.now()}`;
    const now = new Date().toISOString();

    const newAnn: Announcement = {
        ...announcement,
        id,
        views: 0,
        reactions: { helpful: 0, heart: 0, celebrate: 0 },
        issue_date: announcement.issue_date || now,
        created_at: now,
        updated_at: now,
    };

    await pool.query(
        `INSERT INTO announcements (id, title, slug, summary, content, category, department, audience, urgency, is_pinned, is_published, views, helpful_reactions, heart_reactions, celebrate_reactions, attachments_json, author_name, issue_date, created_at, updated_at)
 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, 0, ?, ?, ?, ?, ?)`,
        [
            newAnn.id,
            newAnn.title,
            newAnn.slug,
            newAnn.summary,
            newAnn.content,
            newAnn.category,
            newAnn.department,
            newAnn.audience,
            newAnn.urgency,
            newAnn.is_pinned ? 1 : 0,
            newAnn.is_published ? 1 : 0,
            JSON.stringify(newAnn.attachments || []),
            newAnn.author_name,
            new Date(newAnn.issue_date || now),
            new Date(now),
            new Date(now),
        ]
    );

    return newAnn;
}

export async function deleteAnnouncement(id: string): Promise<boolean> {
    const pool = await getPool();
    const [result] = await pool.query<mysql.ResultSetHeader>('DELETE FROM announcements WHERE id = ?', [id]);
    if (result.affectedRows === 0) {
        throw new Error(`Announcement with ID "${id}" was not found in MySQL database.`);
    }
    return true;
}

export type AnnouncementUpdate = Partial<
    Pick<
        Announcement,
        | 'title'
        | 'slug'
        | 'summary'
        | 'content'
        | 'category'
        | 'department'
        | 'audience'
        | 'urgency'
        | 'is_pinned'
        | 'is_published'
        | 'author_name'
        | 'issue_date'
    > & { attachments?: Announcement['attachments'] }
>;

export async function updateAnnouncement(id: string, updates: AnnouncementUpdate): Promise<Announcement> {
    const pool = await getPool();
    const fields: string[] = [];
    const values: unknown[] = [];
    if (updates.title !== undefined) { fields.push('title = ?'); values.push(updates.title); }
    if (updates.slug !== undefined) { fields.push('slug = ?'); values.push(updates.slug); }
    if (updates.summary !== undefined) { fields.push('summary = ?'); values.push(updates.summary); }
    if (updates.content !== undefined) { fields.push('content = ?'); values.push(updates.content); }
    if (updates.category !== undefined) { fields.push('category = ?'); values.push(updates.category); }
    if (updates.department !== undefined) { fields.push('department = ?'); values.push(updates.department); }
    if (updates.audience !== undefined) { fields.push('audience = ?'); values.push(updates.audience); }
    if (updates.urgency !== undefined) { fields.push('urgency = ?'); values.push(updates.urgency); }
    if (updates.is_pinned !== undefined) { fields.push('is_pinned = ?'); values.push(updates.is_pinned ? 1 : 0); }
    if (updates.is_published !== undefined) { fields.push('is_published = ?'); values.push(updates.is_published ? 1 : 0); }
    if (updates.author_name !== undefined) { fields.push('author_name = ?'); values.push(updates.author_name); }
    if (updates.issue_date !== undefined) { fields.push('issue_date = ?'); values.push(new Date(updates.issue_date)); }
    if (updates.attachments !== undefined) { fields.push('attachments_json = ?'); values.push(JSON.stringify(updates.attachments || [])); }
    if (fields.length === 0) throw new Error('No fields to update.');
    values.push(id);
    const [result] = await pool.query<mysql.ResultSetHeader>(
        `UPDATE announcements SET ${fields.join(', ')} WHERE id = ?`,
        values
    );
    if (result.affectedRows === 0) {
        throw new Error(`Announcement with ID "${id}" was not found in MySQL database.`);
    }
    const [rows] = await pool.query<mysql.RowDataPacket[]>('SELECT * FROM announcements WHERE id = ?', [id]);
    const r = rows[0];
    return {
        id: r.id,
        title: r.title,
        slug: r.slug,
        summary: r.summary,
        content: r.content,
        category: r.category,
        department: r.department,
        audience: r.audience,
        urgency: r.urgency,
        is_pinned: Boolean(r.is_pinned),
        is_published: Boolean(r.is_published),
        views: r.views || 0,
        reactions: {
            helpful: r.helpful_reactions || 0,
            heart: r.heart_reactions || 0,
            celebrate: r.celebrate_reactions || 0,
        },
        attachments: r.attachments_json ? JSON.parse(r.attachments_json) : [],
        author_name: r.author_name,
        issue_date: new Date(r.issue_date || r.created_at).toISOString(),
        created_at: new Date(r.created_at).toISOString(),
        updated_at: new Date(r.updated_at).toISOString(),
    };
}

// ----------------------------------------------------
// Managed taxonomy (categories & departments)
// ----------------------------------------------------

function taxonomyId(prefix: string, name: string): string {
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'custom';
    return `${prefix}-${Date.now().toString(36)}-${slug}`.slice(0, 64);
}

export async function fetchTaxonomy(table: 'categories' | 'departments'): Promise<TaxonomyEntry[]> {
    const pool = await getPool();
    const [rows] = await pool.query<mysql.RowDataPacket[]>(`SELECT * FROM \`${table}\` ORDER BY name ASC`);
    return rows.map((r) => ({
        id: r.id,
        name: r.name,
        created_at: r.created_at ? new Date(r.created_at).toISOString() : undefined,
    }));
}

export async function createTaxonomyEntry(table: 'categories' | 'departments', name: string): Promise<TaxonomyEntry> {
    const clean = name.trim();
    if (!clean) throw new Error('Name is required.');
    if ((table === 'categories' && clean.length > 64) || (table === 'departments' && clean.length > 128)) {
        throw new Error('Name is too long.');
    }
    const pool = await getPool();
    const entry: TaxonomyEntry = {
        id: taxonomyId(table === 'categories' ? 'cat' : 'dept', clean),
        name: clean,
    };
    try {
        await pool.query(`INSERT INTO \`${table}\` (id, name) VALUES (?, ?)`, [entry.id, entry.name]);
    } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        if (msg.includes('Duplicate entry')) throw new Error(`"${clean}" already exists.`);
        throw err;
    }
    return entry;
}

export async function renameTaxonomyEntry(
    table: 'categories' | 'departments',
    id: string,
    name: string
): Promise<TaxonomyEntry> {
    const clean = name.trim();
    if (!clean) throw new Error('Name is required.');
    const pool = await getPool();
    const [rows] = await pool.query<mysql.RowDataPacket[]>(`SELECT * FROM \`${table}\` WHERE id = ?`, [id]);
    if (rows.length === 0) throw new Error('Entry not found.');
    const oldName: string = rows[0].name;
    if (oldName === clean) {
        return { id, name: oldName, created_at: new Date(rows[0].created_at).toISOString() };
    }
    try {
        await pool.query(`UPDATE \`${table}\` SET name = ? WHERE id = ?`, [clean, id]);
    } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        if (msg.includes('Duplicate entry')) throw new Error(`"${clean}" already exists.`);
        throw err;
    }
    // Cascade the rename to referencing rows (manual "FK" — columns store names).
    if (table === 'categories') {
        await pool.query(`UPDATE announcements SET category = ? WHERE category = ?`, [clean, oldName]);
    } else {
        await pool.query(`UPDATE announcements SET department = ? WHERE department = ?`, [clean, oldName]);
        await pool.query(`UPDATE events SET department = ? WHERE department = ?`, [clean, oldName]);
    }
    return { id, name: clean };
}

export async function taxonomyUsage(
    table: 'categories' | 'departments',
    name: string
): Promise<{ announcements: number; events: number }> {
    const pool = await getPool();
    const column = table === 'categories' ? 'category' : 'department';
    const [annRows] = await pool.query<mysql.RowDataPacket[]>(
        `SELECT COUNT(*) as count FROM announcements WHERE \`${column}\` = ?`,
        [name]
    );
    let events = 0;
    if (table === 'departments') {
        const [evtRows] = await pool.query<mysql.RowDataPacket[]>(
            'SELECT COUNT(*) as count FROM events WHERE department = ?',
            [name]
        );
        events = evtRows[0]?.count || 0;
    }
    return { announcements: annRows[0]?.count || 0, events };
}

export async function deleteTaxonomyEntry(table: 'categories' | 'departments', id: string): Promise<boolean> {
    const pool = await getPool();
    const [rows] = await pool.query<mysql.RowDataPacket[]>(`SELECT * FROM \`${table}\` WHERE id = ?`, [id]);
    if (rows.length === 0) throw new Error('Entry not found.');
    const usage = await taxonomyUsage(table, rows[0].name as string);
    const total = usage.announcements + usage.events;
    if (total > 0) {
        throw new Error(
            `"${rows[0].name}" is still used by ${total} record${total === 1 ? '' : 's'} and cannot be deleted.`
        );
    }
    const [result] = await pool.query<mysql.ResultSetHeader>(`DELETE FROM \`${table}\` WHERE id = ?`, [id]);
    return result.affectedRows > 0;
}

export async function reactToAnnouncement(
    id: string,
    reactionType: 'helpful' | 'heart' | 'celebrate'
): Promise<{ helpful: number; heart: number; celebrate: number }> {
    const pool = await getPool();
    const column =
        reactionType === 'helpful'
            ? 'helpful_reactions'
            : reactionType === 'heart'
                ? 'heart_reactions'
                : 'celebrate_reactions';

    await pool.query(`UPDATE announcements SET ${column} = ${column} + 1 WHERE id = ?`, [id]);

    const [rows] = await pool.query<mysql.RowDataPacket[]>(
        'SELECT helpful_reactions, heart_reactions, celebrate_reactions FROM announcements WHERE id = ?',
        [id]
    );

    if (rows.length === 0) {
        throw new Error(`Announcement with ID "${id}" was not found in MySQL database.`);
    }

    return {
        helpful: rows[0].helpful_reactions || 0,
        heart: rows[0].heart_reactions || 0,
        celebrate: rows[0].celebrate_reactions || 0,
    };
}

export async function fetchEvents(): Promise<SchoolEvent[]> {
    const pool = await getPool();
    const [rows] = await pool.query<mysql.RowDataPacket[]>('SELECT * FROM events ORDER BY start_time ASC');

    return rows.map((r) => ({
        id: r.id,
        title: r.title,
        description: r.description,
        location: r.location,
        category: r.category,
        start_time: new Date(r.start_time).toISOString(),
        end_time: new Date(r.end_time).toISOString(),
        capacity: r.capacity || 0,
        rsvp_count: r.rsvp_count || 0,
        is_featured: Boolean(r.is_featured),
        organizer: r.organizer,
        target_audience: r.target_audience,
        department: r.department,
        banner_color: r.banner_color,
        created_at: new Date(r.created_at).toISOString(),
    }));
}

export async function createEvent(
    event: Omit<SchoolEvent, 'id' | 'rsvp_count' | 'created_at'>
): Promise<SchoolEvent> {
    const pool = await getPool();
    const id = `evt-${Date.now()}`;
    const now = new Date().toISOString();

    const newEvt: SchoolEvent = {
        ...event,
        id,
        rsvp_count: 0,
        created_at: now,
    };

    await pool.query(
        `INSERT INTO events (id, title, description, location, category, start_time, end_time, capacity, rsvp_count, is_featured, organizer, target_audience, department, banner_color, created_at)
 VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?)`,
        [
            newEvt.id,
            newEvt.title,
            newEvt.description,
            newEvt.location,
            newEvt.category,
            new Date(newEvt.start_time),
            new Date(newEvt.end_time),
            newEvt.capacity,
            newEvt.is_featured ? 1 : 0,
            newEvt.organizer,
            newEvt.target_audience,
            newEvt.department,
            newEvt.banner_color || '#1F9D55',
            new Date(now),
        ]
    );

    return newEvt;
}

export async function deleteEvent(id: string): Promise<boolean> {
    const pool = await getPool();
    const [result] = await pool.query<mysql.ResultSetHeader>('DELETE FROM events WHERE id = ?', [id]);
    if (result.affectedRows === 0) {
        throw new Error(`Event with ID "${id}" was not found in MySQL database.`);
    }
    return true;
}

export type EventUpdate = Partial<
    Pick<
        SchoolEvent,
        | 'title'
        | 'description'
        | 'location'
        | 'category'
        | 'start_time'
        | 'end_time'
        | 'capacity'
        | 'is_featured'
        | 'organizer'
        | 'target_audience'
        | 'department'
        | 'banner_color'
    >
>;

function mapEventRow(r: mysql.RowDataPacket): SchoolEvent {
    return {
        id: r.id,
        title: r.title,
        description: r.description,
        location: r.location,
        category: r.category,
        start_time: new Date(r.start_time).toISOString(),
        end_time: new Date(r.end_time).toISOString(),
        capacity: r.capacity || 0,
        rsvp_count: r.rsvp_count || 0,
        is_featured: Boolean(r.is_featured),
        organizer: r.organizer,
        target_audience: r.target_audience,
        department: r.department,
        banner_color: r.banner_color,
        created_at: new Date(r.created_at).toISOString(),
    };
}

export async function updateEvent(id: string, updates: EventUpdate): Promise<SchoolEvent> {
    const pool = await getPool();
    const fields: string[] = [];
    const values: unknown[] = [];
    if (updates.title !== undefined) { fields.push('title = ?'); values.push(updates.title); }
    if (updates.description !== undefined) { fields.push('description = ?'); values.push(updates.description); }
    if (updates.location !== undefined) { fields.push('location = ?'); values.push(updates.location); }
    if (updates.category !== undefined) { fields.push('category = ?'); values.push(updates.category); }
    if (updates.start_time !== undefined) { fields.push('start_time = ?'); values.push(new Date(updates.start_time)); }
    if (updates.end_time !== undefined) { fields.push('end_time = ?'); values.push(new Date(updates.end_time)); }
    if (updates.capacity !== undefined) { fields.push('capacity = ?'); values.push(updates.capacity); }
    if (updates.is_featured !== undefined) { fields.push('is_featured = ?'); values.push(updates.is_featured ? 1 : 0); }
    if (updates.organizer !== undefined) { fields.push('organizer = ?'); values.push(updates.organizer); }
    if (updates.target_audience !== undefined) { fields.push('target_audience = ?'); values.push(updates.target_audience); }
    if (updates.department !== undefined) { fields.push('department = ?'); values.push(updates.department); }
    if (updates.banner_color !== undefined) { fields.push('banner_color = ?'); values.push(updates.banner_color); }
    if (fields.length === 0) throw new Error('No fields to update.');
    values.push(id);
    const [result] = await pool.query<mysql.ResultSetHeader>(
        `UPDATE events SET ${fields.join(', ')} WHERE id = ?`,
        values
    );
    if (result.affectedRows === 0) {
        throw new Error(`Event with ID "${id}" was not found in MySQL database.`);
    }
    const [rows] = await pool.query<mysql.RowDataPacket[]>('SELECT * FROM events WHERE id = ?', [id]);
    return mapEventRow(rows[0]);
}

// ----------------------------------------------------
// Students
// ----------------------------------------------------

export async function fetchStudents(status?: Student['status']): Promise<Student[]> {
    const pool = await getPool();
    const query = status ? 'SELECT * FROM students WHERE status = ? ORDER BY created_at DESC' : 'SELECT * FROM students ORDER BY created_at DESC';
    const params = status ? [status] : [];
    const [rows] = await pool.query<mysql.RowDataPacket[]>(query, params);
    return rows.map((r) => ({
        student_id: r.student_id,
        fname: r.fname,
        lname: r.lname,
        mname: r.mname || undefined,
        course: r.course,
        year: r.year,
        phone: r.phone,
        email: r.email,
        status: r.status as Student['status'],
        created_at: r.created_at ? new Date(r.created_at).toISOString() : undefined,
    }));
}

export async function fetchPendingStudents(): Promise<Student[]> {
    return fetchStudents('pending');
}

export async function createStudent(student: Student): Promise<Student> {
    const pool = await getPool();
    const status = student.status || 'approved';
    await pool.query(
        `INSERT INTO students (student_id, fname, lname, mname, course, year, phone, email, status)
 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [student.student_id, student.fname, student.lname, student.mname || null, student.course, student.year, student.phone, student.email, status]
    );
    return { ...student, status: status as Student['status'] };
}

export async function createSubscriptionRequest(student: Omit<Student, 'status' | 'created_at'>): Promise<Student> {
    return createStudent({ ...student, status: 'pending' } as Student);
}

export async function deleteStudent(studentId: string): Promise<boolean> {
    const pool = await getPool();
    const [result] = await pool.query<mysql.ResultSetHeader>('DELETE FROM students WHERE student_id = ?', [studentId]);
    if (result.affectedRows === 0) {
        throw new Error(`Student with ID "${studentId}" was not found.`);
    }
    return true;
}

export async function updateStudent(studentId: string, updates: Partial<Omit<Student, 'student_id'>>): Promise<Student> {
    const pool = await getPool();
    const fields: string[] = [];
    const values: unknown[] = [];
    if (updates.fname !== undefined) { fields.push('fname = ?'); values.push(updates.fname); }
    if (updates.lname !== undefined) { fields.push('lname = ?'); values.push(updates.lname); }
    if (updates.mname !== undefined) { fields.push('mname = ?'); values.push(updates.mname || null); }
    if (updates.course !== undefined) { fields.push('course = ?'); values.push(updates.course); }
    if (updates.year !== undefined) { fields.push('year = ?'); values.push(updates.year); }
    if (updates.phone !== undefined) { fields.push('phone = ?'); values.push(updates.phone); }
    if (updates.email !== undefined) { fields.push('email = ?'); values.push(updates.email); }
    if ((updates as unknown as { status?: string }).status !== undefined) { fields.push('status = ?'); values.push((updates as unknown as { status: string }).status); }
    if (fields.length === 0) throw new Error('No fields to update.');
    values.push(studentId);
    const [result] = await pool.query<mysql.ResultSetHeader>(`UPDATE students SET ${fields.join(', ')} WHERE student_id = ?`, values);
    if (result.affectedRows === 0) throw new Error(`Student with ID "${studentId}" was not found.`);
    const [rows] = await pool.query<mysql.RowDataPacket[]>('SELECT * FROM students WHERE student_id = ?', [studentId]);
    const r = rows[0];
    return { student_id: r.student_id, fname: r.fname, lname: r.lname, mname: r.mname || undefined, course: r.course, year: r.year, phone: r.phone, email: r.email, status: r.status, created_at: r.created_at ? new Date(r.created_at).toISOString() : undefined };
}

export async function approveStudent(studentId: string): Promise<Student> {
    return updateStudent(studentId, { status: 'approved' } as unknown as Partial<Omit<Student, 'student_id'>>);
}

export async function declineStudent(studentId: string): Promise<Student> {
    return updateStudent(studentId, { status: 'declined' } as unknown as Partial<Omit<Student, 'student_id'>>);
}

// ----------------------------------------------------
// Notification engagement log (open tracking + reminders)
// ----------------------------------------------------

export type BlastKind = 'announcement' | 'event';

export interface BlastLogEntry {
    id: string;
    kind: BlastKind;
    ref_id: string;
    ref_title: string;
    student_email: string;
    token: string;
    sent_at: string;
    opened_at?: string;
    reminders_sent: number;
    last_reminder_at?: string;
}

export interface BlastStats {
    kind: BlastKind;
    ref_id: string;
    ref_title: string;
    sent: number;
    opened: number;
    reminders: number;
    last_activity?: string;
}

function mapLogRow(r: mysql.RowDataPacket): BlastLogEntry {
    return {
        id: r.id,
        kind: r.kind as BlastKind,
        ref_id: r.ref_id,
        ref_title: r.ref_title || '',
        student_email: r.student_email,
        token: r.token,
        sent_at: new Date(r.sent_at).toISOString(),
        opened_at: r.opened_at ? new Date(r.opened_at).toISOString() : undefined,
        reminders_sent: r.reminders_sent || 0,
        last_reminder_at: r.last_reminder_at ? new Date(r.last_reminder_at).toISOString() : undefined,
    };
}

// Records one blast (one row per recipient). Returns the per-email tokens
// so the send loop can embed each recipient's tracking pixel.
export async function logBlast(
    kind: BlastKind,
    refId: string,
    title: string,
    emails: string[]
): Promise<Array<{ email: string; token: string }>> {
    const pool = await getPool();
    const entries = emails.map((email) => ({
        id: `nl-${Date.now().toString(36)}${crypto.randomBytes(4).toString('hex')}`,
        email: email.trim().toLowerCase(),
        token: crypto.randomBytes(16).toString('hex'),
    }));
    for (const e of entries) {
        await pool.query(
            `INSERT INTO notification_logs (id, kind, ref_id, ref_title, student_email, token)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [e.id, kind, refId, title.slice(0, 255), e.email, e.token]
        );
    }
    return entries;
}

// Stamps the first open for a tracking token. Returns false for unknown or
// already-opened tokens (repeat image loads must not skew stats).
export async function recordOpen(token: string): Promise<boolean> {
    if (!token || token.length > 64) return false;
    const pool = await getPool();
    const [result] = await pool.query<mysql.ResultSetHeader>(
        'UPDATE notification_logs SET opened_at = CURRENT_TIMESTAMP WHERE token = ? AND opened_at IS NULL',
        [token]
    );
    return result.affectedRows > 0;
}

export async function fetchBlastStats(): Promise<BlastStats[]> {
    const pool = await getPool();
    const [rows] = await pool.query<mysql.RowDataPacket[]>(
        `SELECT kind, ref_id, ref_title,
                COUNT(*) as sent,
                COUNT(opened_at) as opened,
                COALESCE(SUM(reminders_sent), 0) as reminders,
                MAX(COALESCE(last_reminder_at, opened_at, sent_at)) as last_activity
         FROM notification_logs
         GROUP BY kind, ref_id, ref_title
         ORDER BY last_activity DESC`
    );
    return rows.map((r) => ({
        kind: r.kind as BlastKind,
        ref_id: r.ref_id,
        ref_title: r.ref_title || '',
        sent: Number(r.sent) || 0,
        opened: Number(r.opened) || 0,
        reminders: Number(r.reminders) || 0,
        last_activity: r.last_activity ? new Date(r.last_activity).toISOString() : undefined,
    }));
}

export async function fetchNonOpeners(kind: BlastKind, refId: string): Promise<BlastLogEntry[]> {
    const pool = await getPool();
    const [rows] = await pool.query<mysql.RowDataPacket[]>(
        'SELECT * FROM notification_logs WHERE kind = ? AND ref_id = ? AND opened_at IS NULL ORDER BY sent_at ASC',
        [kind, refId]
    );
    return rows.map(mapLogRow);
}

export async function markReminderSent(logId: string): Promise<void> {
    const pool = await getPool();
    await pool.query(
        'UPDATE notification_logs SET reminders_sent = reminders_sent + 1, last_reminder_at = CURRENT_TIMESTAMP WHERE id = ?',
        [logId]
    );
}
