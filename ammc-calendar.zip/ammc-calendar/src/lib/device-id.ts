// Anonymous per-browser identifier used to key unread state and push
// subscriptions. It is not an auth credential — anyone can mint their own — so
// it must never gate access to anything private.
//
// Stored twice on purpose: localStorage for synchronous reads on the page, and
// IndexedDB so the service worker can reach the same value. Workers have no
// access to localStorage, and a pushsubscriptionchange re-subscribe has to
// re-bind to the original device or the unread count resets.

const DEVICE_KEY = 'ammc-device-id';
const DB_NAME = 'ammc-device';
const STORE_NAME = 'device';

function uuid(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

function openDb(): Promise<IDBDatabase | null> {
  return new Promise((resolve) => {
    try {
      if (typeof indexedDB === 'undefined') {
        resolve(null);
        return;
      }
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME);
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function idbGet(): Promise<string | null> {
  const db = await openDb();
  if (!db) return null;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const request = tx.objectStore(STORE_NAME).get(DEVICE_KEY);
      request.onsuccess = () => resolve(typeof request.result === 'string' ? request.result : null);
      request.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function idbSet(value: string): Promise<void> {
  const db = await openDb();
  if (!db) return;
  await new Promise<void>((resolve) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(value, DEVICE_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

/** Synchronous accessor for page code. Returns '' during SSR. */
export function getDeviceId(): string {
  if (typeof window === 'undefined') return '';
  try {
    const existing = localStorage.getItem(DEVICE_KEY);
    if (existing) return existing;
  } catch {
    // Storage blocked; fall through to the async path.
  }
  return '';
}

/** Page-side accessor that mints and persists an id on first use. */
export async function ensureDeviceId(): Promise<string> {
  const existing = getDeviceId();
  if (existing) {
    void idbSet(existing);
    return existing;
  }
  const stored = await idbGet();
  if (stored) {
    try {
      localStorage.setItem(DEVICE_KEY, stored);
    } catch {
      /* ignore */
    }
    return stored;
  }
  const created = uuid();
  try {
    localStorage.setItem(DEVICE_KEY, created);
  } catch {
    /* ignore */
  }
  await idbSet(created);
  return created;
}

/** Service-worker-side accessor. Workers must not touch localStorage. */
export async function getDeviceIdForWorker(): Promise<string> {
  const stored = await idbGet();
  return stored ?? '';
}