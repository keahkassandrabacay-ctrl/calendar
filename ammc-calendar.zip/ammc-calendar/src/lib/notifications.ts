import mysql from 'mysql2/promise';
import { SchoolEvent } from '@/types';
import { Announcement } from '@/types';

function normalizePhone(phone: string): string {
  const p = phone.trim();
  if (p.startsWith('+')) return p;
  if (p.startsWith('09') && p.length === 11) return `+63${p.slice(1)}`;
  if (p.startsWith('9') && p.length === 10) return `+63${p}`;
  return p;
}

export async function sendSMS(phone: string, message: string): Promise<boolean> {
  const apiKey = (process.env.TEXTBEE_API_KEY || '').trim();
  if (!apiKey || apiKey === 'your_textbee_api_key_here') {
    console.log(`[SMS SKIPPED] No TextBee API key configured. Message for ${phone}: ${message}`);
    return false;
  }

  try {
    const normalized = normalizePhone(phone);
    const res = await fetch('https://api.textbee.dev/api/v1/gateway/send-sms', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
      body: JSON.stringify({
        recipients: [normalized],
        message,
      }),
    });

    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`TextBee SMS ${res.status}: ${txt}`);
    }

    const data = await res.json();
    console.log(`[SMS SENT] to ${phone}: ${message} →`, data);
    return true;
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`[SMS FAILED] to ${phone}:`, msg);
    return false;
  }
}

let transporter: import('nodemailer').Transporter | null = null;

function getTransporter(): import('nodemailer').Transporter | null {
  const host = (process.env.SMTP_HOST || '').trim();
  const port = Number((process.env.SMTP_PORT || '587').trim()) || 587;
  const user = (process.env.SMTP_USER || '').trim();
  const pass = (process.env.SMTP_PASS || '').trim();
  const secure = (process.env.SMTP_SECURE || '').trim() === 'true';

  if (!host || !user || !pass || host === 'your_smtp_host_here') {
    return null;
  }

  if (transporter) return transporter;

  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const nodemailer = require('nodemailer') as typeof import('nodemailer');
  transporter = nodemailer.createTransport({
    host,
    port,
    secure: port === 465 || secure,
    auth: { user, pass },
  });
  return transporter;
}

let logoBuffer: Buffer | null = null;
let logoAttempted = false;

// School seal embedded in every email (CID attachment, so it renders without
// any public URL). Cached in memory after the first read.
function getLogoAttachment(): Array<{ filename: string; content: Buffer; cid: string }> {
  if (!logoAttempted) {
    logoAttempted = true;
    try {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const fs = require('fs') as typeof import('fs');
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const path = require('path') as typeof import('path');
      logoBuffer = fs.readFileSync(path.join(process.cwd(), 'public', 'icons', 'icon-192x192.png'));
    } catch {
      logoBuffer = null;
    }
  }
  if (!logoBuffer) return [];
  return [{ filename: 'ammc-logo.png', content: logoBuffer, cid: 'ammc-logo' }];
}

export async function sendEmail(
  to: string,
  subject: string,
  html: string,
  attachments: Array<{ filename: string; content: Buffer; cid: string }> = []
): Promise<boolean> {
  let from = (process.env.EMAIL_FROM || '').trim();
  const tp = getTransporter();

  if (!tp) {
    console.log(`[EMAIL SKIPPED] No SMTP configured (SMTP_HOST/SMTP_USER/SMTP_PASS). To: ${to}, Subject: ${subject}`);
    return false;
  }
  // Gmail forces FROM to the authenticated user; compare bare addresses so a
  // display name in EMAIL_FROM survives.
  const smtpUser = (process.env.SMTP_USER || '').trim();
  if (!from) from = smtpUser;
  const fromAddress = (from.match(/<([^>]+)>/)?.[1] ?? from).trim().toLowerCase();
  if (smtpUser.toLowerCase().endsWith('@gmail.com') && fromAddress !== smtpUser.toLowerCase()) {
    console.log(`[EMAIL FROM OVERRIDE] Gmail SMTP requires FROM to be authenticated user. Overriding ${from} -> ${smtpUser}`);
    from = smtpUser;
  }
  if (!from) {
    console.error('[EMAIL MISSING] EMAIL_FROM not configured');
    return false;
  }

  try {
    const info = await tp.sendMail({
      from,
      to,
      subject,
      html,
      attachments: attachments.map((a) => ({
        filename: a.filename,
        content: a.content,
        cid: a.cid,
        contentType: 'image/png',
        contentDisposition: 'inline' as const,
      })),
    });
    console.log(`[EMAIL SENT] to ${to}: ${subject} (${info.messageId})`);
    return true;
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`[EMAIL FAILED] to ${to}:`, msg);
    return false;
  }
}

async function getPool(): Promise<mysql.Pool> {
  const { getPool } = await import('./db');
  return getPool();
}

interface StudentRow {
  student_id: string;
  fname: string;
  lname: string;
  mname?: string;
  course: string;
  year: number;
  phone: string;
  email: string;
}

export async function getAllStudents(): Promise<StudentRow[]> {
  const pool = await getPool();
  const [rows] = await pool.query<mysql.RowDataPacket[]>("SELECT student_id, fname, lname, mname, course, year, phone, email FROM students WHERE status = 'approved'");
  return rows.map(r => ({
    student_id: r.student_id,
    fname: r.fname,
    lname: r.lname,
    mname: r.mname,
    course: r.course,
    year: r.year,
    phone: r.phone,
    email: r.email,
  }));
}

export async function getStudentsByAudience(audience: string, department?: string): Promise<StudentRow[]> {
  const pool = await getPool();
  let query = "SELECT student_id, fname, lname, mname, course, year, phone, email FROM students WHERE status = 'approved'";
  const params: (string | number)[] = [];

  if (audience && audience !== 'All Campus') {
    // Map TargetAudience values to course/department filtering
    // For now, we'll filter by course based on audience
    // This is a simplistic mapping - in production, you'd have a proper audience-course mapping
    if (audience === 'College Students') {
      query += ' AND year >= 1 AND year <= 4';
    } else if (audience === 'Senior High School') {
      query += ' AND year <= 12';
    } else if (audience === 'Faculty & Staff') {
      // Not applicable for students table
    } else if (audience === 'Parents & Guardians') {
      // Not applicable - would need parent records
    }
  }

  if (department && department !== 'All Departments') {
    query += ' AND course LIKE ?';
    params.push(`%${department}%`);
  }

  const [rows] = await pool.query<mysql.RowDataPacket[]>(query, params);
  return rows.map(r => ({
    student_id: r.student_id,
    fname: r.fname,
    lname: r.lname,
    mname: r.mname,
    course: r.course,
    year: r.year,
    phone: r.phone,
    email: r.email,
  }));
}

type AnnouncementPayload = Pick<Announcement, 'id' | 'title' | 'summary' | 'category' | 'department' | 'audience' | 'urgency'>;
type EventPayload = Pick<SchoolEvent, 'id' | 'title' | 'description' | 'location' | 'category' | 'start_time' | 'end_time' | 'target_audience' | 'department'>;

// Absolute site URL for the tracking pixel. Unset (e.g. localhost dev) means
// mail clients couldn't load the pixel anyway, so it is omitted.
function appBaseUrl(): string {
  return (process.env.APP_URL || '').trim().replace(/\/$/, '');
}

function pixelImg(token: string): string {
  const base = appBaseUrl();
  if (!base) return '';
  return `<img src="${base}/api/track/open?token=${token}" width="1" height="1" alt="" style="display:block;width:1px;height:1px;" />`;
}

function escapeHtml(value: string): string {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// Mail clients (notably Gmail) strip webfonts, so the app's font theme is
// mirrored with its fallback stacks: Instrument Serif -> Georgia serif for
// display type, Plus Jakarta Sans -> system sans for body/UI text.
// Plain-text layout for SMS: bracketed header, labelled detail lines, and a
// link back to the app. Kept terse — long messages get split into multiple
// 160-character segments.
function smsTemplate(opts: { header: string; title: string; lines: string[]; linkPath: string }): string {
  const base = appBaseUrl();
  const link = base ? `\n\nSee full details:\n${base}${opts.linkPath}` : '';
  return `[AMMC] ${opts.header}\n${opts.title}\n\n${opts.lines.join('\n')}${link}`;
}

const SMS_URGENCY_LABEL: Record<string, string> = {
  critical: '🔴 Urgent Alert',
  important: '⚠️ Important Advisory',
  normal: 'ℹ️ General Notice',
};

const EMAIL_SERIF = `Georgia,'Times New Roman',serif`;
const EMAIL_SANS = `-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,Helvetica,sans-serif`;

// Shared branded layout for all notification emails. Inline styles only:
// mail clients (notably Gmail) strip <style> blocks.
function emailLayout(opts: {
  eyebrow: string;
  title: string;
  bodyHtml: string;
  footerNote: string;
  pixel?: string;
}): string {
  const logo = `<img src="cid:ammc-logo" width="64" height="64" alt="AMMC Seal" style="display:block;width:64px;height:64px;border-radius:14px;margin-bottom:8px;" />`;
  return `<div style="margin:0;padding:16px 8px;background-color:#F4EFEA;font-family:${EMAIL_SANS};">` +
    `<div style="max-width:560px;margin:0 auto;background-color:#ffffff;border:1px solid #E8E4DF;border-radius:12px;overflow:hidden;">` +
    `<div style="background-color:#1F9D55;padding:20px 24px;">${logo}` +
    `<p style="margin:0;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;color:#DDD8CE;font-family:${EMAIL_SANS};">Dr. Aurelio Mendoza Memorial Colleges</p>` +
    `<p style="margin:4px 0 0;font-size:18px;font-weight:bold;color:#FAF9F6;font-family:${EMAIL_SERIF};">${escapeHtml(opts.eyebrow)}</p></div>` +
    `<div style="padding:20px 24px;color:#3C3A36;font-size:14px;line-height:1.6;font-family:${EMAIL_SANS};">` +
    `<p style="margin:0 0 12px;font-size:20px;font-weight:bold;color:#262422;font-family:${EMAIL_SERIF};">${escapeHtml(opts.title)}</p>` +
    `${opts.bodyHtml}</div>` +
    `<div style="padding:14px 24px;background-color:#FAF9F6;border-top:1px solid #E8E4DF;color:#6B6862;font-size:11px;line-height:1.5;font-family:${EMAIL_SANS};">` +
    `<p style="margin:0;">${escapeHtml(opts.footerNote)}</p>` +
    `<p style="margin:6px 0 0;">Ipil, Zamboanga Sibugay &bull; You received this because you are a subscribed AMMC student.</p>` +
    `</div></div>${opts.pixel || ''}</div>`;
}

export async function notifyNewAnnouncement(announcement: AnnouncementPayload): Promise<{ sms: number; email: number }> {
  const students = await getAllStudents();
  console.log(`[NOTIFY] notifyNewAnnouncement "${announcement.title}" — ${students.length} student(s) found`);
  if (students.length === 0) {
    console.log('[NOTIFY] No students in database — skipping SMS/email. Add students via Admin → Students tab.');
    return { sms: 0, email: 0 };
  }
  const { logBlast } = await import('./db');
  const tokens = await logBlast(
    'announcement',
    announcement.id,
    announcement.title,
    students.map((s) => s.email).filter((e) => !!e)
  );
  const tokenByEmail = new Map(tokens.map((t) => [t.email, t.token]));
  let sentSMS = 0;
  let sentEmail = 0;

  const baseSMS = smsTemplate({
    header: 'Announcement',
    title: announcement.title,
    lines: [
      `📎 ${announcement.department}`,
      `👥 ${announcement.audience}`,
      SMS_URGENCY_LABEL[announcement.urgency] || 'ℹ️ General Notice',
    ],
    linkPath: '/announcements',
  });

  for (const student of students) {
    // Send SMS
    if (student.phone) {
      const smsSent = await sendSMS(student.phone, baseSMS);
      if (smsSent) sentSMS++;
    }

    // Send Email (per-recipient tracking pixel when APP_URL is set)
    if (student.email) {
      const token = tokenByEmail.get(student.email.trim().toLowerCase()) || '';
      const subject = `📢 New Announcement: ${announcement.title}`;
      const html = emailLayout({
        eyebrow: 'New Announcement',
        title: announcement.title,
        bodyHtml: `<p style="margin:0 0 8px;">${escapeHtml(announcement.summary)}</p>`,
        footerNote: `Category: ${announcement.category} | Audience: ${announcement.audience} | Urgency: ${announcement.urgency}`,
        pixel: pixelImg(token),
      });
      const emailSent = await sendEmail(student.email, subject, html, getLogoAttachment());
      if (emailSent) sentEmail++;
    }
  }

  return { sms: sentSMS, email: sentEmail };
}

export async function notifyNewEvent(event: EventPayload): Promise<{ sms: number; email: number }> {
  const students = await getAllStudents();
  console.log(`[NOTIFY] notifyNewEvent "${event.title}" — ${students.length} student(s) found`);
  if (students.length === 0) {
    console.log('[NOTIFY] No students in database — skipping SMS/email. Add students via Admin → Students tab.');
    return { sms: 0, email: 0 };
  }
  const { logBlast } = await import('./db');
  const tokens = await logBlast(
    'event',
    event.id,
    event.title,
    students.map((s) => s.email).filter((e) => !!e)
  );
  const tokenByEmail = new Map(tokens.map((t) => [t.email, t.token]));
  let sentSMS = 0;
  let sentEmail = 0;

  const when = new Date(event.start_time).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const startTime = new Date(event.start_time).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  const baseSMS = smsTemplate({
    header: 'Campus Event',
    title: event.title,
    lines: [
      `🗓 ${when} · ${startTime}`,
      `📍 ${event.location}`,
      `📎 ${event.department}`,
      `👥 ${event.target_audience}`,
    ],
    linkPath: '/events',
  });

  for (const student of students) {
    // Send SMS
    if (student.phone) {
      const smsSent = await sendSMS(student.phone, baseSMS);
      if (smsSent) sentSMS++;
    }

    // Send Email (per-recipient tracking pixel when APP_URL is set)
    if (student.email) {
      const token = tokenByEmail.get(student.email.trim().toLowerCase()) || '';
      const subject = `📅 New Event: ${event.title}`;
      const when = `${new Date(event.start_time).toLocaleDateString()} - ${new Date(event.end_time).toLocaleDateString()}`;
      const html = emailLayout({
        eyebrow: 'New Event',
        title: event.title,
        bodyHtml:
          `<p style="margin:0 0 8px;"><strong>When:</strong> ${escapeHtml(when)}</p>` +
          `<p style="margin:0 0 8px;"><strong>Where:</strong> ${escapeHtml(event.location)}</p>` +
          `<p style="margin:0;">${escapeHtml(event.description)}</p>`,
        footerNote: `Audience: ${event.target_audience} | Department: ${event.department} | Category: ${event.category}`,
        pixel: pixelImg(token),
      });
      const emailSent = await sendEmail(student.email, subject, html, getLogoAttachment());
      if (emailSent) sentEmail++;
    }
  }

  return { sms: sentSMS, email: sentEmail };
}

export const REMINDER_DEFAULT_MIN_AGE_DAYS = 3;
export const REMINDER_DEFAULT_MAX = 2;

// Re-sends a blast by email to recipients who never opened it, provided the
// blast is old enough and the recipient is under the reminder cap.
// Returns per-outcome counts; never throws for individual send failures.
export async function remindNonOpeners(
  kind: 'announcement' | 'event',
  refId: string,
  minAgeDays: number = REMINDER_DEFAULT_MIN_AGE_DAYS,
  maxReminders: number = REMINDER_DEFAULT_MAX
): Promise<{ reminded: number; skipped: number; total: number }> {
  const { fetchNonOpeners, markReminderSent, fetchAnnouncements, fetchEvents } = await import('./db');
  const pending = await fetchNonOpeners(kind, refId);
  const cutoff = Date.now() - Math.max(0, minAgeDays) * 24 * 60 * 60 * 1000;

  let title = '';
  let bodyHtml = '';
  let footerNote = '';
  if (kind === 'announcement') {
    const found = (await fetchAnnouncements()).find((a) => a.id === refId);
    if (!found) throw new Error('Announcement not found.');
    title = found.title;
    bodyHtml = `<p style="margin:0;">${escapeHtml(found.summary)}</p>`;
    footerNote = `Category: ${found.category} | Audience: ${found.audience}`;
  } else {
    const found = (await fetchEvents()).find((e) => e.id === refId);
    if (!found) throw new Error('Event not found.');
    title = found.title;
    const when = `${new Date(found.start_time).toLocaleDateString()} - ${new Date(found.end_time).toLocaleDateString()}`;
    bodyHtml =
      `<p style="margin:0 0 8px;"><strong>When:</strong> ${escapeHtml(when)}</p>` +
      `<p style="margin:0;"><strong>Where:</strong> ${escapeHtml(found.location)}</p>`;
    footerNote = `Audience: ${found.target_audience} | Department: ${found.department}`;
  }

  let reminded = 0;
  let skipped = 0;
  for (const entry of pending) {
    const oldEnough = new Date(entry.sent_at).getTime() <= cutoff;
    const underCap = entry.reminders_sent < Math.max(0, maxReminders);
    if (!oldEnough || !underCap) {
      skipped++;
      continue;
    }
    const subject = `Reminder: ${title}`;
    const html = emailLayout({
      eyebrow: 'Reminder — Not Opened Yet',
      title,
      bodyHtml:
        `<p style="margin:0 0 8px;">Our records show you have not opened this yet, so here it is again:</p>` +
        bodyHtml +
        `<p style="margin:8px 0 0;font-size:12px;color:#6B6862;">This is reminder ${entry.reminders_sent + 1} of ${maxReminders}.</p>`,
      footerNote,
      pixel: pixelImg(entry.token),
    });
    try {
      const sent = await sendEmail(entry.student_email, subject, html, getLogoAttachment());
      if (sent) {
        await markReminderSent(entry.id);
        reminded++;
      } else {
        skipped++;
      }
    } catch {
      skipped++;
    }
  }
  return { reminded, skipped, total: pending.length };
}