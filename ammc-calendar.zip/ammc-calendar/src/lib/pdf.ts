import { Announcement } from '@/types';

const GREEN: [number, number, number] = [31, 157, 85];
const DARK_GREEN: [number, number, number] = [14, 86, 45];
const INK: [number, number, number] = [38, 36, 34];
const GREY: [number, number, number] = [107, 104, 98];
const LINE: [number, number, number] = [232, 228, 223];

const PAGE_W = 210; // A4 mm
const PAGE_H = 297;
const MARGIN = 16;
const CONTENT_W = PAGE_W - MARGIN * 2;

function formatIssueDate(iso: string): string {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '—';
    return d.toLocaleString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
    });
}

// Strip the light Markdown the announcement editor accepts so the PDF shows
// clean text rather than asterisks and hashes.
function plainText(md: string): string {
    return md
        .replace(/```[\s\S]*?```/g, '')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/\*\*([^*]+)\*\*/g, '$1')
        .replace(/\*([^*]+)\*/g, '$1')
        .replace(/^#{1,6}\s+/gm, '')
        .replace(/^[-*+]\s+/gm, '• ')
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1 ($2)');
}

// Shared PDF renderer: pulls in jsPDF lazily so the bundle only loads when
// someone actually exports.
async function getJsPDF() {
    const { jsPDF } = await import('jspdf');
    return jsPDF;
}

type Doc = {
    doc: import('jspdf').jsPDF;
    y: number;
    logo: string | null;
};

function header(doc: Doc, title: string, subtitle: string): void {
    const { doc: d, logo } = doc;
    doc.y = MARGIN;
    if (logo) {
        try {
            d.addImage(logo, 'PNG', MARGIN, doc.y, 16, 16);
        } catch {
            // Logo is decorative; a missing image must not break the export.
        }
    }
    const left = MARGIN + (logo ? 20 : 0);
    d.setFont('helvetica', 'bold');
    d.setFontSize(9);
    d.setTextColor(...GREY);
    d.text('DR. AURELIO MENDOZA MEMORIAL COLLEGES', left, doc.y + 4);
    d.setFontSize(16);
    d.setTextColor(...INK);
    d.text(title, left, doc.y + 11);
    d.setFont('helvetica', 'normal');
    d.setFontSize(9);
    d.setTextColor(...GREY);
    d.text(subtitle, left, doc.y + 17);

    doc.y += 22;
    d.setDrawColor(...GREEN);
    d.setLineWidth(1);
    d.line(MARGIN, doc.y, PAGE_W - MARGIN, doc.y);
    doc.y += 8;
}

function footer(doc: Doc): void {
    const { doc: d } = doc;
    const pageCount = d.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
        d.setPage(i);
        d.setDrawColor(...LINE);
        d.setLineWidth(0.2);
        d.line(MARGIN, PAGE_H - 14, PAGE_W - MARGIN, PAGE_H - 14);
        d.setFont('helvetica', 'normal');
        d.setFontSize(7.5);
        d.setTextColor(...GREY);
        d.text('Ipil, Zamboanga Sibugay', MARGIN, PAGE_H - 9);
        d.text(`Page ${i} of ${pageCount}`, PAGE_W - MARGIN, PAGE_H - 9, { align: 'right' });
    }
}

function ensureSpace(doc: Doc, needed: number): void {
    const { doc: d } = doc;
    if (doc.y + needed <= PAGE_H - 18) return;
    d.addPage();
    doc.y = MARGIN;
}

function metaRow(doc: Doc, label: string, value: string): void {
    const { doc: d } = doc;
    ensureSpace(doc, 7);
    d.setFont('helvetica', 'bold');
    d.setFontSize(8);
    d.setTextColor(...DARK_GREEN);
    d.text(`${label.toUpperCase()}  `, MARGIN, doc.y);
    const labelW = d.getTextWidth(`${label.toUpperCase()}  `);
    d.setFont('helvetica', 'normal');
    d.setTextColor(...GREY);
    d.text(value.slice(0, 120), MARGIN + labelW, doc.y);
    doc.y += 5.5;
}

// Wraps body text across pages.
function bodyBlock(doc: Doc, text: string): void {
    const { doc: d } = doc;
    d.setFont('helvetica', 'normal');
    d.setFontSize(10);
    d.setTextColor(...INK);
    for (const rawLine of plainText(text).split('\n')) {
        const line = rawLine.trimEnd();
        if (!line.trim()) {
            doc.y += 3;
            continue;
        }
        const wrapped = d.splitTextToSize(line, CONTENT_W) as string[];
        for (const w of wrapped) {
            ensureSpace(doc, 5.5);
            d.text(w, MARGIN, doc.y);
            doc.y += 5.5;
        }
    }
    doc.y += 4;
}

async function loadLogo(): Promise<string | null> {
    try {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const fs = require('fs') as typeof import('fs');
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const path = require('path') as typeof import('path');
        const buf = fs.readFileSync(path.join(process.cwd(), 'public', 'icons', 'icon-192x192.png'));
        return `data:image/png;base64,${buf.toString('base64')}`;
    } catch {
        return null;
    }
}

function sortByIssueDate(list: Announcement[]): Announcement[] {
    return [...list].sort(
        (a, b) => new Date(b.issue_date || b.created_at).getTime() - new Date(a.issue_date || a.created_at).getTime()
    );
}

export async function buildAnnouncementPdf(announcements: Announcement[]): Promise<Uint8Array> {
    const JsPDF = await getJsPDF();
    const doc: Doc = { doc: new JsPDF({ unit: 'mm', format: 'a4' }), y: MARGIN, logo: await loadLogo() };
    const list = sortByIssueDate(announcements.filter((a) => a.is_published));

    header(doc, 'Official Announcements', `All published circulars • ${list.length} document${list.length === 1 ? '' : 's'}`);

    if (list.length === 0) {
        doc.doc.setFont('helvetica', 'normal');
        doc.doc.setFontSize(10);
        doc.doc.setTextColor(...GREY);
        doc.doc.text('No published announcements to export.', MARGIN, doc.y + 6);
    }

    for (const ann of list) {
        ensureSpace(doc, 40);
        // Urgency tag
        const urgencyLabel =
            ann.urgency === 'critical' ? 'CRITICAL ALERT' : ann.urgency === 'important' ? 'IMPORTANT ADVISORY' : 'GENERAL NOTICE';
        const tag = `${ann.category.toUpperCase()}  •  ${urgencyLabel}`;
        doc.doc.setFont('helvetica', 'bold');
        doc.doc.setFontSize(7.5);
        doc.doc.setTextColor(...GREEN);
        doc.doc.text(tag, MARGIN, doc.y);

        doc.y += 7;
        ensureSpace(doc, 12);
        doc.doc.setFont('helvetica', 'bold');
        doc.doc.setFontSize(13);
        doc.doc.setTextColor(...INK);
        const titleLines = doc.doc.splitTextToSize(ann.title, CONTENT_W) as string[];
        for (const line of titleLines) {
            ensureSpace(doc, 7);
            doc.doc.text(line, MARGIN, doc.y);
            doc.y += 7;
        }

        metaRow(doc, 'Issued', formatIssueDate(ann.issue_date || ann.created_at));
        metaRow(doc, 'Department', ann.department);
        metaRow(doc, 'Audience', ann.audience);
        metaRow(doc, 'Author', ann.author_name);

        doc.y += 2;
        ensureSpace(doc, 20);
        doc.doc.setFont('helvetica', 'bold');
        doc.doc.setFontSize(9);
        doc.doc.setTextColor(...DARK_GREEN);
        doc.doc.text('SYNOPSIS', MARGIN, doc.y);
        doc.y += 6;
        doc.doc.setFont('helvetica', 'normal');
        doc.doc.setFontSize(9.5);
        doc.doc.setTextColor(...INK);
        for (const w of doc.doc.splitTextToSize(plainText(ann.summary), CONTENT_W) as string[]) {
            ensureSpace(doc, 5);
            doc.doc.text(w, MARGIN, doc.y);
            doc.y += 5;
        }

        doc.y += 3;
        ensureSpace(doc, 24);
        doc.doc.setFont('helvetica', 'bold');
        doc.doc.setFontSize(9);
        doc.doc.setTextColor(...DARK_GREEN);
        doc.doc.text('DETAILS', MARGIN, doc.y);
        doc.y += 6;
        bodyBlock(doc, ann.content);

        if (ann.attachments && ann.attachments.length > 0) {
            ensureSpace(doc, 16);
            doc.doc.setFont('helvetica', 'bold');
            doc.doc.setFontSize(8);
            doc.doc.setTextColor(...DARK_GREEN);
            doc.doc.text('ATTACHMENTS', MARGIN, doc.y);
            doc.y += 5;
            doc.doc.setFont('helvetica', 'normal');
            doc.doc.setFontSize(8.5);
            doc.doc.setTextColor(...GREY);
            for (const file of ann.attachments) {
                ensureSpace(doc, 5);
                doc.doc.text(`• ${file.name}${file.size ? ` (${file.size})` : ''}`, MARGIN, doc.y);
                doc.y += 5;
            }
        }

        // Divider between entries
        ensureSpace(doc, 12);
        doc.doc.setDrawColor(...LINE);
        doc.doc.setLineWidth(0.3);
        doc.doc.line(MARGIN, doc.y, PAGE_W - MARGIN, doc.y);
        doc.y += 10;
    }

    footer(doc);
    return new Uint8Array(doc.doc.output('arraybuffer') as ArrayBuffer);
}

export async function buildSingleAnnouncementPdf(announcement: Announcement): Promise<Uint8Array> {
    const JsPDF = await getJsPDF();
    const doc: Doc = { doc: new JsPDF({ unit: 'mm', format: 'a4' }), y: MARGIN, logo: await loadLogo() };

    header(
        doc,
        'Official Circular',
        `${announcement.department} • ${announcement.audience}`
    );

    const urgencyLabel =
        announcement.urgency === 'critical'
            ? 'CRITICAL ALERT'
            : announcement.urgency === 'important'
                ? 'IMPORTANT ADVISORY'
                : 'GENERAL NOTICE';
    doc.doc.setFont('helvetica', 'bold');
    doc.doc.setFontSize(7.5);
    doc.doc.setTextColor(...GREEN);
    doc.doc.text(`${announcement.category.toUpperCase()}  •  ${urgencyLabel}`, MARGIN, doc.y);

    doc.y += 8;
    doc.doc.setFont('helvetica', 'bold');
    doc.doc.setFontSize(17);
    doc.doc.setTextColor(...INK);
    for (const line of doc.doc.splitTextToSize(announcement.title, CONTENT_W) as string[]) {
        ensureSpace(doc, 9);
        doc.doc.text(line, MARGIN, doc.y);
        doc.y += 9;
    }

    doc.y += 2;
    metaRow(doc, 'Issued', formatIssueDate(announcement.issue_date || announcement.created_at));
    metaRow(doc, 'Author', announcement.author_name);

    doc.y += 4;
    ensureSpace(doc, 30);
    doc.doc.setFont('helvetica', 'bold');
    doc.doc.setFontSize(10);
    doc.doc.setTextColor(...DARK_GREEN);
    doc.doc.text('SYNOPSIS', MARGIN, doc.y);
    doc.y += 7;
    doc.doc.setFont('helvetica', 'normal');
    doc.doc.setFontSize(10);
    doc.doc.setTextColor(...INK);
    for (const w of doc.doc.splitTextToSize(plainText(announcement.summary), CONTENT_W) as string[]) {
        ensureSpace(doc, 5.5);
        doc.doc.text(w, MARGIN, doc.y);
        doc.y += 5.5;
    }

    doc.y += 4;
    ensureSpace(doc, 30);
    bodyBlock(doc, announcement.content);

    if (announcement.attachments && announcement.attachments.length > 0) {
        ensureSpace(doc, 18);
        doc.doc.setFont('helvetica', 'bold');
        doc.doc.setFontSize(9);
        doc.doc.setTextColor(...DARK_GREEN);
        doc.doc.text('ATTACHMENTS', MARGIN, doc.y);
        doc.y += 6;
        doc.doc.setFont('helvetica', 'normal');
        doc.doc.setFontSize(9);
        doc.doc.setTextColor(...GREY);
        for (const file of announcement.attachments) {
            ensureSpace(doc, 5.5);
            doc.doc.text(`• ${file.name}${file.size ? ` (${file.size})` : ''}`, MARGIN, doc.y);
            doc.y += 5.5;
        }
    }

    footer(doc);
    return new Uint8Array(doc.doc.output('arraybuffer') as ArrayBuffer);
}