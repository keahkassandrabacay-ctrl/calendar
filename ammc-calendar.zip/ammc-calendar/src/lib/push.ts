import webpush from 'web-push';
import { fetchSubscriptionsWithReadState, getUnreadCount, deletePushSubscription, type PushSubscriptionRow } from './db';

const VAPID_SUBJECT = process.env.VAPID_SUBJECT?.trim();
const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY?.trim();
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY?.trim();

let configured = false;

function isConfigured(): boolean {
    if (!VAPID_SUBJECT || !VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) {
        return false;
    }
    if (!configured) {
        webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
        configured = true;
    }
    return true;
}

export function pushConfigured(): boolean {
    return isConfigured();
}

export interface PushPayload {
    title: string;
    body: string;
    url: string;
    tag: string;
}

interface SendResult {
    sent: number;
    failed: number;
    pruned: number;
}

function toSubscription(row: PushSubscriptionRow) {
    return {
        endpoint: row.endpoint,
        keys: { p256dh: row.p256dh, auth: row.auth },
    };
}

// Push services answer 404/410 once an endpoint is gone for good. Those are the
// only statuses we drop the row for; everything else (rate limits, offline push
// service) is transient and must stay subscribed.
function isGone(statusCode?: number): boolean {
    return statusCode === 404 || statusCode === 410;
}

// Fans a new-announcement push out to every registered device. Each device gets
// its own unread count, because "read" is tracked per device rather than globally.
export async function broadcastAnnouncement(payload: PushPayload): Promise<SendResult> {
    const result: SendResult = { sent: 0, failed: 0, pruned: 0 };
    if (!isConfigured()) {
        console.warn('[PUSH] Skipped: VAPID keys not configured.');
        return result;
    }

    let rows: PushSubscriptionRow[];
    try {
        rows = await fetchSubscriptionsWithReadState();
    } catch (err) {
        console.error('[PUSH] Could not load subscriptions:', err);
        return result;
    }
    if (rows.length === 0) return result;

    // One unread lookup per distinct device, not per subscription.
    const counts = new Map<string, number>();
    for (const deviceId of new Set(rows.map((r) => r.device_id))) {
        try {
            counts.set(deviceId, await getUnreadCount(deviceId));
        } catch (err) {
            console.error(`[PUSH] Unread count failed for device ${deviceId}:`, err);
            counts.set(deviceId, 1);
        }
    }

    await Promise.all(
        rows.map(async (row) => {
            const count = counts.get(row.device_id) ?? 0;
            try {
                await webpush.sendNotification(
                    toSubscription(row),
                    JSON.stringify({ ...payload, count, v: 1 }),
                    { TTL: 60 * 60 * 24, urgency: 'high' }
                );
                result.sent += 1;
            } catch (err) {
                const statusCode = (err as { statusCode?: number }).statusCode;
                if (isGone(statusCode)) {
                    try {
                        await deletePushSubscription(row.endpoint);
                        result.pruned += 1;
                    } catch (delErr) {
                        console.error('[PUSH] Failed to prune subscription:', delErr);
                    }
                } else {
                    result.failed += 1;
                    console.error(`[PUSH] Send failed (${statusCode ?? 'no status'}):`, err);
                }
            }
        })
    );

    return result;
}