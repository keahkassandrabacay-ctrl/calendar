-- Dr. Aurelio Mendoza Memorial Colleges (AMMC) Database Schema
-- Compatible with MySQL in XAMPP (phpMyAdmin / MariaDB)

CREATE DATABASE IF NOT EXISTS `ammc` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `ammc`;

-- Admins Table
CREATE TABLE IF NOT EXISTS `admins` (
 `id` VARCHAR(64) PRIMARY KEY,
 `email` VARCHAR(191) NOT NULL UNIQUE,
 `password_hash` VARCHAR(255) NOT NULL,
 `name` VARCHAR(191) NOT NULL,
 `role` VARCHAR(64) NOT NULL DEFAULT 'Super Admin',
 `department` VARCHAR(128) NULL,
 `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Announcements Table
CREATE TABLE IF NOT EXISTS `announcements` (
 `id` VARCHAR(64) PRIMARY KEY,
 `title` VARCHAR(255) NOT NULL,
 `slug` VARCHAR(255) NOT NULL,
 `summary` TEXT NOT NULL,
 `content` LONGTEXT NOT NULL,
 `category` VARCHAR(64) NOT NULL,
 `department` VARCHAR(128) NOT NULL,
 `audience` VARCHAR(64) NOT NULL DEFAULT 'All Campus',
 `urgency` VARCHAR(32) NOT NULL DEFAULT 'normal',
 `is_pinned` BOOLEAN NOT NULL DEFAULT FALSE,
 `is_published` BOOLEAN NOT NULL DEFAULT TRUE,
 `views` INT NOT NULL DEFAULT 0,
 `helpful_reactions` INT NOT NULL DEFAULT 0,
 `heart_reactions` INT NOT NULL DEFAULT 0,
 `celebrate_reactions` INT NOT NULL DEFAULT 0,
 `attachments_json` LONGTEXT NULL,
 `author_name` VARCHAR(128) NOT NULL DEFAULT 'AMMC Administration',
 `issue_date` DATETIME NULL,
 `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
 `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Events Table
CREATE TABLE IF NOT EXISTS `events` (
 `id` VARCHAR(64) PRIMARY KEY,
 `title` VARCHAR(255) NOT NULL,
 `description` LONGTEXT NOT NULL,
 `location` VARCHAR(255) NOT NULL,
 `category` VARCHAR(64) NOT NULL,
 `start_time` DATETIME NOT NULL,
 `end_time` DATETIME NOT NULL,
 `capacity` INT NOT NULL DEFAULT 0,
 `rsvp_count` INT NOT NULL DEFAULT 0,
 `is_featured` BOOLEAN NOT NULL DEFAULT FALSE,
 `organizer` VARCHAR(191) NOT NULL,
 `target_audience` VARCHAR(64) NOT NULL DEFAULT 'All Campus',
 `department` VARCHAR(128) NOT NULL DEFAULT 'All Departments',
 `banner_color` VARCHAR(32) NOT NULL DEFAULT '#5A5A40',
 `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Students Table (required by src/lib/db.ts fetchStudents/createStudent)
CREATE TABLE IF NOT EXISTS `students` (
 `student_id` VARCHAR(64) PRIMARY KEY,
 `fname` VARCHAR(191) NOT NULL,
 `lname` VARCHAR(191) NOT NULL,
 `mname` VARCHAR(191) NULL,
 `course` VARCHAR(128) NOT NULL,
 `year` INT NOT NULL,
 `phone` VARCHAR(32) NOT NULL,
 `email` VARCHAR(191) NOT NULL UNIQUE,
 `status` ENUM('pending','approved','declined') NOT NULL DEFAULT 'approved',
 `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Managed vocabulary: announcement categories (admin-editable)
CREATE TABLE IF NOT EXISTS `categories` (
 `id` VARCHAR(64) PRIMARY KEY,
 `name` VARCHAR(64) NOT NULL UNIQUE,
 `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `categories` (`id`, `name`) VALUES
 ('cat-academic', 'Academic'),
 ('cat-administrative', 'Administrative'),
 ('cat-student-affairs', 'Student Affairs'),
 ('cat-sports', 'Sports & Athletics'),
 ('cat-admissions', 'Admissions & Enrollment'),
 ('cat-scholarships', 'Scholarships & Grants'),
 ('cat-advisory', 'Campus Advisory');

-- Managed vocabulary: departments (shared by announcements & events)
CREATE TABLE IF NOT EXISTS `departments` (
 `id` VARCHAR(64) PRIMARY KEY,
 `name` VARCHAR(128) NOT NULL UNIQUE,
 `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `departments` (`id`, `name`) VALUES
 ('dept-all', 'All Departments'),
 ('dept-president', 'Office of the President'),
 ('dept-registrar', 'Office of the Registrar'),
 ('dept-nursing', 'College of Nursing'),
 ('dept-educ', 'College of Education'),
 ('dept-cba', 'College of Business Administration'),
 ('dept-cas', 'College of Arts & Sciences'),
 ('dept-crim', 'College of Criminology'),
 ('dept-it', 'College of Information Technology'),
 ('dept-shs', 'Basic Education & Senior High'),
 ('dept-ssc', 'Supreme Student Council'),
 ('dept-athletics', 'Athletics Department');

-- Notification engagement log: one row per recipient per blast.
-- Powers open tracking (pixel) and non-opener reminders.
CREATE TABLE IF NOT EXISTS `notification_logs` (
  `id` VARCHAR(64) PRIMARY KEY,
  `kind` ENUM('announcement','event') NOT NULL,
  `ref_id` VARCHAR(64) NOT NULL,
  `ref_title` VARCHAR(255) NOT NULL DEFAULT '',
  `student_email` VARCHAR(191) NOT NULL,
  `token` VARCHAR(64) NOT NULL UNIQUE,
  `sent_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `opened_at` DATETIME NULL,
  `reminders_sent` INT NOT NULL DEFAULT 0,
  `last_reminder_at` DATETIME NULL,
  INDEX `idx_blast` (`kind`, `ref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Web Push endpoints registered by installed PWAs (see src/lib/push.ts).
-- `device_id` is an anonymous per-browser id minted in localStorage; it is not
-- an auth credential, only a key for per-device unread state.
CREATE TABLE IF NOT EXISTS `push_subscriptions` (
  `id` VARCHAR(64) PRIMARY KEY,
  `endpoint` VARCHAR(512) NOT NULL UNIQUE,
  `p256dh` VARCHAR(255) NOT NULL,
  `auth` VARCHAR(255) NOT NULL,
  `device_id` VARCHAR(64) NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_device` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Per-device "last read" marker powering the true unread badge count.
CREATE TABLE IF NOT EXISTS `announcement_reads` (
  `device_id` VARCHAR(64) PRIMARY KEY,
  `last_read_at` DATETIME NOT NULL,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


