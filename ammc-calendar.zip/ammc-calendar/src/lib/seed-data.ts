import { Announcement, SchoolEvent, AdminUser } from '@/types';

export const INITIAL_ADMINS: AdminUser[] = [
 {
 id: 'admin-1',
 email: 'admin@ammc.edu.ph',
 name: 'Dr. Aurelio Mendoza Admin',
 role: 'Super Admin',
 department: 'DSA',
 },
 {
 id: 'admin-2',
 email: 'registrar@ammc.edu.ph',
 name: 'College Registrar',
 role: 'Dean / Dept Head',
 department: 'Office of the Registrar',
 },
 {
 id: 'admin-3',
 email: 'studentaffairs@ammc.edu.ph',
 name: 'Office of Student Affairs',
 role: 'Student Affairs Officer',
 department: 'Supreme Student Council',
 },
];

export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
 {
 id: 'ann-1',
 title: 'Official Advisory: Schedule of 1st Semester Midterm Examinations A.Y. 2026-2027',
 slug: 'schedule-1st-semester-midterm-examinations-2026',
 summary: 'The Office of the Vice President for Academic Affairs releases the comprehensive schedule and exam room assignments for all collegiate departments.',
 content: `Please be advised that the Midterm Examination for the First Semester of Academic Year 2026-2027 is scheduled from September 1 to September 5, 2026.

All students are reminded of the following institutional guidelines:
1. **Examination Permits**: Please secure your verified Midterm Examination Permits from the Accounting and Registrar's office prior to Friday, August 28.
2. **Proper Attire**: Strict adherence to the institutional uniform policy and identification card (ID) validation is required at all testing venues.
3. **Examination Venues**: Special laboratory and clinical practicum examinations for the College of Nursing and College of Information Technology will take place in their designated specialized suites.
4. **Permit Clearance**: Working students with approved deferred payment schemes must present their promissory approvals endorsed by the Dean's Office.

May all AMMC scholars prepare diligently and uphold the highest standards of academic integrity.`,
 category: 'Academic',
 department: 'Office of the Registrar',
 audience: 'College Students',
 urgency: 'critical',
 is_pinned: true,
 is_published: true,
 views: 1420,
 reactions: {
 helpful: 89,
 heart: 42,
 celebrate: 18,
 },
 attachments: [
 {
 name: 'AMMC_Midterm_Exam_Room_Assignments_2026.pdf',
 size: '1.4 MB',
 url: '#',
 },
 {
 name: 'Guidelines_Academic_Integrity_Policy.pdf',
 size: '420 KB',
 url: '#',
 },
 ],
 author_name: 'Office of Academic Affairs',
 created_at: '2026-08-18T08:00:00.000Z',
 updated_at: '2026-08-18T08:00:00.000Z',
 },
 {
 id: 'ann-2',
 title: 'AMMC Celebrates 100% Passing Rate in August 2026 Nurse Licensure Examination (NLE)',
 slug: 'ammc-100-percent-passing-rate-nle-august-2026',
 summary: 'Dr. Aurelio Mendoza Memorial Colleges proudly congratulates the College of Nursing Class of 2026 for achieving a pristine 100% passing record on their first-time takers.',
 content: `With immense pride and honor, the Board of Trustees, Administration, Faculty, and Student Body of Dr. Aurelio Mendoza Memorial Colleges extend their heartfelt congratulations to our newest Registered Nurses!

Our institution has once again demonstrated academic excellence and unyielding dedication to healthcare education by garnering a **100% Institutional Passing Rate** for first-time examinees in the August 2026 Nurse Licensure Examination administered by the Professional Regulation Commission (PRC).

Special commendation to the Dean of Nursing, clinical instructors, and clinical preceptors for their tireless mentorship. A formal Thanksgiving Mass and Testimonial Dinner in honor of the board passers will be hosted at the AMMC Grand Gymnasium on September 12, 2026.`,
 category: 'Student Affairs',
 department: 'College of Nursing',
 audience: 'All Campus',
 urgency: 'important',
 is_pinned: true,
 is_published: true,
 views: 2890,
 reactions: {
 helpful: 120,
 heart: 384,
 celebrate: 512,
 },
 attachments: [
 {
 name: 'Official_PRC_Passing_Roll_AMMC.pdf',
 size: '850 KB',
 url: '#',
 },
 ],
 author_name: 'College of Nursing Dean\'s Office',
 created_at: '2026-08-16T10:30:00.000Z',
 updated_at: '2026-08-16T10:30:00.000Z',
 },
 {
 id: 'ann-3',
 title: 'Call for Applications: Academic Excellence and Foundation Scholarship Grants AY 2026-2027',
 slug: 'scholarship-grants-application-ay-2026-2027',
 summary: 'Applications are now open for academic merit scholarships, athletic tuition discounts, and sibling assistance grants through the Student Welfare Office.',
 content: `The Student Welfare and Financial Assistance Center announces that applications for institutional scholarship programs for the 1st Semester are now officially open.

**Available Grant Categories:**
- **Presidential Academic Scholar**: 100% Tuition & Miscellaneous Fee Waiver for General Weighted Average (GWA) of 1.25 or better.
- **Dean’s Honor Grant**: 50% Tuition Discount for GWA of 1.45 or better.
- **Varsity & Cultural Arts Guild Scholarship**: Full and Partial grants for qualified campus athletes and performing artists.
- **Family / Sibling Loyalty Discount**: Applicable for households with two or more concurrently enrolled siblings.

Application forms can be downloaded below or obtained physically at Window 4 of the Registrar & Student Services Hall. Deadline of submission with supporting certifications is September 8, 2026.`,
 category: 'Scholarships & Grants',
 department: 'Office of the Registrar',
 audience: 'College Students',
 urgency: 'important',
 is_published: true,
 is_pinned: false,
 views: 940,
 reactions: {
 helpful: 145,
 heart: 67,
 celebrate: 22,
 },
 attachments: [
 {
 name: 'AMMC_Scholarship_Application_Form_2026.pdf',
 size: '310 KB',
 url: '#',
 },
 ],
 author_name: 'Scholarships & Financial Aid Office',
 created_at: '2026-08-14T09:15:00.000Z',
 updated_at: '2026-08-14T09:15:00.000Z',
 },
 {
 id: 'ann-4',
 title: 'Annual College Intramurals & Cultural Festival 2026: "Igniting Unity, Excellence, and Legacy"',
 slug: 'annual-college-intramurals-cultural-festival-2026',
 summary: 'The Supreme Student Council unveils the event guidelines, sports schedules, and collegiate teams for the most anticipated campus week of the year.',
 content: `Get ready, Mendoza Scholars! The AMMC Supreme Student Council (SSC) in partnership with the Athletics and Cultural Affairs Department proudly presents the **Annual Intramurals & Cultural Fest 2026**, happening from September 21 to September 25, 2026!

**Participating Collegiate Factions:**
- 🔴 **Red Phoenix** - College of Nursing & Allied Health
- 🔵 **Blue Titans** - College of Business Administration & Accountancy
- 🟢 **Green Falcons** - College of Education & Arts and Sciences
- 🟡 **Golden Pythons** - College of Criminology
- 🟣 **Violet Cybers** - College of Information Technology & Engineering
- ⚪ **Silver Sentinels** - Senior High School Department

Registration for cheer dance, basketball, volleyball, badminton, esports (MLBB / Valorant), debate cup, and the Mr. & Ms. AMMC 2026 Pageant is now open with your respective college governors.`,
 category: 'Sports & Athletics',
 department: 'Supreme Student Council',
 audience: 'All Campus',
 urgency: 'normal',
 is_published: true,
 is_pinned: false,
 views: 1830,
 reactions: {
 helpful: 78,
 heart: 215,
 celebrate: 402,
 },
 author_name: 'Supreme Student Council Executive Board',
 created_at: '2026-08-12T14:00:00.000Z',
 updated_at: '2026-08-12T14:00:00.000Z',
 },
 {
 id: 'ann-5',
 title: 'Campus Safety & Health Advisory: Enhanced Hygiene Protocol and Free Student Health Screening',
 slug: 'campus-health-safety-screening-advisory',
 summary: 'The AMMC University Clinic will conduct free routine health appraisals, dental check-ups, and booster immunization clinics starting this week.',
 content: `In our ongoing commitment to maintain a safe, wholesome, and conducive learning environment for every student and staff member, the AMMC Health and Medical Services Clinic announces the schedule for the annual Routine Physical and Dental Examination.

- **Senior High School**: Aug 24 - Aug 26, 2026
- **Colleges of Nursing & Criminology**: Aug 27 - Aug 29, 2026
- **Colleges of CBA, Educ, and IT**: Aug 31 - Sept 2, 2026

Please bring your valid student ID and vaccination card. Free multivitamins and initial medical consults are available at the clinic from 8:00 AM to 5:00 PM daily.`,
 category: 'Campus Advisory',
 department: 'Office of the President',
 audience: 'All Campus',
 urgency: 'normal',
 is_published: true,
 is_pinned: false,
 views: 620,
 reactions: {
 helpful: 92,
 heart: 35,
 celebrate: 8,
 },
 author_name: 'Campus Health & Medical Services',
 created_at: '2026-08-10T11:20:00.000Z',
 updated_at: '2026-08-10T11:20:00.000Z',
 },
 {
 id: 'ann-6',
 title: 'Advisory on Online Learning Management System (LMS) Server Maintenance',
 slug: 'lms-server-scheduled-maintenance-notice',
 summary: 'The College IT and MIS Department will perform scheduled infrastructure upgrades this Saturday evening from 10:00 PM to 4:00 AM.',
 content: `The Management Information Systems (MIS) Office will be undertaking scheduled server maintenance and storage performance enhancements for the AMMC Canvas and Systems.

During this window, online quizzes, submissions, and grade inquiry modules will be temporarily inaccessible. Faculty members are advised to set assignment deadlines outside this scheduled maintenance timeframe. We apologize for any temporary inconvenience as we upgrade our campus digital infrastructure.`,
 category: 'Administrative',
 department: 'College of Information Technology',
 audience: 'Faculty & Staff',
 urgency: 'normal',
 is_published: true,
 is_pinned: false,
 views: 510,
 reactions: {
 helpful: 64,
 heart: 12,
 celebrate: 4,
 },
 author_name: 'MIS & Digital Infrastructure Unit',
 created_at: '2026-08-08T16:45:00.000Z',
 updated_at: '2026-08-08T16:45:00.000Z',
 }
];

export const INITIAL_EVENTS: SchoolEvent[] = [
 {
 id: 'evt-1',
 title: 'General Student Convocation & Leadership Assembly 2026',
 description: 'Annual gathering of all collegiate student leaders, class officers, and campus organization representatives with the College President and Academic Deans.',
 location: 'AMMC Main Auditorium & Performing Arts Hall',
 category: 'Campus Life & Culture',
 start_time: '2026-08-25T09:00:00.000Z',
 end_time: '2026-08-25T12:30:00.000Z',
 capacity: 450,
 rsvp_count: 312,
 is_featured: true,
 organizer: 'Office of Student Affairs & SSC',
 target_audience: 'College Students',
 department: 'Supreme Student Council',
 banner_color: '#1F9D55',
 created_at: '2026-08-15T00:00:00.000Z',
 },
 {
 id: 'evt-2',
 title: 'Midterm Examination Week (All Collegiate Programs)',
 description: 'Institutional examination period for 1st Semester A.Y. 2026-2027. Students must present signed examination permits at their designated testing rooms.',
 location: 'All Campus Academic Buildings & Science Halls',
 category: 'Examinations',
 start_time: '2026-09-01T08:00:00.000Z',
 end_time: '2026-09-05T17:00:00.000Z',
 capacity: 2500,
 rsvp_count: 0,
 is_featured: true,
 organizer: 'Office of the Academic Registrar',
 target_audience: 'College Students',
 department: 'Office of the Registrar',
 banner_color: '#B56E4D',
 created_at: '2026-08-15T00:00:00.000Z',
 },
 {
 id: 'evt-3',
 title: 'International Cybersecurity & AI Innovation Summit 2026',
 description: 'A cutting-edge symposium featuring guest keynote speakers from the tech industry discussing Artificial Intelligence, Cloud Security, and Modern Web Architecture.',
 location: 'Mendoza Multipurpose Hall & Hybrid Zoom Livestream',
 category: 'Seminars & Workshops',
 start_time: '2026-08-28T13:30:00.000Z',
 end_time: '2026-08-28T17:30:00.000Z',
 capacity: 200,
 rsvp_count: 148,
 is_featured: true,
 organizer: 'College of Information Technology & Computer Society',
 target_audience: 'All Campus',
 department: 'College of Information Technology',
 banner_color: '#5A6B7C',
 created_at: '2026-08-14T00:00:00.000Z',
 },
 {
 id: 'evt-4',
 title: 'Nursing Testimonial Dinner & Capping/Pinning Ceremony',
 description: 'Honoring the board passers of the August 2026 Nurse Licensure Examination and formal investiture of Level II Nursing student clinical badges.',
 location: 'AMMC Grand Convention Pavilion',
 category: 'Campus Life & Culture',
 start_time: '2026-09-12T16:00:00.000Z',
 end_time: '2026-09-12T20:30:00.000Z',
 capacity: 350,
 rsvp_count: 280,
 is_featured: true,
 organizer: 'College of Nursing & Nightingale Society',
 target_audience: 'College Students',
 department: 'College of Nursing',
 banner_color: '#5B7B68',
 created_at: '2026-08-16T00:00:00.000Z',
 },
 {
 id: 'evt-5',
 title: 'AMMC Intramural Games 2026: Opening Ceremony & Torch Relay',
 description: 'Grand opening parade, lighting of the institutional urn of peace, inter-college cheer dance competition, and opening basketball exhibition matches.',
 location: 'AMMC Sports Complex & Athletics Stadium',
 category: 'Athletics & Sports',
 start_time: '2026-09-21T07:30:00.000Z',
 end_time: '2026-09-21T18:00:00.000Z',
 capacity: 1200,
 rsvp_count: 650,
 is_featured: true,
 organizer: 'Athletics Department & SSC',
 target_audience: 'All Campus',
 department: 'Athletics Department',
 banner_color: '#C47C5D',
 created_at: '2026-08-12T00:00:00.000Z',
 },
 {
 id: 'evt-6',
 title: 'Faculty Research Colloquium & Curriculum Development Workshop',
 description: 'Semi-annual academic workshop for faculty members across all departments on scholarly publication, pedagogical innovation, and institutional assessment.',
 location: 'Faculty Development Lounge, 3rd Floor Admin Building',
 category: 'Seminars & Workshops',
 start_time: '2026-09-18T08:30:00.000Z',
 end_time: '2026-09-18T16:00:00.000Z',
 capacity: 120,
 rsvp_count: 85,
 is_featured: false,
 organizer: 'Research and Extension Services Division',
 target_audience: 'Faculty & Staff',
 department: 'Office of the President',
 banner_color: '#8C7D6B',
 created_at: '2026-08-10T00:00:00.000Z',
 },
 {
 id: 'evt-7',
 title: 'National Heroes Day (Non-Working Institutional Holiday)',
 description: 'Suspension of regular collegiate classes and administrative office operations in nationwide commemoration of Philippine National Heroes Day.',
 location: 'Nationwide & Institutional Observance',
 category: 'Holidays & Observances',
 start_time: '2026-08-31T00:00:00.000Z',
 end_time: '2026-08-31T23:59:59.000Z',
 capacity: 0,
 rsvp_count: 0,
 is_featured: false,
 organizer: 'Office of the President',
 target_audience: 'All Campus',
 department: 'Office of the President',
 banner_color: '#8C7D6B',
 created_at: '2026-08-01T00:00:00.000Z',
 },
 {
 id: 'evt-8',
 title: 'Executive Academic Council & Collegiate Deans Monthly Assembly',
 description: 'Deliberation of midterm curriculum adjustments, clinical hospital affiliations, board review intensives, and institutional quality assurance accreditations.',
 location: 'Board of Trustees Executive Room, 3rd Floor Administration Building',
 category: 'Administrative & Faculty Meetings',
 start_time: '2026-08-26T13:30:00.000Z',
 end_time: '2026-08-26T16:30:00.000Z',
 capacity: 40,
 rsvp_count: 32,
 is_featured: true,
 organizer: 'Office of the Vice President for Academic Affairs',
 target_audience: 'Faculty & Staff',
 department: 'Office of the President',
 banner_color: '#1F9D55',
 created_at: '2026-08-16T00:00:00.000Z',
 },
 {
 id: 'evt-9',
 title: 'Supreme Student Council & Recognized Organizations Coordination Meeting',
 description: 'Quarterly alignment on student welfare programs, intramural sports bracket logistics, organization budget proposals, and university week event security.',
 location: 'Student Affairs Hall, Student Center Room 204',
 category: 'Administrative & Faculty Meetings',
 start_time: '2026-08-29T10:00:00.000Z',
 end_time: '2026-08-29T12:30:00.000Z',
 capacity: 75,
 rsvp_count: 58,
 is_featured: false,
 organizer: 'Office of Student Affairs & SSC',
 target_audience: 'College Students',
 department: 'Supreme Student Council',
 banner_color: '#5B7B68',
 created_at: '2026-08-15T00:00:00.000Z',
 },
 {
 id: 'evt-10',
 title: 'Ninoy Aquino Day (Special Non-Working National Holiday)',
 description: 'Official non-working holiday across all collegiate and basic education departments in accordance with Philippine Presidential Proclamation.',
 location: 'Nationwide Observance',
 category: 'Holidays & Observances',
 start_time: '2026-08-21T00:00:00.000Z',
 end_time: '2026-08-21T23:59:59.000Z',
 capacity: 0,
 rsvp_count: 0,
 is_featured: false,
 organizer: 'Office of the President',
 target_audience: 'All Campus',
 department: 'Office of the President',
 banner_color: '#B56E4D',
 created_at: '2026-08-01T00:00:00.000Z',
 },
 {
 id: 'evt-11',
 title: 'AMMC Institutional Founder’s Day & Charter Celebration Holiday',
 description: 'Honoring the legacy of Dr. Aurelio Mendoza with institutional thanksgiving mass, floral offering, founding anniversary ceremonies, and academic recess.',
 location: 'AMMC Grand Campus Quadrangle',
 category: 'Holidays & Observances',
 start_time: '2026-10-15T00:00:00.000Z',
 end_time: '2026-10-15T23:59:59.000Z',
 capacity: 0,
 rsvp_count: 0,
 is_featured: true,
 organizer: 'Office of the President & Board of Trustees',
 target_audience: 'All Campus',
 department: 'Office of the President',
 banner_color: '#1F9D55',
 created_at: '2026-08-01T00:00:00.000Z',
 }
];


