import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import {
  fetchTaxonomy,
  createTaxonomyEntry,
  renameTaxonomyEntry,
  deleteTaxonomyEntry,
  taxonomyUsage,
} from '@/lib/db';
import { verifyAdminToken } from '@/lib/auth';

type Table = 'categories' | 'departments';

async function requireAdmin(request: Request) {
  const cookieStore = await cookies();
  const token =
    cookieStore.get('ammc_admin_token')?.value ||
    request.headers.get('Authorization')?.replace('Bearer ', '');
  const user = token ? verifyAdminToken(token) : null;
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized. Admin credentials required.' }, { status: 401 });
  }
  return null;
}

export function taxonomyHandlers(table: Table, entryLabel: string) {
  const key = table === 'categories' ? 'categories' : 'departments';

  async function GET() {
    try {
      const entries = await fetchTaxonomy(table);
      const withUsage = await Promise.all(
        entries.map(async (e) => ({ ...e, usage: await taxonomyUsage(table, e.name) }))
      );
      return NextResponse.json({ [key]: withUsage });
    } catch (error) {
      console.error(`Error fetching ${key}:`, error);
      return NextResponse.json({ error: `Failed to fetch ${key}.` }, { status: 500 });
    }
  }

  async function POST(request: Request) {
    const denied = await requireAdmin(request);
    if (denied) return denied;
    try {
      const body = await request.json();
      const entry = await createTaxonomyEntry(table, String(body?.name ?? ''));
      return NextResponse.json({ success: true, entry }, { status: 201 });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Failed to create entry.';
      const status = msg === 'Name is required.' || msg.endsWith('already exists.') ? 400 : 500;
      return NextResponse.json({ error: msg }, { status });
    }
  }

  async function PATCH(request: Request) {
    const denied = await requireAdmin(request);
    if (denied) return denied;
    try {
      const body = await request.json();
      const { id, name } = body ?? {};
      if (!id || !name) {
        return NextResponse.json({ error: `${entryLabel} ID and new name are required.` }, { status: 400 });
      }
      const entry = await renameTaxonomyEntry(table, String(id), String(name));
      return NextResponse.json({ success: true, entry });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Failed to rename entry.';
      const status =
        msg === 'Entry not found.' ? 404 : msg.endsWith('already exists.') ? 400 : 500;
      return NextResponse.json({ error: msg }, { status });
    }
  }

  async function DELETE(request: Request) {
    const denied = await requireAdmin(request);
    if (denied) return denied;
    try {
      const { searchParams } = new URL(request.url);
      const id = searchParams.get('id');
      if (!id) {
        return NextResponse.json({ error: `${entryLabel} ID is required.` }, { status: 400 });
      }
      await deleteTaxonomyEntry(table, id);
      return NextResponse.json({ success: true });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Failed to delete entry.';
      const status = msg === 'Entry not found.' ? 404 : msg.includes('still used') ? 400 : 500;
      return NextResponse.json({ error: msg }, { status });
    }
  }

  return { GET, POST, PATCH, DELETE };
}
