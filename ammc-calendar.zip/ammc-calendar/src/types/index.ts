export type UrgencyLevel = 'normal' | 'important' | 'critical';

// Default categories, seeded into the managed `categories` table.
export type AnnouncementCategory =
  | 'Academic'
  | 'Administrative'
  | 'Student Affairs'
  | 'Sports & Athletics'
  | 'Admissions & Enrollment'
  | 'Scholarships & Grants'
  | 'Campus Advisory';

export const DEFAULT_ANNOUNCEMENT_CATEGORIES: AnnouncementCategory[] = [
  'Academic',
  'Administrative',
  'Student Affairs',
  'Sports & Athletics',
  'Admissions & Enrollment',
  'Scholarships & Grants',
  'Campus Advisory',
];

export type TargetAudience = 
  | 'All Campus'
  | 'College Students'
  | 'Senior High School'
  | 'Faculty & Staff'
  | 'Alumni & Community'
  | 'Parents & Guardians';

export type DepartmentTag =
  | 'All Departments'
  | 'Office of the President'
  | 'Office of the Registrar'
  | 'College of Nursing'
  | 'College of Education'
  | 'College of Business Administration'
  | 'College of Arts & Sciences'
  | 'College of Criminology'
  | 'College of Information Technology'
  | 'Basic Education & Senior High'
  | 'Supreme Student Council'
  | 'Athletics Department';

// Default departments, seeded into the managed `departments` table.
export const DEFAULT_DEPARTMENTS: DepartmentTag[] = [
  'All Departments',
  'Office of the President',
  'Office of the Registrar',
  'College of Nursing',
  'College of Education',
  'College of Business Administration',
  'College of Arts & Sciences',
  'College of Criminology',
  'College of Information Technology',
  'Basic Education & Senior High',
  'Supreme Student Council',
  'Athletics Department',
];

export interface TaxonomyEntry {
  id: string;
  name: string;
  created_at?: string;
}

export interface Announcement {
  id: string;
  title: string;
  slug: string;
  content: string;
  summary: string;
  // Free-form: must match an entry in the managed `categories` table.
  category: string;
  // Free-form: must match an entry in the managed `departments` table.
  department: string;
  audience: TargetAudience;
  urgency: UrgencyLevel;
  is_pinned: boolean;
  is_published: boolean;
  views: number;
  reactions?: {
    helpful: number;
    heart: number;
    celebrate: number;
  };
  attachments?: Array<{
    name: string;
    size: string;
    url: string;
  }>;
  author_name: string;
  // Date/time printed on the circular; defaults to created_at.
  issue_date?: string;
  created_at: string;
  updated_at: string;
}

export type EventCategory =
  | 'Academic Calendar'
  | 'Campus Life & Culture'
  | 'Athletics & Sports'
  | 'Seminars & Workshops'
  | 'Examinations'
  | 'Holidays & Observances'
  | 'Administrative & Faculty Meetings'
  | 'Alumni & Community';

export interface SchoolEvent {
  id: string;
  title: string;
  description: string;
  location: string;
  category: EventCategory;
  start_time: string; // ISO string
  end_time: string;   // ISO string
  capacity: number;
  rsvp_count: number;
  is_featured: boolean;
  organizer: string;
  target_audience: TargetAudience;
  // Free-form: must match an entry in the managed `departments` table.
  department: string;
  banner_color?: string;
  created_at: string;
}

export type StudentStatus = 'pending' | 'approved' | 'declined';

export interface Student {
  student_id: string;
  fname: string;
  lname: string;
  mname?: string;
  course: string;
  year: number;
  phone: string;
  email: string;
  status?: StudentStatus;
  created_at?: string;
}

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: 'Super Admin' | 'Dean / Dept Head' | 'Student Affairs Officer';
  department?: string;
}

export interface DatabaseStatus {
  connected: boolean;
  engine: 'mysql';
  host?: string;
  database?: string;
  error?: string;
  item_counts?: {
    announcements: number;
    events: number;
    students?: number;
    pending_students?: number;
  };
}
